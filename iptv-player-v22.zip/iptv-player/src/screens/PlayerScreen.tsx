import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Image,
  Platform,
  Pressable,
  StatusBar,
  StyleSheet,
  Text,
  useTVEventHandler,
  View,
} from 'react-native';
import Video from 'react-native-video';
import { ScreenProps } from '../nav/Navigator';
import { getNowNext } from '../api/epg';
import NowNext from '../components/NowNext';
import Logo from '../components/Logo';
import Clock from '../components/Clock';
import { getQueue, getQueueSource } from '../playerQueue';
import VodPlayer from './VodPlayer';
import Focusable from '../components/Focusable';
import { describeVideoError, openInVlc } from '../utils/external';
import { colors } from '../theme';
import { Program } from '../types';

type Props = ScreenProps<'Player'>;

/** Films/séries → moteur VLC intégré ; télé en direct → lecteur Android. */
export default function PlayerScreen(props: Props) {
  const vod = props.route.params.vod;
  if (vod) {
    return <VodPlayer url={vod.url} title={vod.title} catchup={vod.catchup} />;
  }
  return <LivePlayer {...props} />;
}

function LivePlayer({ route }: Props) {
  const vod = route.params.vod;
  const isLive = !vod;

  const queue = getQueue();
  const source = getQueueSource();
  const [index, setIndex] = useState(route.params.index ?? 0);
  const [buffering, setBuffering] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [errorDetail, setErrorDetail] = useState<string | null>(null);
  const [slow, setSlow] = useState(false);
  const [attempt, setAttempt] = useState(0);
  // Reconnexions automatiques du direct avant d'afficher une erreur
  const autoRetry = useRef(0);
  // Surveillance : si l'image n'avance plus, on se reconnecte
  const lastProgress = useRef(Date.now());
  const errorRef = useRef<string | null>(null);
  errorRef.current = error;
  const reconnect = useCallback(() => {
    lastProgress.current = Date.now();
    setBuffering(true);
    setAttempt(a => a + 1);
  }, []);
  useEffect(() => {
    if (!isLive) {
      return;
    }
    const t = setInterval(() => {
      if (!errorRef.current && Date.now() - lastProgress.current > 12000) {
        reconnect();
      }
    }, 2000);
    return () => clearInterval(t);
  }, [isLive, reconnect]);
  const [overlay, setOverlay] = useState(true);
  const [epg, setEpg] = useState<Program[]>([]);
  const hideTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const channel = isLive ? queue[index] : undefined;
  const url = vod ? vod.url : channel?.streamUrl;
  const title = vod ? vod.title : channel?.name;

  const showOverlay = useCallback(() => {
    setOverlay(true);
    if (hideTimer.current) {
      clearTimeout(hideTimer.current);
    }
    hideTimer.current = setTimeout(() => setOverlay(false), 5000);
  }, []);

  const zap = useCallback(
    (delta: number) => {
      if (!isLive || queue.length === 0) {
        return;
      }
      setIndex(i => (i + delta + queue.length) % queue.length);
      setError(null);
      setErrorDetail(null);
      setBuffering(true);
      autoRetry.current = 0;
      lastProgress.current = Date.now();
      showOverlay();
    },
    [isLive, queue.length, showOverlay],
  );

  useEffect(() => {
    showOverlay();
    return () => {
      if (hideTimer.current) {
        clearTimeout(hideTimer.current);
      }
    };
  }, [showOverlay]);

  // Guide horaire de la chaîne en cours
  useEffect(() => {
    if (!channel || !source) {
      return;
    }
    let cancelled = false;
    setEpg([]);
    getNowNext(source, channel).then(data => {
      if (!cancelled) {
        setEpg(data);
      }
    });
    return () => {
      cancelled = true;
    };
  }, [channel, source]);

  // Télécommande (direct seulement) : haut/bas = changer de chaîne, OK = infos.
  // En film/série, les contrôles natifs du lecteur gèrent la télécommande.
  useTVEventHandler(evt => {
    if (!evt || !isLive) {
      return;
    }
    if (evt.eventType === 'up' || evt.eventType === 'channelUp') {
      zap(-1);
    } else if (evt.eventType === 'down' || evt.eventType === 'channelDown') {
      zap(1);
    } else if (evt.eventType === 'select') {
      showOverlay();
    }
  });

  // Film/série qui charge depuis plus de 20 s : on propose VLC
  useEffect(() => {
    setSlow(false);
    if (!buffering || error) {
      return;
    }
    const t = setTimeout(() => setSlow(true), 20000);
    return () => clearTimeout(t);
  }, [buffering, error, url, attempt]);

  const retry = () => {
    setError(null);
    setErrorDetail(null);
    setBuffering(true);
    setAttempt(a => a + 1);
  };

  if (!url) {
    return (
      <View style={styles.container}>
        <Text style={styles.errorText}>Rien à lire.</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <StatusBar hidden />
      <Video
        key={`${url}#${attempt}`}
        source={{ uri: url }}
        style={StyleSheet.absoluteFill}
        resizeMode="contain"
        controls={!isLive}
        onLoad={() => {
          setBuffering(false);
          autoRetry.current = 0;
        }}
        onBuffer={({ isBuffering }) => setBuffering(isBuffering)}
        progressUpdateInterval={1000}
        onProgress={() => {
          lastProgress.current = Date.now();
        }}
        onEnd={() => {
          // le serveur a fermé le flux : en direct, on se reconnecte
          if (isLive) {
            reconnect();
          }
        }}
        onError={(e: any) => {
          if (isLive && autoRetry.current < 3) {
            // coupure du flux : on se reconnecte sans rien afficher
            autoRetry.current++;
            setBuffering(true);
            setTimeout(() => setAttempt(a => a + 1), 1000);
            return;
          }
          setBuffering(false);
          setError(
            isLive
              ? 'Cette chaîne ne joue pas en ce moment.'
              : 'Le lecteur intégré ne peut pas lire ce contenu.',
          );
          setErrorDetail(describeVideoError(e));
        }}
        bufferConfig={{
          minBufferMs: 5000,
          maxBufferMs: 30000,
          bufferForPlaybackMs: 1500,
          bufferForPlaybackAfterRebufferMs: 3000,
        }}
      />

      {/* Zone tactile (téléphone, direct) pour afficher les infos */}
      {isLive && (
        <Pressable
          style={StyleSheet.absoluteFill}
          onPress={showOverlay}
          focusable={false}
        />
      )}

      {buffering && !error && (
        <ActivityIndicator size="large" color={colors.accent} style={styles.spinner} />
      )}

      {(error || (slow && !isLive)) && (
        <View style={styles.errorBox}>
          <Text style={styles.errorText}>
            {error || 'Le chargement est long… ce format n’est peut-être pas pris en charge.'}
          </Text>
          {!!errorDetail && <Text style={styles.errorDetail}>{errorDetail}</Text>}
          <View style={styles.errorButtons}>
            <Focusable hasTVPreferredFocus style={styles.errBtn} onPress={retry}>
              <Text style={styles.errBtnText}>↻  Réessayer</Text>
            </Focusable>
            {!isLive && (
              <Focusable style={[styles.errBtn, styles.vlcBtn]} onPress={() => openInVlc(url)}>
                <Text style={styles.errBtnText}>Ouvrir avec VLC</Text>
              </Focusable>
            )}
          </View>
        </View>
      )}

      {overlay && isLive && (
        <>
          <View style={styles.topBar} pointerEvents="none">
            <Logo size={22} />
            <Clock />
          </View>
          <View style={styles.overlay} pointerEvents="box-none">
            <View style={styles.info}>
              <View style={styles.infoHead}>
                <View style={styles.logoBox}>
                  {channel?.logo ? (
                    <Image source={{ uri: channel.logo }} style={styles.logo} resizeMode="contain" />
                  ) : (
                    <Text style={styles.logoLetter}>{(title || '?').charAt(0)}</Text>
                  )}
                </View>
                <Text style={styles.number}>{index + 1}</Text>
                <View style={{ flex: 1 }}>
                  <Text style={styles.name} numberOfLines={1}>
                    {title}
                  </Text>
                  <View style={styles.livePill}>
                    <View style={styles.liveDot} />
                    <Text style={styles.liveText}>EN DIRECT</Text>
                  </View>
                </View>
              </View>
              {epg.length > 0 && <NowNext programs={epg} />}
            </View>
            {!Platform.isTV && (
              <View style={styles.zapButtons}>
                <Pressable style={styles.zapBtn} onPress={() => zap(-1)}>
                  <Text style={styles.zapText}>▲</Text>
                </Pressable>
                <Pressable style={styles.zapBtn} onPress={() => zap(1)}>
                  <Text style={styles.zapText}>▼</Text>
                </Pressable>
              </View>
            )}
          </View>
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000', justifyContent: 'center' },
  spinner: { position: 'absolute', alignSelf: 'center' },
  errorBox: {
    position: 'absolute',
    alignSelf: 'center',
    backgroundColor: 'rgba(7,10,18,0.85)',
    padding: 18,
    borderRadius: 14,
  },
  errorText: { color: colors.text, fontSize: 17, fontWeight: '700', textAlign: 'center' },
  errorDetail: { color: colors.muted, fontSize: 12, textAlign: 'center', marginTop: 8, maxWidth: 520 },
  errorButtons: { flexDirection: 'row', gap: 12, justifyContent: 'center', marginTop: 16 },
  errBtn: {
    paddingHorizontal: 20,
    paddingVertical: 11,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: colors.border,
    backgroundColor: colors.panelAlt,
  },
  vlcBtn: { backgroundColor: '#f97316', borderColor: '#f97316' },
  errBtnText: { color: '#fff', fontSize: 15, fontWeight: '800' },
  topBar: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    paddingHorizontal: 28,
    paddingVertical: 18,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'rgba(7,10,18,0.55)',
  },
  overlay: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    padding: 24,
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
  },
  info: {
    flex: 1,
    maxWidth: 760,
    backgroundColor: 'rgba(7,10,18,0.82)',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
    paddingHorizontal: 22,
    paddingVertical: 18,
  },
  infoHead: { flexDirection: 'row', alignItems: 'center', marginBottom: 14 },
  logoBox: {
    width: 72,
    height: 50,
    borderRadius: 10,
    backgroundColor: 'rgba(255,255,255,0.08)',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 14,
    overflow: 'hidden',
  },
  logo: { width: '86%', height: '86%' },
  logoLetter: { color: colors.muted, fontSize: 22, fontWeight: '900' },
  number: { color: colors.accent, fontSize: 28, fontWeight: '900', marginRight: 14 },
  name: { color: '#fff', fontSize: 22, fontWeight: '800' },
  livePill: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 4 },
  liveDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: colors.live },
  liveText: { color: colors.live, fontSize: 11, fontWeight: '900', letterSpacing: 1 },
  zapButtons: { gap: 12, marginLeft: 14 },
  zapBtn: {
    backgroundColor: 'rgba(7,10,18,0.82)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
    width: 56,
    height: 56,
    borderRadius: 28,
    alignItems: 'center',
    justifyContent: 'center',
  },
  zapText: { color: '#fff', fontSize: 20 },
});
