package __PKG__;

import com.facebook.react.ReactPackage;
import com.facebook.react.bridge.NativeModule;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.uimanager.ViewManager;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class KingUpdatePackage implements ReactPackage {
  @Override
  public List<NativeModule> createNativeModules(ReactApplicationContext context) {
    List<NativeModule> modules = new ArrayList<>();
    modules.add(new KingUpdateModule(context));
    modules.add(new KingRecordModule(context));
    return modules;
  }

  @SuppressWarnings({"rawtypes", "unchecked"})
  @Override
  public List createViewManagers(ReactApplicationContext context) {
    return Collections.emptyList();
  }
}
