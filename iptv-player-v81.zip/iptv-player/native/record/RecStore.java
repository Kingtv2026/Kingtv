package __PKG__;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.json.JSONObject;

/** Enregistrements programmés ou en cours, gardés même si l'app est fermée. */
final class RecStore {
  static final String ACTION_START = "king.rec.START";

  private static SharedPreferences prefs(Context c) {
    return c.getSharedPreferences("king_rec", Context.MODE_PRIVATE);
  }

  static synchronized JSONObject all(Context c) {
    try {
      return new JSONObject(prefs(c).getString("jobs", "{}"));
    } catch (Exception e) {
      return new JSONObject();
    }
  }

  private static void save(Context c, JSONObject a) {
    prefs(c).edit().putString("jobs", a.toString()).apply();
  }

  static synchronized JSONObject get(Context c, String id) {
    return all(c).optJSONObject(id);
  }

  static synchronized void put(Context c, JSONObject job) {
    try {
      JSONObject a = all(c);
      a.put(job.getString("id"), job);
      save(c, a);
    } catch (Exception ignored) {
    }
  }

  static synchronized void remove(Context c, String id) {
    JSONObject a = all(c);
    a.remove(id);
    save(c, a);
  }

  static List<JSONObject> list(Context c) {
    List<JSONObject> out = new ArrayList<>();
    JSONObject a = all(c);
    Iterator<String> it = a.keys();
    while (it.hasNext()) {
      JSONObject j = a.optJSONObject(it.next());
      if (j != null) out.add(j);
    }
    return out;
  }

  private static PendingIntent alarmIntent(Context c, String id) {
    Intent i = new Intent(c, KingRecordReceiver.class);
    i.setAction(ACTION_START);
    i.setData(Uri.parse("kingrec://" + id));
    i.putExtra("id", id);
    return PendingIntent.getBroadcast(c, id.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
  }

  static void schedule(Context c, JSONObject job) {
    AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
    if (am == null) return;
    PendingIntent pi = alarmIntent(c, job.optString("id"));
    long at = job.optLong("startAt");
    try {
      if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
      } else {
        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
      }
    } catch (Exception e) {
      am.set(AlarmManager.RTC_WAKEUP, at, pi);
    }
  }

  static void unschedule(Context c, String id) {
    AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
    if (am != null) am.cancel(alarmIntent(c, id));
  }

  /** Au démarrage de l'appareil : remet les alarmes, reprend ce qui devait tourner. */
  static void restoreAll(Context c) {
    long now = System.currentTimeMillis();
    for (JSONObject j : list(c)) {
      String id = j.optString("id");
      if (j.optLong("endAt") <= now) {
        remove(c, id);
      } else if (j.optLong("startAt") <= now) {
        KingRecordService.start(c, id);
      } else {
        try {
          j.put("status", "scheduled");
        } catch (Exception ignored) {
        }
        put(c, j);
        schedule(c, j);
      }
    }
  }
}
