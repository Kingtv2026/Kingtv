package __PKG__;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Alarme d'un enregistrement programmé, et redémarrage de l'appareil. */
public class KingRecordReceiver extends BroadcastReceiver {
  @Override
  public void onReceive(Context context, Intent intent) {
    String a = intent.getAction();
    if (RecStore.ACTION_START.equals(a)) {
      String id = intent.getStringExtra("id");
      if (id != null) KingRecordService.start(context, id);
    } else if (Intent.ACTION_BOOT_COMPLETED.equals(a) || "android.intent.action.QUICKBOOT_POWERON".equals(a)) {
      RecStore.restoreAll(context);
    }
  }
}
