package __PKG__;

import android.content.Context;
import android.os.Environment;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import java.io.File;
import java.io.FileInputStream;
import java.nio.charset.StandardCharsets;
import org.json.JSONArray;
import org.json.JSONObject;

/** Pont entre l'app et les enregistrements (appareil ou clé USB). */
public class KingRecordModule extends ReactContextBaseJavaModule {
  private final ReactApplicationContext ctx;

  public KingRecordModule(ReactApplicationContext context) {
    super(context);
    ctx = context;
  }

  @Override
  public String getName() {
    return "KingRecord";
  }

  /** Dossiers d'enregistrement possibles : stockage de l'appareil, clés USB, cartes SD. */
  private JSONArray volumes() {
    JSONArray arr = new JSONArray();
    File[] dirs = ctx.getExternalFilesDirs(null);
    StorageManager sm = (StorageManager) ctx.getSystemService(Context.STORAGE_SERVICE);
    int ext = 0;
    for (int i = 0; dirs != null && i < dirs.length; i++) {
      File d = dirs[i];
      if (d == null) continue;
      try {
        boolean removable = i > 0 && Environment.isExternalStorageRemovable(d);
        String label = null;
        if (sm != null) {
          StorageVolume v = sm.getStorageVolume(d);
          if (v != null) {
            label = v.getDescription(ctx);
            removable = v.isRemovable();
          }
        }
        if (label == null || label.isEmpty()) label = i == 0 ? "Appareil" : "Stockage externe " + (++ext);
        File rec = new File(d, "Enregistrements");
        JSONObject o = new JSONObject();
        o.put("path", rec.getAbsolutePath());
        o.put("label", i == 0 && !removable ? "Appareil" : label);
        o.put("removable", removable);
        o.put("free", d.getUsableSpace());
        o.put("total", d.getTotalSpace());
        arr.put(o);
      } catch (Exception ignored) {
      }
    }
    return arr;
  }

  @ReactMethod
  public void getVolumes(Promise p) {
    p.resolve(volumes().toString());
  }

  /** opts (JSON) : id, url, title, channel, startAt, endAt, dir, file */
  @ReactMethod
  public void record(String json, Promise p) {
    try {
      JSONObject job = new JSONObject(json);
      String id = job.getString("id");
      long now = System.currentTimeMillis();
      if (job.optLong("endAt") <= now) {
        p.reject("past", "Cette émission est déjà terminée.");
        return;
      }
      if (job.optLong("startAt") <= now + 5000) {
        job.put("status", "starting");
        RecStore.put(ctx, job);
        KingRecordService.start(ctx, id);
      } else {
        job.put("status", "scheduled");
        RecStore.put(ctx, job);
        RecStore.schedule(ctx, job);
      }
      p.resolve(id);
    } catch (Exception e) {
      p.reject("record", e.getMessage());
    }
  }

  @ReactMethod
  public void cancel(String id, Promise p) {
    JSONObject j = RecStore.get(ctx, id);
    RecStore.unschedule(ctx, id);
    if (j != null && "scheduled".equals(j.optString("status"))) {
      RecStore.remove(ctx, id);
    } else {
      KingRecordService.stop(ctx, id);
    }
    p.resolve(true);
  }

  @ReactMethod
  public void list(Promise p) {
    try {
      JSONObject out = new JSONObject();
      JSONArray jobs = new JSONArray();
      for (JSONObject j : RecStore.list(ctx)) {
        JSONObject c = new JSONObject(j.toString());
        c.remove("url");
        jobs.put(c);
      }
      out.put("jobs", jobs);
      JSONArray files = new JSONArray();
      JSONArray vols = volumes();
      for (int i = 0; i < vols.length(); i++) {
        JSONObject v = vols.getJSONObject(i);
        File[] list = new File(v.getString("path")).listFiles();
        if (list == null) continue;
        for (File f : list) {
          if (!f.isFile() || !f.getName().endsWith(".ts")) continue;
          JSONObject o = new JSONObject();
          o.put("path", f.getAbsolutePath());
          o.put("name", f.getName());
          o.put("size", f.length());
          o.put("mtime", f.lastModified());
          o.put("volume", v.getString("label"));
          File info = new File(f.getAbsolutePath() + ".json");
          if (info.isFile() && info.length() < 65536) {
            try (FileInputStream in = new FileInputStream(info)) {
              byte[] b = new byte[(int) info.length()];
              int n = in.read(b);
              o.put("info", new JSONObject(new String(b, 0, Math.max(n, 0), StandardCharsets.UTF_8)));
            } catch (Exception ignored) {
            }
          }
          files.put(o);
        }
      }
      out.put("files", files);
      p.resolve(out.toString());
    } catch (Exception e) {
      p.reject("list", e.getMessage());
    }
  }

  @ReactMethod
  public void deleteFile(String path, Promise p) {
    try {
      File f = new File(path).getCanonicalFile();
      JSONArray vols = volumes();
      boolean inside = false;
      for (int i = 0; i < vols.length(); i++) {
        String root = new File(vols.getJSONObject(i).getString("path")).getCanonicalPath() + File.separator;
        if (f.getPath().startsWith(root)) inside = true;
      }
      if (!inside || !f.getName().endsWith(".ts")) {
        p.reject("delete", "Fichier refusé.");
        return;
      }
      for (JSONObject j : RecStore.list(ctx)) {
        if (f.getPath().equals(j.optString("path"))) {
          p.reject("delete", "Arrête d'abord l'enregistrement en cours.");
          return;
        }
      }
      boolean ok = f.delete();
      new File(f.getPath() + ".json").delete();
      p.resolve(ok);
    } catch (Exception e) {
      p.reject("delete", e.getMessage());
    }
  }
}
