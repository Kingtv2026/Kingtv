/**
 * Petite navigation « pile d'écrans » en JavaScript pur (aucun code natif).
 * Remplace react-navigation / react-native-screens, qui posaient problème
 * avec la version TV de React Native.
 */
import { isTVLike } from '../device';
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { BackHandler, Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { colors } from '../theme';
import Background from '../components/Background';
import Clock from '../components/Clock';
import TabBar, { TabKey } from '../components/TabBar';
import SideMenu, { SIDE_W } from '../components/SideMenu';
import { RootStackParamList } from '../navigation';
import { useRemoteKeys } from '../remoteKeys';
import { CAT_FAVORITES } from '../types';

type RouteName = keyof RootStackParamList;

export interface Nav {
  navigate<N extends RouteName>(name: N, params?: RootStackParamList[N]): void;
  replace<N extends RouteName>(name: N, params?: RootStackParamList[N]): void;
  goBack(): void;
  /** Revient au tout premier écran (Mes listes) */
  popToTop(): void;
  setOptions(options: { title?: string }): void;
}

export type ScreenProps<N extends RouteName> = {
  navigation: Nav;
  route: { name: N; params: RootStackParamList[N] };
};

export interface ScreenConfig {
  component: React.ComponentType<any>;
  title?: string;
  headerShown?: boolean | (() => boolean);
  /** Plein écran (lecteur) : passe sous les barres du téléphone */
  fullscreen?: boolean;
  /** Onglet actif de la barre du bas (null = pas de barre) */
  tab?: (params: any) => TabKey | null;
}

// Sur téléphone Android, l'app s'affiche sous la barre d'état et la barre de
// navigation : on leur laisse de la place. Rien à faire sur la télé.
const PHONE = Platform.OS === 'android' && !isTVLike();
// L'app est en plein écran (barres du téléphone masquées) : petite marge seulement
const TOP_INSET = PHONE ? 6 : 0;
const BOTTOM_INSET = 0;

interface Entry {
  key: string;
  name: RouteName;
  params: any;
  title?: string;
}

const FocusContext = createContext(true);
const SideMenuContext = createContext<(hidden: boolean) => void>(() => {});

/** Cache le menu de gauche (télé) tant que `hidden` est vrai, ex. quand on parcourt une grille. */
export function useHideSideMenu(hidden: boolean) {
  const set = useContext(SideMenuContext);
  useEffect(() => {
    set(hidden);
    return () => set(false);
  }, [hidden, set]);
}

/** Vrai quand l'écran est celui du dessus. */
export function useIsFocused(): boolean {
  return useContext(FocusContext);
}

/** Exécute `effect` chaque fois que l'écran redevient visible. */
export function useFocusEffect(effect: () => void | (() => void)) {
  const focused = useIsFocused();
  useEffect(() => {
    if (focused) {
      return effect();
    }
  }, [focused, effect]);
}

let keyCounter = 0;
const newKey = () => `s${++keyCounter}`;

export function StackNavigator({
  screens,
  initial,
}: {
  screens: Record<RouteName, ScreenConfig>;
  initial: RouteName;
}) {
  const [stack, setStack] = useState<Entry[]>([
    { key: newKey(), name: initial, params: undefined },
  ]);
  const stackRef = useRef(stack);
  stackRef.current = stack;

  const push = useCallback((name: RouteName, params?: any) => {
    setStack(s => [...s, { key: newKey(), name, params }]);
  }, []);
  const replaceTop = useCallback((name: RouteName, params?: any) => {
    setStack(s => [...s.slice(0, -1), { key: newKey(), name, params }]);
  }, []);
  const pop = useCallback(() => {
    setStack(s => (s.length > 1 ? s.slice(0, -1) : s));
  }, []);
  const popToTop = useCallback(() => {
    setStack(s => s.slice(0, 1));
  }, []);
  const setTitle = useCallback((key: string, title?: string) => {
    setStack(s => s.map(e => (e.key === key ? { ...e, title } : e)));
  }, []);

  // Touches de la télécommande valables partout : GUIDE, DVR (enregistrements), TV, favoris
  useRemoteKeys(key => {
    const s = stackRef.current;
    const top = s[s.length - 1];
    let source: any = null;
    for (let i = s.length - 1; i >= 0 && !source; i--) {
      if (s[i].params?.source?.type === 'xtream') source = s[i].params.source;
    }
    if (key === 'guide') {
      if (top.name === 'Guide') {
        pop();
      } else if (top.name === 'Player' && s[s.length - 2]?.name === 'Guide') {
        pop(); // on revient au guide d'où vient la chaîne
      } else if (source) {
        push('Guide', { source });
      }
      return true;
    }
    if (key === 'menu') {
      // écran sans menu (guide, réglages, recherche…) : on revient à l'écran précédent
      if (top.name !== 'Player' && s.length > 1) {
        pop();
        return true;
      }
      return false;
    }
    if (key === 'dvr') {
      if (top.name !== 'Recordings') push('Recordings');
      return true;
    }
    if ((key === 'tv' || key === 'fav') && source && top.name !== 'Player') {
      push('Channels', key === 'fav' ? { source, initialCategory: CAT_FAVORITES } : { source });
      return true;
    }
    return false;
  });

  // Bouton « Retour » du téléphone ou de la télécommande
  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (stackRef.current.length > 1) {
        pop();
        return true;
      }
      return false; // dernier écran : on laisse Android fermer l'app
    });
    return () => sub.remove();
  }, [pop]);

  return (
    <View style={styles.root}>
      <Background />
      {stack.map((entry, i) => (
        <ScreenHost
          key={entry.key}
          entry={entry}
          config={screens[entry.name]}
          focused={i === stack.length - 1}
          canGoBack={i > 0}
          push={push}
          replaceTop={replaceTop}
          pop={pop}
          popToTop={popToTop}
          setTitle={setTitle}
        />
      ))}
    </View>
  );
}

function ScreenHost({
  entry,
  config,
  focused,
  canGoBack,
  push,
  replaceTop,
  pop,
  popToTop,
  setTitle,
}: {
  entry: Entry;
  config: ScreenConfig;
  focused: boolean;
  canGoBack: boolean;
  push: (n: RouteName, p?: any) => void;
  replaceTop: (n: RouteName, p?: any) => void;
  pop: () => void;
  popToTop: () => void;
  setTitle: (key: string, title?: string) => void;
}) {
  const navigation: Nav = useMemo(
    () => ({
      navigate: (name, params) => push(name, params),
      replace: (name, params) => replaceTop(name, params),
      goBack: pop,
      popToTop,
      setOptions: ({ title }) => setTitle(entry.key, title),
    }),
    [entry.key, push, replaceTop, pop, popToTop, setTitle],
  );
  const route = useMemo(
    () => ({ name: entry.name, params: entry.params }),
    [entry.name, entry.params],
  );
  const Component = config.component;
  const title = entry.title ?? config.title ?? '';
  const tabKey = config.tab ? config.tab(entry.params) : null;
  const tabSource = entry.params?.source;
  const hasTabs = !!tabKey && tabSource?.type === 'xtream';
  // Télévision (Android TV, Formuler, Fire Stick…) : menu à gauche. Cellulaire : menu en bas.
  const [sideHidden, setSideHidden] = useState(false);
  const sideMenu = hasTabs && isTVLike() && !sideHidden;

  return (
    // Les écrans du dessous restent montés (on garde leur état) mais cachés
    <View
      style={[
        StyleSheet.absoluteFill,
        !config.fullscreen && { paddingTop: TOP_INSET, paddingBottom: BOTTOM_INSET },
        !focused && styles.hidden,
      ]}>
      <FocusContext.Provider value={focused}>
      <SideMenuContext.Provider value={setSideHidden}>
        <View style={[{ flex: 1 }, sideMenu && { marginLeft: SIDE_W }]}>
        {(typeof config.headerShown === 'function' ? config.headerShown() : config.headerShown !== false) && (
          <View style={styles.header}>
            {canGoBack && (
              <Pressable onPress={pop} focusable={false} style={styles.back} hitSlop={12}>
                <Text style={styles.backText}>‹</Text>
              </Pressable>
            )}
            <Text style={styles.title} numberOfLines={1}>
              {title}
            </Text>
            <Clock compact />
          </View>
        )}
        <View style={styles.body}>
          <Component navigation={navigation} route={route} />
        </View>
        {hasTabs && !isTVLike() && <TabBar active={tabKey!} source={tabSource} navigation={navigation} />}
        </View>
        {sideMenu && <SideMenu active={tabKey!} source={tabSource} navigation={navigation} />}
      </SideMenuContext.Provider>
      </FocusContext.Provider>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  hidden: { display: 'none' },
  header: {
    height: 64,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  back: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.panel,
    borderWidth: 1,
    borderColor: colors.border,
    marginRight: 14,
  },
  backText: { color: colors.text, fontSize: 30, lineHeight: 32, marginTop: -3 },
  title: { color: colors.text, fontSize: 22, fontWeight: '800', flex: 1, letterSpacing: 0.3 },
  body: { flex: 1 },
});
