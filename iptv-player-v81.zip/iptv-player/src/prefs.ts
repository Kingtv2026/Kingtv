import AsyncStorage from '@react-native-async-storage/async-storage';

export type LiveEngine = 'vlc' | 'exo';
const KEY = 'iptv.liveEngine';
let engine: LiveEngine = 'vlc';

/** À appeler au démarrage : charge le choix du lecteur de la télé en direct. */
export async function loadPrefs() {
  try {
    const v = await AsyncStorage.getItem(KEY);
    if (v === 'vlc' || v === 'exo') {
      engine = v;
    }
    guidePreview = (await AsyncStorage.getItem(K_GP)) === '1';
  } catch {}
}

export function getLiveEngine(): LiveEngine {
  return engine;
}

export async function setLiveEngine(v: LiveEngine) {
  engine = v;
  await AsyncStorage.setItem(KEY, v).catch(() => {});
}

// Aperçu vidéo dans le guide horaire (désactivé par défaut : plus fluide sur les boîtiers)
const K_GP = 'iptv.guidePreview';
let guidePreview = false;
export function getGuidePreview(): boolean {
  return guidePreview;
}
export async function setGuidePreview(v: boolean) {
  guidePreview = v;
  await AsyncStorage.setItem(K_GP, v ? '1' : '0').catch(() => {});
}
