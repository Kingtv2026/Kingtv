import AsyncStorage from '@react-native-async-storage/async-storage';
import { VodItem } from './types';

/** Historique et favoris des films / séries, gardés sur l'appareil (par liste). */
export type VodKind = 'movie' | 'series';
const MAX_HIST = 60;

const mem = new Map<string, VodItem[]>();
const key = (what: 'hist' | 'fav', srcId: string, kind: VodKind) => `iptv.vod.${what}.${srcId}.${kind}`;

async function read(k: string): Promise<VodItem[]> {
  const hit = mem.get(k);
  if (hit) return hit;
  try {
    const v = JSON.parse((await AsyncStorage.getItem(k)) || '[]');
    const list = Array.isArray(v) ? v : [];
    mem.set(k, list);
    return list;
  } catch {
    return [];
  }
}
async function write(k: string, list: VodItem[]) {
  mem.set(k, list);
  await AsyncStorage.setItem(k, JSON.stringify(list)).catch(() => {});
}
const slim = (i: VodItem): VodItem => ({
  id: i.id,
  name: i.name,
  poster: i.poster,
  rating: i.rating,
  added: i.added,
  categoryId: i.categoryId,
  url: i.url,
});

export function getHistory(srcId: string, kind: VodKind) {
  return read(key('hist', srcId, kind));
}
/** Ajoute en tête de l'historique (déjà vu = remonte en premier). */
export async function addHistory(srcId: string, kind: VodKind, item: VodItem) {
  const k = key('hist', srcId, kind);
  const list = (await read(k)).filter(i => i.id !== item.id);
  await write(k, [slim(item), ...list].slice(0, MAX_HIST));
}

export function getFavs(srcId: string, kind: VodKind) {
  return read(key('fav', srcId, kind));
}
export async function isFav(srcId: string, kind: VodKind, id: string) {
  return (await read(key('fav', srcId, kind))).some(i => i.id === id);
}
/** Ajoute ou retire des favoris. Retourne le nouvel état (true = favori). */
export async function toggleFav(srcId: string, kind: VodKind, item: VodItem) {
  const k = key('fav', srcId, kind);
  const list = await read(k);
  const on = list.some(i => i.id === item.id);
  await write(k, on ? list.filter(i => i.id !== item.id) : [slim(item), ...list]);
  return !on;
}

// Appui long sur une affiche : ajoute / retire des favoris de la section ouverte
let ctx: { srcId: string; kind: VodKind } | null = null;
const listeners = new Set<(name: string, fav: boolean) => void>();
export function setVodContext(srcId: string, kind: VodKind) {
  ctx = { srcId, kind };
}
export function onFavChange(fn: (name: string, fav: boolean) => void) {
  listeners.add(fn);
  return () => {
    listeners.delete(fn);
  };
}
export async function longPressFav(item: VodItem) {
  if (!ctx) return;
  const fav = await toggleFav(ctx.srcId, ctx.kind, item);
  listeners.forEach(l => l(item.name, fav));
}
