import AsyncStorage from '@react-native-async-storage/async-storage';

const K_PIN = 'iptv.parentalPin';
let pin = '0000';
let unlocked = false;
const listeners = new Set<() => void>();

/** Groupes considérés « adultes » d'après leur nom. */
const ADULT_RE = /(\b(adult|adulte|adultes|adults|xxx|porn|porno|érotique|erotique|erotic|hentai)\b)|18\s*\+|\+\s*18|for adults/i;

export function isAdultName(name?: string | null): boolean {
  return !!name && ADULT_RE.test(name);
}

export async function loadParental() {
  try {
    const v = await AsyncStorage.getItem(K_PIN);
    if (v && /^\d{4}$/.test(v)) {
      pin = v;
    }
  } catch {}
}

export function checkPin(p: string): boolean {
  return p === pin;
}

export async function setPin(p: string) {
  pin = p;
  await AsyncStorage.setItem(K_PIN, p).catch(() => {});
}

export function isUnlocked(): boolean {
  return unlocked;
}

export function unlock() {
  unlocked = true;
  listeners.forEach(fn => fn());
}

export function lock() {
  unlocked = false;
  listeners.forEach(fn => fn());
}

/** Être prévenu quand on verrouille/déverrouille (pour rafraîchir les listes). */
export function onParentalChange(fn: () => void): () => void {
  listeners.add(fn);
  return () => listeners.delete(fn);
}
