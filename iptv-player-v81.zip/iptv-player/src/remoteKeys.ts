import { useEffect, useRef } from 'react';
import { DeviceEventEmitter } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

/**
 * Touches spéciales de la télécommande envoyées par Android :
 * guide, dvr, record, last, info, tv, fav, red/green/yellow/blue, d0…d9.
 * Le dernier écran inscrit (celui du dessus) passe en premier ; s'il ne
 * gère pas la touche (retourne false), elle passe au suivant.
 */
type Handler = (key: string) => boolean;
const handlers: Handler[] = [];

// Boutons associés par l'utilisateur : code Android → action (ex. 172 → guide)
const K_MAP = 'iptv.keymap';
let keymap: Record<string, string> = {};
AsyncStorage.getItem(K_MAP)
  .then(v => {
    if (v) keymap = JSON.parse(v);
  })
  .catch(() => {});

export async function mapKey(code: string, action: string) {
  // un seul bouton par action
  for (const k of Object.keys(keymap)) if (keymap[k] === action) delete keymap[k];
  keymap[code] = action;
  await AsyncStorage.setItem(K_MAP, JSON.stringify(keymap)).catch(() => {});
}
export function mappedCode(action: string): string | null {
  return Object.keys(keymap).find(k => keymap[k] === action) || null;
}
export async function resetKeymap() {
  keymap = {};
  await AsyncStorage.removeItem(K_MAP).catch(() => {});
}

// Écoute du « prochain bouton pressé » (écran d'association)
let rawListener: ((code: string) => void) | null = null;
export function captureNextKey(cb: ((code: string) => void) | null) {
  rawListener = cb;
}

function dispatch(key: string) {
  for (let i = handlers.length - 1; i >= 0; i--) {
    try {
      if (handlers[i](key)) return;
    } catch {}
  }
}

DeviceEventEmitter.addListener('kingKey', (key: string) => {
  // code à retenir : touche inconnue d'Android ("c123") ou touche nommée ("n:record")
  const code = key.startsWith('c') ? key.slice(1) : `n:${key}`;
  if (rawListener) {
    const cb = rawListener;
    rawListener = null;
    cb(code);
    return;
  }
  const action = keymap[code];
  if (action) {
    dispatch(action);
    return;
  }
  if (!key.startsWith('c')) dispatch(key);
});

/** Inscrit un gestionnaire tant que `active` est vrai (écran visible). */
export function useRemoteKeys(handler: Handler, active = true) {
  const ref = useRef(handler);
  ref.current = handler;
  useEffect(() => {
    if (!active) return;
    const h: Handler = k => ref.current(k);
    handlers.push(h);
    return () => {
      const i = handlers.indexOf(h);
      if (i >= 0) handlers.splice(i, 1);
    };
  }, [active]);
}
