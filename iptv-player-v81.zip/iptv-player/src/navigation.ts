import { Channel, Program, Source, VodItem, XtreamSource } from './types';

export type RootStackParamList = {
  Activation: undefined;
  Sources: undefined;
  AddSource: { edit?: Source; reopen?: boolean } | undefined;
  Home: { source: XtreamSource };
  Channels: { source: Source; initialCategory?: string };
  Guide: { source: XtreamSource };
  Settings: { source: XtreamSource };
  Search: { source: XtreamSource };
  Recordings: undefined;
  Catchup: { source: XtreamSource; channel: Channel };
  Media: { source: XtreamSource; kind: 'movie' | 'series' };
  MovieDetail: { source: XtreamSource; item: VodItem };
  SeriesDetail: { source: XtreamSource; item: VodItem };
  Player: {
    index?: number;
    vod?: {
      url: string;
      title: string;
      /** Rattrapage : les sauts redemandent l'émission au serveur */
      catchup?: {
        source: XtreamSource;
        streamId: string;
        program: Program;
        /** Commencer à cette minute de l'émission (pause du direct) */
        startOffsetMin?: number;
        /** Différé d'une chaîne en direct : position de la chaîne pour « Retour au direct » */
        liveIndex?: number;
      };
    };
  };
};

/** Xtream : écran d'accueil (Direct / Films / Séries). M3U : directement les chaînes. */
export function openSource(navigation: any, source: Source, replace = false) {
  const screen = source.type === 'xtream' ? 'Home' : 'Channels';
  if (replace) {
    navigation.replace(screen, { source });
  } else {
    navigation.navigate(screen, { source });
  }
}
