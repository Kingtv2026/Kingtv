import AsyncStorage from '@react-native-async-storage/async-storage';
import { Platform } from 'react-native';
import { LICENSE_API } from './buildInfo';
import { getSources, removeSource, saveSource } from './storage';
import { clearCaches } from './api';
import { Source } from './types';
import { setBrand } from './brand';

/** Identifiant de la liste gérée depuis le panneau du vendeur. */
export const PANEL_SOURCE_ID = 'panel';

const K_DEVICE = 'iptv.deviceId';
const K_LICENSE = 'iptv.license';
/** Dernier abonnement reçu du panneau (pour ne pas écraser les corrections du client) */
const K_PANEL_PORTAL = 'iptv.panelPortal';

export interface License {
  code: string;
  name?: string;
  expires?: string | null;
  checkedAt: number;
  graceDays: number;
}

/** Identifiant unique de l'appareil, créé une seule fois. */
export async function getDeviceId(): Promise<string> {
  let id = await AsyncStorage.getItem(K_DEVICE);
  if (!id) {
    const hex = '0123456789abcdef';
    id = Array.from({ length: 32 }, () => hex[Math.floor(Math.random() * 16)]).join('');
    await AsyncStorage.setItem(K_DEVICE, id);
  }
  return id;
}

/** Nom lisible de l'appareil, affiché dans le panneau. */
export function deviceLabel(): string {
  const c: any = (Platform as any).constants || {};
  const name = [c.Manufacturer, c.Model].filter(Boolean).join(' ');
  return name || (Platform.isTV ? 'Android TV' : 'Android');
}

export async function getStoredLicense(): Promise<License | null> {
  try {
    const raw = await AsyncStorage.getItem(K_LICENSE);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export class LicenseError extends Error {
  /** true = serveur injoignable (pas un refus) */
  network: boolean;
  constructor(msg: string, network: boolean) {
    super(msg);
    this.network = network;
  }
}

/**
 * Crée, met à jour ou retire la liste du client selon ce que le vendeur
 * a entré dans le panneau. Retourne la liste si elle existe.
 */
async function applyPortal(p: any): Promise<Source | null> {
  const existing = (await getSources()).find(s => s.id === PANEL_SOURCE_ID) || null;
  if (!p || (p.type !== 'xtream' && p.type !== 'm3u')) {
    if (existing) {
      await removeSource(PANEL_SOURCE_ID);
      clearCaches(PANEL_SOURCE_ID);
    }
    await AsyncStorage.removeItem(K_PANEL_PORTAL).catch(() => {});
    return null;
  }
  // Même abonnement que la dernière fois côté panneau : on garde la version
  // de l'appareil (le client a peut-être corrigé ses informations lui-même)
  const sig = JSON.stringify(p);
  const lastSig = await AsyncStorage.getItem(K_PANEL_PORTAL).catch(() => null);
  if (existing && lastSig === sig) {
    return existing;
  }
  const src: Source =
    p.type === 'm3u'
      ? { id: PANEL_SOURCE_ID, type: 'm3u', name: String(p.name || 'Ma liste'), url: String(p.url) }
      : {
          id: PANEL_SOURCE_ID,
          type: 'xtream',
          name: String(p.name || 'Ma liste'),
          server: String(p.server),
          username: String(p.username),
          password: String(p.password ?? ''),
        };
  if (JSON.stringify(existing) !== JSON.stringify(src)) {
    await saveSource(src);
    clearCaches(PANEL_SOURCE_ID);
  }
  await AsyncStorage.setItem(K_PANEL_PORTAL, sig).catch(() => {});
  return src;
}

/** Active ou vérifie un code auprès du panneau. */
export async function activate(code: string): Promise<License & { source: Source | null }> {
  const clean = code.trim().toUpperCase().replace(/\s+/g, '');
  let res: Response;
  try {
    res = await fetch(LICENSE_API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code: clean, device_id: await getDeviceId(), device_label: deviceLabel() }),
    });
  } catch {
    throw new LicenseError('Impossible de joindre le serveur. Vérifie ta connexion Internet.', true);
  }
  let data: any = null;
  try {
    data = await res.json();
  } catch {
    throw new LicenseError('Réponse invalide du serveur de licences.', true);
  }
  if (!data?.ok) {
    throw new LicenseError(data?.error || 'Code refusé.', !!data?.server);
  }
  const lic: License = {
    code: clean,
    name: data.name,
    expires: data.expires,
    checkedAt: Date.now(),
    graceDays: Number(data.grace_days) || 3,
  };
  await AsyncStorage.setItem(K_LICENSE, JSON.stringify(lic));
  await setBrand(data.brand);
  const source = await applyPortal(data.portal);
  return { ...lic, source };
}

export async function clearLicense() {
  await AsyncStorage.removeItem(K_LICENSE);
  await setBrand(null);
}

export function licensingEnabled(): boolean {
  return !!LICENSE_API;
}
