import { useEffect, useRef } from 'react';
import { AppState } from 'react-native';
import { activate, clearLicense, getStoredLicense, LicenseError, licensingEnabled, PANEL_SOURCE_ID } from './license';
import { openSource } from './navigation';
import { getSources } from './storage';
import { Source } from './types';

let lastCheck = 0;

/**
 * Revérifie le code auprès du panneau quand on revient dans l'app ou sur
 * l'écran (au plus une fois par minute). Si le vendeur a envoyé ou changé
 * l'abonnement à distance, l'app ouvre tout de suite la nouvelle version.
 * `active` : seulement pour l'écran visible.
 */
export function useLicenseWatch(navigation: any, current: Source | null, active: boolean) {
  const cur = useRef(current);
  cur.current = current;
  const on = useRef(active);
  on.current = active;
  const busy = useRef(false);

  const check = useRef(async () => {});
  check.current = async () => {
    if (!licensingEnabled() || !on.current || busy.current || Date.now() - lastCheck < 60000) return;
    const stored = await getStoredLicense();
    if (!stored) return;
    busy.current = true;
    lastCheck = Date.now();
    try {
      const before = (await getSources()).find(s => s.id === PANEL_SOURCE_ID) || null;
      const res = await activate(stored.code);
      const next = res.source;
      const changed = JSON.stringify(before) !== JSON.stringify(next);
      if (!changed || !on.current) return;
      const now = cur.current;
      if (next && (!now || now.id === PANEL_SOURCE_ID)) {
        navigation.popToTop();
        openSource(navigation, next);
      } else if (!next && now?.id === PANEL_SOURCE_ID) {
        navigation.popToTop();
      }
    } catch (e: any) {
      if (e instanceof LicenseError && !e.network) {
        await clearLicense();
        navigation.popToTop();
        navigation.replace('Activation');
      }
    } finally {
      busy.current = false;
    }
  };

  useEffect(() => {
    const sub = AppState.addEventListener('change', st => {
      if (st === 'active') check.current();
    });
    return () => sub.remove();
  }, []);

  useEffect(() => {
    if (active) check.current();
  }, [active]);
}
