import AsyncStorage from '@react-native-async-storage/async-storage';
import { NativeModules, PermissionsAndroid, Platform } from 'react-native';

const M: any = NativeModules.KingRecord;

/** Vrai si la version installée sait enregistrer (Android). */
export const recordingSupported = !!M;

export interface RecVolume {
  path: string;
  label: string;
  removable: boolean;
  free: number;
  total: number;
}

export interface RecJob {
  id: string;
  title: string;
  channel: string;
  startAt: number;
  endAt: number;
  status: 'scheduled' | 'starting' | 'recording';
  dir: string;
  path?: string;
  bytes?: number;
}

export interface RecFile {
  path: string;
  name: string;
  size: number;
  mtime: number;
  volume: string;
  title: string;
  channel: string;
  startAt: number;
  endAt: number;
}

const K_VOLUME = 'iptv.recVolume';

export async function getVolumes(): Promise<RecVolume[]> {
  if (!M) return [];
  try {
    return JSON.parse(await M.getVolumes());
  } catch {
    return [];
  }
}

/** Dernier stockage choisi (chemin), ou celui de l'appareil. */
export async function getPreferredVolume(vols: RecVolume[]): Promise<RecVolume | null> {
  const saved = await AsyncStorage.getItem(K_VOLUME).catch(() => null);
  return vols.find(v => v.path === saved) || vols[0] || null;
}

export async function setPreferredVolume(path: string) {
  await AsyncStorage.setItem(K_VOLUME, path).catch(() => {});
}

/** Nom de fichier sans accents ni espaces (lisible par tous les lecteurs). */
function safeName(s: string): string {
  return (
    s
      .normalize('NFD')
      .replace(/[̀-ͯ]/g, '')
      .replace(/[^A-Za-z0-9]+/g, '_')
      .replace(/^_+|_+$/g, '')
      .slice(0, 50) || 'tv'
  );
}

function stamp(ms: number): string {
  const d = new Date(ms);
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}_${p(d.getHours())}h${p(d.getMinutes())}`;
}

async function askNotifications() {
  if (Platform.OS === 'android' && Number(Platform.Version) >= 33) {
    try {
      await PermissionsAndroid.request('android.permission.POST_NOTIFICATIONS' as any);
    } catch {}
  }
}

/**
 * Enregistre maintenant (startAt ≤ maintenant) ou programme pour plus tard.
 * Pour une émission programmée, on commence 1 min avant et on finit 3 min après.
 */
export async function startRecording(opts: {
  url: string;
  title: string;
  channel: string;
  startAt: number;
  endAt: number;
  volume: RecVolume;
  padding?: boolean;
}): Promise<string> {
  if (!M) throw new Error('Mets l’app à jour pour enregistrer.');
  await askNotifications();
  const now = Date.now();
  const startAt = opts.padding ? Math.max(opts.startAt - 60000, now) : Math.max(opts.startAt, now);
  const endAt = opts.padding ? opts.endAt + 180000 : opts.endAt;
  const id = `${now.toString(36)}${Math.random().toString(36).slice(2, 6)}`;
  const file = `${safeName(opts.channel)}_${safeName(opts.title)}_${stamp(startAt)}.ts`;
  await setPreferredVolume(opts.volume.path);
  return M.record(
    JSON.stringify({ id, url: opts.url, title: opts.title, channel: opts.channel, startAt, endAt, dir: opts.volume.path, file }),
  );
}

export async function cancelRecording(id: string) {
  if (M) await M.cancel(id);
}

export async function listRecordings(): Promise<{ jobs: RecJob[]; files: RecFile[] }> {
  if (!M) return { jobs: [], files: [] };
  try {
    const raw = JSON.parse(await M.list());
    const files: RecFile[] = (raw.files || []).map((f: any) => ({
      path: f.path,
      name: f.name,
      size: f.size,
      mtime: f.mtime,
      volume: f.volume,
      title: f.info?.title || f.name.replace(/\.ts$/, '').replace(/_/g, ' '),
      channel: f.info?.channel || '',
      startAt: f.info?.startAt || f.mtime,
      endAt: f.info?.endAt || f.mtime,
    }));
    files.sort((a, b) => b.startAt - a.startAt);
    const jobs: RecJob[] = (raw.jobs || []).sort((a: RecJob, b: RecJob) => a.startAt - b.startAt);
    return { jobs, files };
  } catch {
    return { jobs: [], files: [] };
  }
}

export async function deleteRecording(path: string): Promise<boolean> {
  return M ? M.deleteFile(path) : false;
}

export function formatSize(bytes: number): string {
  if (bytes >= 1e9) return `${(bytes / 1e9).toFixed(1).replace('.', ',')} Go`;
  if (bytes >= 1e6) return `${Math.round(bytes / 1e6)} Mo`;
  return `${Math.max(1, Math.round(bytes / 1e3))} Ko`;
}
