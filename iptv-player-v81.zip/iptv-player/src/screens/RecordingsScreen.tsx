import React, { useCallback, useEffect, useState } from 'react';
import { FlatList, StyleSheet, Text, View } from 'react-native';
import { ScreenProps, useIsFocused } from '../nav/Navigator';
import Focusable from '../components/Focusable';
import Icon from '../components/Icon';
import { colors } from '../theme';
import { formatTime } from '../api/epg';
import {
  RecFile,
  RecJob,
  cancelRecording,
  deleteRecording,
  formatSize,
  listRecordings,
  recordingSupported,
} from '../record';

type Props = ScreenProps<'Recordings'>;

type Row =
  | { kind: 'head'; key: string; label: string }
  | { kind: 'job'; key: string; job: RecJob }
  | { kind: 'file'; key: string; file: RecFile }
  | { kind: 'empty'; key: string; label: string };

function dateLabel(ms: number) {
  const d = new Date(ms);
  const days = ['dim.', 'lun.', 'mar.', 'mer.', 'jeu.', 'ven.', 'sam.'];
  return `${days[d.getDay()]} ${d.getDate()}/${d.getMonth() + 1} · ${formatTime(ms)}`;
}

function minutes(a: number, b: number) {
  const m = Math.max(1, Math.round((b - a) / 60000));
  return m >= 60 ? `${Math.floor(m / 60)} h ${String(m % 60).padStart(2, '0')}` : `${m} min`;
}

export default function RecordingsScreen({ navigation }: Props) {
  const focused = useIsFocused();
  const [jobs, setJobs] = useState<RecJob[]>([]);
  const [files, setFiles] = useState<RecFile[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [confirm, setConfirm] = useState<string | null>(null);
  // Focus de départ seulement à l'ouverture (pas à chaque rafraîchissement)
  const [initialFocus, setInitialFocus] = useState(true);
  useEffect(() => {
    if (!loaded) return;
    const t = setTimeout(() => setInitialFocus(false), 1500);
    return () => clearTimeout(t);
  }, [loaded]);

  const refresh = useCallback(async () => {
    const r = await listRecordings();
    setJobs(r.jobs);
    setFiles(r.files);
    setLoaded(true);
  }, []);

  useEffect(() => {
    if (!focused) return;
    refresh();
    const t = setInterval(refresh, 3000);
    return () => clearInterval(t);
  }, [focused, refresh]);

  const active = jobs.filter(j => j.status !== 'scheduled');
  const scheduled = jobs.filter(j => j.status === 'scheduled');
  const busyPaths = new Set(active.map(j => j.path));
  const done = files.filter(f => !busyPaths.has(f.path));

  const rows: Row[] = [];
  if (active.length) {
    rows.push({ kind: 'head', key: 'h1', label: 'En cours' });
    active.forEach(j => rows.push({ kind: 'job', key: j.id, job: j }));
  }
  if (scheduled.length) {
    rows.push({ kind: 'head', key: 'h2', label: 'Programmés' });
    scheduled.forEach(j => rows.push({ kind: 'job', key: j.id, job: j }));
  }
  rows.push({ kind: 'head', key: 'h3', label: 'Enregistrés' });
  if (done.length) done.forEach(f => rows.push({ kind: 'file', key: f.path, file: f }));
  else if (loaded)
    rows.push({
      kind: 'empty',
      key: 'e',
      label: 'Aucun enregistrement. Pour enregistrer : dans le lecteur, bouton « Enregistrer » (sur télé : maintiens OK), ou depuis le guide horaire.',
    });

  let firstFocus = true;
  const preferred = () => {
    const v = firstFocus;
    firstFocus = false;
    return v && initialFocus;
  };

  const renderRow = ({ item }: { item: Row }) => {
    if (item.kind === 'head') return <Text style={styles.head}>{item.label}</Text>;
    if (item.kind === 'empty') return <Text style={styles.empty}>{item.label}</Text>;
    if (item.kind === 'job') {
      const j = item.job;
      const rec = j.status !== 'scheduled';
      return (
        <View style={styles.row}>
          <View style={[styles.badge, rec && { backgroundColor: 'rgba(255,59,92,0.18)' }]}>
            <Icon name={rec ? 'record' : 'clock'} size={22} color={rec ? colors.live : colors.accent} />
          </View>
          <View style={styles.body}>
            <Text style={styles.title} numberOfLines={1}>
              {j.title}
            </Text>
            <Text style={styles.meta} numberOfLines={1}>
              {j.channel} · {rec ? `jusqu’à ${formatTime(j.endAt)}` : `${dateLabel(j.startAt)} → ${formatTime(j.endAt)}`}
              {rec && j.bytes ? ` · ${formatSize(j.bytes)}` : ''}
            </Text>
          </View>
          <Focusable
            hasTVPreferredFocus={preferred()}
            style={[styles.btn, styles.btnDanger]}
            onPress={async () => {
              await cancelRecording(j.id);
              refresh();
            }}>
            <Icon name={rec ? 'stop' : 'trash'} size={18} color="#fff" />
            <Text style={styles.btnText}>{rec ? 'Arrêter' : 'Annuler'}</Text>
          </Focusable>
        </View>
      );
    }
    const f = item.file;
    const asking = confirm === f.path;
    return (
      <View style={styles.row}>
        <View style={styles.badge}>
          <Icon name="film" size={22} color={colors.accent} />
        </View>
        <View style={styles.body}>
          <Text style={styles.title} numberOfLines={1}>
            {f.title}
          </Text>
          <Text style={styles.meta} numberOfLines={1}>
            {f.channel ? `${f.channel} · ` : ''}
            {dateLabel(f.startAt)} · {minutes(f.startAt, f.endAt)} · {formatSize(f.size)} · {f.volume}
          </Text>
        </View>
        <Focusable
          hasTVPreferredFocus={preferred()}
          style={styles.btn}
          onPress={() =>
            navigation.navigate('Player', {
              vod: { url: 'file://' + f.path, title: f.channel ? `${f.channel} · ${f.title}` : f.title },
            })
          }>
          <Icon name="play" size={18} color="#fff" />
          <Text style={styles.btnText}>Regarder</Text>
        </Focusable>
        <Focusable
          style={[styles.btn, asking && styles.btnDanger]}
          onPress={async () => {
            if (!asking) {
              setConfirm(f.path);
              return;
            }
            setConfirm(null);
            try {
              await deleteRecording(f.path);
            } catch {}
            refresh();
          }}>
          <Icon name="trash" size={18} color="#fff" />
          {asking && <Text style={styles.btnText}>Confirmer</Text>}
        </Focusable>
      </View>
    );
  };

  if (!recordingSupported) {
    return (
      <View style={styles.container}>
        <Text style={styles.empty}>Cette version de l’app ne peut pas enregistrer. Fais la mise à jour.</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <FlatList data={rows} keyExtractor={r => r.key} renderItem={renderRow} contentContainerStyle={{ paddingBottom: 30 }} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, paddingHorizontal: 18 },
  head: {
    color: colors.muted,
    fontSize: 13,
    fontWeight: '900',
    letterSpacing: 1,
    textTransform: 'uppercase',
    marginTop: 18,
    marginBottom: 8,
  },
  empty: { color: colors.muted, fontSize: 15, lineHeight: 22, marginTop: 6, maxWidth: 640 },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    marginBottom: 8,
    borderRadius: 16,
    backgroundColor: colors.panel,
    borderWidth: 1,
    borderColor: colors.border,
    gap: 10,
  },
  badge: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: 'rgba(79,140,255,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  body: { flex: 1 },
  title: { color: colors.text, fontSize: 16, fontWeight: '800' },
  meta: { color: colors.muted, fontSize: 12, marginTop: 3 },
  btn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 12,
    backgroundColor: colors.panelAlt,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  btnDanger: { backgroundColor: colors.danger },
  btnText: { color: '#fff', fontSize: 14, fontWeight: '800' },
});
