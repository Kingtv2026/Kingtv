/**
 * Films / Séries sur télé, style MyTVOnline 4 :
 * grande image du titre sélectionné en haut, rangées d'affiches en bas,
 * groupes dans un panneau à gauche (← sur la 1re colonne), tri dans une petite fenêtre (touche rouge).
 */
import { longPressFav } from '../vodLibrary';
import React, { forwardRef, memo, useCallback, useEffect, useImperativeHandle, useRef, useState } from 'react';
import {
  ActivityIndicator,
  BackHandler,
  FlatList,
  Image,
  StyleSheet,
  Text,
  TextInput,
  useTVEventHandler,
  useWindowDimensions,
  View,
} from 'react-native';
import Focusable from '../components/Focusable';
import FocusTrap from '../components/FocusTrap';
import Icon, { IconName } from '../components/Icon';
import Clock from '../components/Clock';
import { colors } from '../theme';
import { thumb } from '../utils/thumb';
import { useRemoteKeys } from '../remoteKeys';
import { getMovieInfo, getSeriesInfo } from '../api/xtream';
import { Category, MovieInfo, VodItem, XtreamSource } from '../types';

const ROW_H = 44;
const SPECIAL_ICON: Record<string, IconName> = {
  __all__: 'film',
  __recent__: 'plus',
  __hist__: 'clock',
  __fav__: 'star',
};

export type NavKey = 'home' | 'live' | 'movies' | 'series' | 'guide' | 'search' | 'settings';
const NAV: { key: NavKey; icon: IconName; label: string }[] = [
  { key: 'home', icon: 'home', label: 'Accueil' },
  { key: 'live', icon: 'tv', label: 'En direct' },
  { key: 'movies', icon: 'film', label: 'Films' },
  { key: 'series', icon: 'series', label: 'Séries' },
  { key: 'guide', icon: 'guide', label: 'Guide' },
  { key: 'search', icon: 'search', label: 'Recherche' },
  { key: 'settings', icon: 'settings', label: 'Réglages' },
];

export type TvSort = 'default' | 'recent' | 'name' | 'za';
const SORTS: { id: TvSort; label: string }[] = [
  { id: 'default', label: 'Défaut' },
  { id: 'recent', label: 'Ajouts récents' },
  { id: 'name', label: 'A-Z' },
  { id: 'za', label: 'Z-A' },
];

// Fiches déjà demandées (on ne redemande pas en revenant sur un titre)
const infoCache = new Map<string, MovieInfo>();

function bigImage(url?: string) {
  if (!url) return url;
  return url.replace(/(image\.tmdb\.org\/t\/p\/)(original|w\d+(?:_and_h\d+[^/]*)?)(\/)/, '$1w780$3');
}

function addedLabel(sec?: number) {
  if (!sec) return '';
  const d = new Date(sec * 1000);
  const m = ['janv.', 'févr.', 'mars', 'avr.', 'mai', 'juin', 'juil.', 'août', 'sept.', 'oct.', 'nov.', 'déc.'];
  return `Date d'ajout : ${d.getDate()} ${m[d.getMonth()]} ${d.getFullYear()}`;
}

type HeroHandle = { show: (item: VodItem | null) => void };

/** Haut de l'écran : seul ce bloc se redessine quand on change d'affiche. */
const Hero = forwardRef<HeroHandle, { source: XtreamSource; isMovie: boolean; height: number }>(function Hero(
  { source, isMovie, height },
  ref,
) {
  const [item, setItem] = useState<VodItem | null>(null);
  const [info, setInfo] = useState<MovieInfo | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const curId = useRef<string | null>(null);

  useImperativeHandle(ref, () => ({
    show: (it: VodItem | null) => {
      if (timer.current) clearTimeout(timer.current);
      // petit délai : on ne charge la fiche que quand on s'arrête sur une affiche
      timer.current = setTimeout(() => {
        setItem(it);
        curId.current = it ? it.id : null;
        if (!it) return;
        const key = `${isMovie ? 'm' : 's'}${it.id}`;
        const hit = infoCache.get(key);
        setInfo(hit || null);
        if (hit) return;
        (isMovie ? getMovieInfo(source, it.id) : getSeriesInfo(source, it.id).then(s => s.info))
          .then(i => {
            infoCache.set(key, i);
            if (curId.current === it.id) setInfo(i);
          })
          .catch(() => {});
      }, 350);
    },
  }));
  useEffect(() => () => {
    if (timer.current) clearTimeout(timer.current);
  }, []);

  if (!item) {
    return <View style={[StyleSheet.absoluteFill, { backgroundColor: '#070a12' }]} />;
  }
  const img = bigImage(info?.backdrop) || thumb(info?.poster || item.poster, 300);
  const rating = Number(info?.rating || item.rating);
  const meta = [info?.year, info?.genre, info?.duration].filter(Boolean).join('  ·  ');
  return (
    <View style={[StyleSheet.absoluteFill, { backgroundColor: '#070a12' }]}>
      {img ? (
        <Image source={{ uri: img }} style={styles.heroImg} resizeMode="cover" fadeDuration={150} />
      ) : null}
      {/* fondu vers la gauche et vers le bas, pour lire le texte */}
      <View style={styles.fadeLeft} pointerEvents="none">
        {[0.97, 0.9, 0.75, 0.5, 0.2, 0].map((o, i) => (
          <View key={i} style={{ flex: 1, backgroundColor: '#070a12', opacity: o }} />
        ))}
      </View>
      <View style={styles.fadeBottom} pointerEvents="none">
        {[0, 0.25, 0.55, 0.8, 0.95, 1].map((o, i) => (
          <View key={i} style={{ flex: 1, backgroundColor: '#070a12', opacity: o }} />
        ))}
      </View>
      <View style={[styles.heroText, { top: Math.round(height * 0.1) }]}>
        <Text style={styles.heroTitle} numberOfLines={2}>
          {item.name}
        </Text>
        <View style={styles.metaRow}>
          {!!meta && (
            <Text style={styles.meta} numberOfLines={1}>
              {meta}
            </Text>
          )}
          {rating > 0 && (
            <View style={styles.tmdb}>
              <Text style={styles.tmdbText}>TMDB {rating.toFixed(1)}</Text>
            </View>
          )}
        </View>
        {!!item.added && <Text style={styles.added}>{addedLabel(item.added)}</Text>}
        {!!info?.plot && (
          <Text style={styles.plot} numberOfLines={3}>
            {info.plot}
          </Text>
        )}
      </View>
    </View>
  );
});

const Poster = memo(function Poster({
  item,
  index,
  width,
  preferred,
  onPress,
  onFocusItem,
}: {
  item: VodItem;
  index: number;
  width: number;
  preferred: boolean;
  onPress: (i: VodItem) => void;
  onFocusItem: (i: VodItem, index: number) => void;
}) {
  const h = Math.round(width * 1.5);
  return (
    <Focusable
      hasTVPreferredFocus={preferred}
      style={[styles.poster, { width, height: h }]}
      focusedStyle={styles.posterFocused}
      onFocus={() => onFocusItem(item, index)}
      onLongPress={() => longPressFav(item)}
      onPress={() => onPress(item)}>
      {item.poster ? (
        <Image
          source={{ uri: thumb(item.poster, width) }}
          style={{ width: '100%', height: '100%' }}
          resizeMode="cover"
          resizeMethod="resize"
          fadeDuration={0}
        />
      ) : (
        <View style={styles.posterEmpty}>
          <Text style={styles.posterName} numberOfLines={4}>
            {item.name}
          </Text>
        </View>
      )}
    </Focusable>
  );
});

export default function MediaTv({
  source,
  isMovie,
  isFocused,
  categories,
  categoryId,
  catName,
  items,
  loadingText,
  sort,
  setSort,
  search,
  setSearch,
  onOpenCategory,
  onOpen,
  isLocked,
  onPanelChange,
  onNav,
}: {
  source: XtreamSource;
  isMovie: boolean;
  isFocused: boolean;
  categories: Category[];
  categoryId: string | null;
  catName: string;
  items: VodItem[] | null;
  loadingText: string | null;
  sort: TvSort;
  setSort: (s: TvSort) => void;
  search: string;
  setSearch: (s: string) => void;
  onOpenCategory: (id: string, after: () => void) => void;
  onOpen: (i: VodItem) => void;
  isLocked: (id: string) => boolean;
  onPanelChange: (open: boolean) => void;
  onNav: (key: NavKey) => void;
}) {
  const { width, height } = useWindowDimensions();
  // Grandes affiches comme MyTVOnline 4 : 7 par rangée, une rangée bien visible en bas
  const cols = 7;
  const cardW = Math.floor((width - 56) / cols) - 10;
  const gridTop = Math.round(height * 0.5);

  const [panel, setPanel] = useState(false);
  // vrai quand le panneau est ouvert par le bouton Menu : focus sur le menu principal
  const [railFocus, setRailFocus] = useState(false);
  useEffect(() => {
    if (!panel) setRailFocus(false);
  }, [panel]);
  const [sortOpen, setSortOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(!!search);
  const [gridFocus, setGridFocus] = useState(true);
  const hero = useRef<HeroHandle>(null);
  const lastCol = useRef({ col: 0, at: 0 });

  useEffect(() => onPanelChange(panel), [panel, onPanelChange]);

  // Premier titre affiché en haut dès que la liste arrive
  useEffect(() => {
    hero.current?.show(items && items.length ? items[0] : null);
  }, [items]);

  // Retour : ferme d'abord la fenêtre ou le panneau ouvert
  useEffect(() => {
    if (!isFocused || (!panel && !sortOpen && !searchOpen)) return;
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (sortOpen) setSortOpen(false);
      else if (panel) setPanel(false);
      else {
        setSearch('');
        setSearchOpen(false);
      }
      return true;
    });
    return () => sub.remove();
  }, [isFocused, panel, sortOpen, searchOpen, setSearch]);

  // ← sur la 1re colonne : ouvre les groupes
  useTVEventHandler(evt => {
    if (!isFocused || panel || sortOpen) return;
    if (evt?.eventType === 'left' && lastCol.current.col === 0 && Date.now() - lastCol.current.at > 250) {
      setPanel(true);
    }
  });

  // Touches de couleur : rouge = trier, vert = rechercher, jaune = groupes
  useRemoteKeys(key => {
    if (!isFocused) return false;
    if (key === 'red') {
      setSortOpen(true);
      return true;
    }
    if (key === 'green') {
      setSearchOpen(true);
      return true;
    }
    if (key === 'yellow') {
      setPanel(true);
      return true;
    }
    if (key === 'menu') {
      if (panel) setPanel(false);
      else {
        setRailFocus(true);
        setPanel(true);
      }
      return true;
    }
    return false;
  }, isFocused);

  const onFocusItem = useCallback((it: VodItem, index: number) => {
    lastCol.current = { col: index % cols, at: Date.now() };
    hero.current?.show(it);
    setGridFocus(false);
  }, [cols]);
  const openRef = useRef(onOpen);
  openRef.current = onOpen;
  const onPress = useCallback((it: VodItem) => openRef.current(it), []);
  const renderItem = useCallback(
    ({ item, index }: { item: VodItem; index: number }) => (
      <Poster
        item={item}
        index={index}
        width={cardW}
        preferred={gridFocus && index === 0}
        onPress={onPress}
        onFocusItem={onFocusItem}
      />
    ),
    [cardW, gridFocus, onPress, onFocusItem],
  );

  // Liste du tiroir : « Mes groupes » (récents, historique, favoris) puis les groupes du fournisseur
  const rows = React.useMemo(() => {
    const mine = categories.filter(c => c.id.startsWith('__'));
    const prov = categories.filter(c => !c.id.startsWith('__'));
    return [
      { key: 'h1', label: 'Mes groupes' },
      ...mine.map(c => ({ key: c.id, cat: c })),
      { key: 'h2', label: source.name || 'Groupes' },
      ...prov.map(c => ({ key: c.id, cat: c })),
    ] as { key: string; label?: string; cat?: Category }[];
  }, [categories, source.name]);

  return (
    <View style={{ flex: 1, backgroundColor: '#070a12' }}>
      <Hero ref={hero} source={source} isMovie={isMovie} height={height} />

      {/* Barre du haut : groupe + heure */}
      <View style={styles.top} pointerEvents="box-none">
        <Focusable style={styles.groupChip} onPress={() => setPanel(true)}>
          <Text style={styles.chev}>‹</Text>
          <Text style={styles.groupChipText} numberOfLines={1}>
            Groupe : {catName}
          </Text>
        </Focusable>
        <View style={styles.topRight}>
          <Focusable style={styles.toolBtn} onPress={() => setSortOpen(true)}>
            <View style={[styles.keyDot, { backgroundColor: '#e5484d' }]} />
            <Text style={styles.toolText}>Trier : {SORTS.find(s => s.id === sort)?.label}</Text>
          </Focusable>
          <Focusable
            style={styles.toolBtn}
            onPress={() => {
              if (searchOpen) {
                setSearch('');
                setSearchOpen(false);
              } else setSearchOpen(true);
            }}>
            <View style={[styles.keyDot, { backgroundColor: '#30a46c' }]} />
            <Text style={styles.toolText}>{searchOpen ? 'Fermer' : 'Rechercher'}</Text>
          </Focusable>
          <View style={[styles.keyDot, { backgroundColor: '#f5d90a', marginLeft: 6 }]} />
          <Text style={styles.toolText}>Groupes</Text>
          <Clock compact />
        </View>
      </View>

      {/* Rangées d'affiches */}
      <View style={[styles.gridArea, { top: gridTop }]}>
        <View style={styles.labelRow}>
          {searchOpen ? (
            <TextInput
              autoFocus
              value={search}
              onChangeText={setSearch}
              placeholder={isMovie ? 'Chercher un film…' : 'Chercher une série…'}
              placeholderTextColor={colors.muted}
              style={styles.search}
              autoCorrect={false}
            />
          ) : (
            <Text style={styles.label} numberOfLines={1}>
              {catName}
              {items ? <Text style={styles.count}>   {items.length}</Text> : null}
            </Text>
          )}
        </View>
        {loadingText && <Text style={styles.loading}>{loadingText}</Text>}
        {items === null ? (
          <ActivityIndicator color={colors.accent} style={{ marginTop: 30 }} />
        ) : (
          <FlatList
            key={cols}
            data={items}
            numColumns={cols}
            keyExtractor={i => i.id}
            renderItem={renderItem}
            initialNumToRender={cols * 2}
            maxToRenderPerBatch={cols}
            updateCellsBatchingPeriod={60}
            windowSize={3}
            removeClippedSubviews
            contentContainerStyle={{ paddingBottom: 30 }}
            ListEmptyComponent={<Text style={styles.empty}>{search
                  ? 'Aucun résultat.'
                  : categoryId === '__fav__'
                  ? 'Aucun favori. Garde OK enfoncé sur une affiche pour l’ajouter.'
                  : categoryId === '__hist__'
                  ? 'Rien de regardé pour l’instant.'
                  : 'Rien ici.'}</Text>}
          />
        )}
      </View>

      {/* Panneau des groupes : tiroir pleine hauteur à gauche, comme MyTVOnline 4 */}
      {panel && (
        <View style={styles.panelWrap}>
          <FocusTrap style={styles.drawer} horizontal>
            {/* Menu principal de l'app (comme le menu de gauche ailleurs) */}
            <View style={styles.rail}>
              {NAV.map(n => {
                const on = n.key === (isMovie ? 'movies' : 'series');
                return (
                  <Focusable
                    key={n.key}
                    hasTVPreferredFocus={railFocus && on}
                    style={[styles.railBtn, on && styles.railOn]}
                    focusedStyle={styles.railFocused}
                    onPress={() => {
                      if (on) return;
                      setPanel(false);
                      onNav(n.key);
                    }}>
                    <Icon name={n.icon} size={20} color="#fff" />
                    <Text style={styles.railText} numberOfLines={1}>
                      {n.label}
                    </Text>
                  </Focusable>
                );
              })}
            </View>
            <View style={styles.panel}>
              <Text style={styles.provider} numberOfLines={1}>
                Fournisseur : <Text style={{ color: '#fff', fontWeight: '900' }}>{source.name}</Text>
              </Text>
              <FlatList
                data={rows}
                keyExtractor={r => r.key}
                initialScrollIndex={Math.max(0, rows.findIndex(r => r.cat?.id === categoryId) - 3)}
                getItemLayout={(_, i) => ({ length: ROW_H, offset: ROW_H * i, index: i })}
                initialNumToRender={rows.length}
                maxToRenderPerBatch={rows.length}
                windowSize={101}
                removeClippedSubviews={false}
                renderItem={({ item: row }) => {
                  if (!row.cat) {
                    return (
                      <View style={styles.sectionRow}>
                        <Text style={styles.sectionText}>{row.label}</Text>
                        <View style={styles.sectionLine} />
                      </View>
                    );
                  }
                  const c = row.cat;
                  const active = c.id === categoryId;
                  const icon = SPECIAL_ICON[c.id];
                  return (
                    <Focusable
                      hasTVPreferredFocus={active && !railFocus}
                      style={[styles.panelRow, active && styles.panelActive]}
                      focusedStyle={styles.panelFocused}
                      onPress={() =>
                        onOpenCategory(c.id, () => {
                          setPanel(false);
                          setGridFocus(true);
                        })
                      }>
                      {!!icon && <Icon name={icon} size={16} color={active ? '#1a2350' : '#fff'} />}
                      {isLocked(c.id) && <Icon name="lock" size={15} color={colors.danger} />}
                      <Text style={[styles.panelText, active && styles.panelTextActive]} numberOfLines={1}>
                        {c.name}
                      </Text>
                    </Focusable>
                  );
                }}
              />
            </View>
          </FocusTrap>
        </View>
      )}

      {/* Fenêtre de tri */}
      {sortOpen && (
        <View style={styles.sortWrap}>
          <FocusTrap style={styles.sortBox} horizontal>
            <Text style={styles.sortTitle}>Tri</Text>
            {SORTS.map(s => (
              <Focusable
                key={s.id}
                hasTVPreferredFocus={s.id === sort}
                style={[styles.sortRow, s.id === sort && styles.sortActive]}
                focusedStyle={styles.panelFocused}
                onPress={() => {
                  setSort(s.id);
                  setSortOpen(false);
                  setGridFocus(true);
                }}>
                <Text style={styles.sortText}>{s.label}</Text>
                {s.id === sort && <Text style={styles.check}>✓</Text>}
              </Focusable>
            ))}
          </FocusTrap>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  heroImg: { position: 'absolute', right: 0, top: 0, width: '80%', height: '100%' },
  fadeLeft: { position: 'absolute', left: '20%', width: '40%', top: 0, bottom: 0, flexDirection: 'row' },
  fadeBottom: { position: 'absolute', left: 0, right: 0, bottom: 0, height: '62%' },
  heroText: { position: 'absolute', left: 34, width: '48%' },
  heroTitle: { color: '#fff', fontSize: 32, fontWeight: '900', letterSpacing: 0.5 },
  favBadge: { color: colors.star, fontSize: 12, fontWeight: '800', marginTop: 6 },
  metaRow: { flexDirection: 'row', alignItems: 'center', gap: 12, marginTop: 8 },
  meta: { color: 'rgba(235,240,255,0.85)', fontSize: 14, fontWeight: '600', flexShrink: 1 },
  tmdb: { borderWidth: 1, borderColor: 'rgba(255,255,255,0.35)', borderRadius: 6, paddingHorizontal: 6, paddingVertical: 1 },
  tmdbText: { color: '#fff', fontSize: 11, fontWeight: '800' },
  added: { color: colors.muted, fontSize: 12, marginTop: 6 },
  plot: { color: 'rgba(235,240,255,0.85)', fontSize: 13, lineHeight: 19, marginTop: 8 },

  top: {
    position: 'absolute',
    top: 10,
    left: 20,
    right: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  groupChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 14,
    borderWidth: 2,
    borderColor: 'transparent',
    maxWidth: 460,
  },
  chev: { color: '#fff', fontSize: 20, fontWeight: '900', marginTop: -3 },
  groupChipText: { color: 'rgba(235,240,255,0.9)', fontSize: 13, fontWeight: '700' },
  topRight: { flexDirection: 'row', alignItems: 'center', gap: 6 },

  gridArea: { position: 'absolute', left: 0, right: 0, bottom: 0, paddingHorizontal: 28 },
  labelRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 8 },
  label: { color: '#fff', fontSize: 17, fontWeight: '800', flex: 1 },
  count: { color: colors.muted, fontSize: 13, fontWeight: '700' },
  search: {
    flex: 1,
    backgroundColor: colors.panel,
    color: colors.text,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: 14,
    paddingVertical: 6,
    fontSize: 14,
  },
  toolBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 14,
    borderWidth: 2,
    borderColor: 'transparent',
    backgroundColor: 'rgba(7,10,18,0.45)',
  },
  keyDot: { width: 12, height: 9, borderRadius: 2 },
  toolText: { color: colors.text, fontSize: 12, fontWeight: '700' },
  loading: { color: colors.muted, fontSize: 12, marginBottom: 6 },
  empty: { color: colors.muted, fontSize: 15, padding: 12 },

  poster: {
    margin: 5,
    borderRadius: 10,
    overflow: 'hidden',
    borderWidth: 3,
    borderColor: 'transparent',
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  posterFocused: { borderColor: '#ffffff', transform: [{ scale: 1.05 }] },
  posterEmpty: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 6 },
  posterName: { color: colors.text, fontSize: 12, fontWeight: '700', textAlign: 'center' },

  panelWrap: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(28,36,140,0.55)', zIndex: 30 },
  drawer: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    flexDirection: 'row',
  },
  rail: {
    width: 84,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    backgroundColor: 'rgba(10,15,52,0.92)',
  },
  railBtn: {
    width: 72,
    paddingVertical: 7,
    borderRadius: 12,
    alignItems: 'center',
    gap: 3,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  railOn: { backgroundColor: 'rgba(79,140,255,0.35)' },
  railFocused: { backgroundColor: 'rgba(127,176,255,0.30)', borderColor: '#ffffff' },
  railText: { color: '#fff', fontSize: 10, fontWeight: '700' },
  panel: {
    width: 300,
    backgroundColor: 'rgba(16,24,78,0.96)',
    paddingHorizontal: 10,
    paddingTop: 16,
    borderRightWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  provider: { color: 'rgba(235,240,255,0.7)', fontSize: 12, fontWeight: '700', marginLeft: 10, marginBottom: 6 },
  sectionRow: { height: ROW_H, flexDirection: 'row', alignItems: 'flex-end', gap: 8, paddingHorizontal: 10, paddingBottom: 8 },
  sectionText: { color: 'rgba(235,240,255,0.6)', fontSize: 11, fontWeight: '700' },
  sectionLine: { flex: 1, height: 1, backgroundColor: 'rgba(255,255,255,0.18)', marginBottom: 5 },
  panelRow: {
    height: ROW_H - 4,
    marginBottom: 4,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingHorizontal: 12,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  panelActive: { backgroundColor: 'rgba(255,255,255,0.92)' },
  panelFocused: { backgroundColor: 'rgba(127,176,255,0.30)', borderColor: '#ffffff' },
  panelText: { color: colors.text, fontSize: 14, fontWeight: '600', flex: 1 },
  panelTextActive: { color: '#1a2350', fontWeight: '800' },

  sortWrap: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.6)',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 40,
  },
  sortBox: {
    width: 300,
    borderRadius: 20,
    padding: 16,
    backgroundColor: colors.panelSolid,
    borderWidth: 1,
    borderColor: colors.border,
  },
  sortTitle: { color: colors.text, fontSize: 16, fontWeight: '900', textAlign: 'center', marginBottom: 10 },
  sortRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 14,
    paddingVertical: 10,
    marginBottom: 4,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: 'transparent',
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  sortActive: { backgroundColor: 'rgba(79,140,255,0.22)' },
  sortText: { color: colors.text, fontSize: 15, fontWeight: '700' },
  check: { color: '#fff', fontSize: 16, fontWeight: '900' },
});
