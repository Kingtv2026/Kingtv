import { Channel, Source } from './types';

// Liste de chaînes en cours (pour zapper haut/bas dans le lecteur).
// Gardée hors de la navigation pour ne pas passer des milliers
// d'éléments dans les paramètres d'écran.
let queue: Channel[] = [];
let queueSource: Source | null = null;
let queueName = '';

export function setQueue(channels: Channel[], source: Source, name?: string) {
  queue = channels;
  queueSource = source;
  queueName = name || '';
}

export function getQueueName(): string {
  return queueName;
}

export function getQueue(): Channel[] {
  return queue;
}

export function getQueueSource(): Source | null {
  return queueSource;
}

// Dernière chaîne regardée (l'aperçu du guide la remet en marche)
let lastPlayed: Channel | null = null;
export function setLastPlayed(c: Channel | null) {
  lastPlayed = c;
}
export function getLastPlayed(): Channel | null {
  return lastPlayed;
}
