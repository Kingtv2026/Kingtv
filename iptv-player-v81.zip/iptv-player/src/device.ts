import { Dimensions, Platform } from 'react-native';

/**
 * Vrai sur une télé ou un boîtier (Android TV, Formuler, Fire Stick…).
 * Certains boîtiers ne se déclarent pas « télé » auprès d'Android : on regarde
 * aussi l'écran (grand et à l'horizontale = télé ; un cellulaire couché reste un cellulaire).
 */
export function isTVLike(): boolean {
  if (Platform.isTV) return true;
  const { width, height } = Dimensions.get('window');
  return width > height && Math.min(width, height) >= 480;
}
