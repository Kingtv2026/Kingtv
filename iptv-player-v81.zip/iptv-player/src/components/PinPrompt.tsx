import React, { useCallback, useEffect, useState } from 'react';
import { BackHandler, StyleSheet, Text, View } from 'react-native';
import Focusable from './Focusable';
import { colors } from '../theme';
import Icon from './Icon';
import { checkPin, isUnlocked, onParentalChange, unlock } from '../parental';

/** Clavier de code à 4 chiffres (fonctionne au toucher et à la télécommande). */
export function PinPrompt({
  title,
  subtitle,
  onSubmit,
  onCancel,
}: {
  title: string;
  subtitle?: string;
  /** Retourne true si le code est accepté, sinon un message d'erreur. */
  onSubmit: (pin: string) => true | string | Promise<true | string>;
  onCancel: () => void;
}) {
  const [value, setValue] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      onCancel();
      return true;
    });
    return () => sub.remove();
  }, [onCancel]);

  const press = async (k: string) => {
    setError(null);
    if (k === '⌫') {
      setValue(v => v.slice(0, -1));
      return;
    }
    const next = (value + k).slice(0, 4);
    setValue(next);
    if (next.length === 4) {
      const res = await onSubmit(next);
      if (res !== true) {
        setError(res);
        setValue('');
      }
    }
  };

  const keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '✕', '0', '⌫'];

  return (
    <View style={styles.overlay}>
      <View style={styles.box}>
        <Icon name="lock" size={40} color={colors.accent} style={{ alignSelf: 'center', marginBottom: 10 }} />
        <Text style={styles.title}>{title}</Text>
        {!!subtitle && <Text style={styles.sub}>{subtitle}</Text>}
        <View style={styles.dots}>
          {[0, 1, 2, 3].map(i => (
            <View key={i} style={[styles.dot, i < value.length && styles.dotOn]} />
          ))}
        </View>
        <Text style={styles.error}>{error || ' '}</Text>
        <View style={styles.pad}>
          {keys.map((k, i) => (
            <Focusable
              key={k}
              hasTVPreferredFocus={i === 0}
              style={[styles.key, k === '✕' && styles.keyCancel]}
              onPress={() => (k === '✕' ? onCancel() : press(k))}>
              <Text style={styles.keyText}>{k}</Text>
            </Focusable>
          ))}
        </View>
      </View>
    </View>
  );
}

/**
 * Petit outil pour les écrans : `ask(action)` exécute l'action tout de suite si
 * c'est déverrouillé, sinon demande le code d'abord. `prompt` est la fenêtre à afficher.
 */
export function useParentalGate() {
  const [pending, setPending] = useState<(() => void) | null>(null);
  const [, force] = useState(0);
  useEffect(() => onParentalChange(() => force(n => n + 1)), []);

  const ask = useCallback((action: () => void) => {
    if (isUnlocked()) {
      action();
    } else {
      setPending(() => action);
    }
  }, []);

  const prompt = pending ? (
    <PinPrompt
      title="Contenu pour adultes"
      subtitle="Entre le code du contrôle parental"
      onSubmit={p => {
        if (!checkPin(p)) {
          return 'Code incorrect';
        }
        unlock();
        const a = pending;
        setPending(null);
        a();
        return true;
      }}
      onCancel={() => setPending(null)}
    />
  ) : null;

  return { ask, prompt, unlocked: isUnlocked() };
}

const styles = StyleSheet.create({
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.75)',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
    zIndex: 50,
  },
  box: {
    width: '100%',
    maxWidth: 340,
    padding: 22,
    borderRadius: 22,
    backgroundColor: colors.panelSolid,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
  },
  lock: { fontSize: 32 },
  title: { color: colors.text, fontSize: 19, fontWeight: '900', marginTop: 6, textAlign: 'center' },
  sub: { color: colors.muted, fontSize: 13, marginTop: 4, textAlign: 'center' },
  dots: { flexDirection: 'row', gap: 14, marginTop: 18 },
  dot: { width: 16, height: 16, borderRadius: 8, borderWidth: 2, borderColor: colors.muted },
  dotOn: { backgroundColor: colors.accent, borderColor: colors.accent },
  error: { color: colors.danger, fontSize: 13, marginTop: 8, minHeight: 18 },
  pad: { flexDirection: 'row', flexWrap: 'wrap', width: 246, gap: 8, marginTop: 6, justifyContent: 'center' },
  key: {
    width: 74,
    height: 54,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: colors.border,
    backgroundColor: colors.panel,
  },
  keyCancel: { backgroundColor: 'rgba(255,84,112,0.15)' },
  keyText: { color: colors.text, fontSize: 22, fontWeight: '800' },
});
