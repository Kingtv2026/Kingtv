import React from 'react';
import * as RN from 'react-native';
import { StyleProp, View, ViewStyle } from 'react-native';

// Composant de la version télé de React Native (absent sur d'anciennes versions : simple View)
const Guide: any = (RN as any).TVFocusGuideView;

/**
 * Zone d'où la sélection ne sort pas avec ▲▼ (seulement avec ◄►).
 * Empêche la télécommande de « sauter » dans le menu de gauche en descendant une liste.
 */
export default function FocusTrap({
  style,
  children,
  vertical = true,
  horizontal = false,
}: {
  style?: StyleProp<ViewStyle>;
  children?: React.ReactNode;
  vertical?: boolean;
  horizontal?: boolean;
}) {
  if (!Guide) {
    return <View style={style}>{children}</View>;
  }
  return (
    <Guide
      style={style}
      trapFocusUp={vertical}
      trapFocusDown={vertical}
      trapFocusLeft={horizontal}
      trapFocusRight={horizontal}>
      {children}
    </Guide>
  );
}
