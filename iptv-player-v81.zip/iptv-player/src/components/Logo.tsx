import React, { useState } from 'react';
import { Image, Text, View } from 'react-native';
import { colors } from '../theme';
import { useBrand } from '../brand';

/** Logo en haut : celui du revendeur s'il en a un, sinon Ktv. */
export default function Logo({ size = 28 }: { size?: number }) {
  const brand = useBrand();
  const [failed, setFailed] = useState<string | null>(null);

  if (brand.logo && failed !== brand.logo) {
    const h = Math.round(size * 1.4);
    const ratio = brand.w && brand.h ? brand.w / brand.h : 3;
    const w = Math.round(Math.min(Math.max(h * ratio, h), size * 7));
    return (
      <Image
        source={{ uri: brand.logo }}
        style={{ width: w, height: h }}
        resizeMode="contain"
        fadeDuration={0}
        onError={() => setFailed(brand.logo!)}
      />
    );
  }

  // Logo Ktv : « K » blanc, « tv » bleu, point rouge « en direct »
  return (
    <View style={{ flexDirection: 'row', alignItems: 'flex-end' }}>
      <Text style={{ color: '#fff', fontSize: size * 1.15, fontWeight: '900', lineHeight: size * 1.3, includeFontPadding: false }}>
        K
      </Text>
      <Text
        style={{
          color: '#5aa8ff',
          fontSize: size * 0.8,
          fontWeight: '900',
          lineHeight: size * 1.05,
          marginLeft: 1,
          includeFontPadding: false,
        }}>
        tv
      </Text>
      <View
        style={{
          width: size * 0.26,
          height: size * 0.26,
          borderRadius: size * 0.13,
          backgroundColor: colors.live,
          marginLeft: 2,
          alignSelf: 'flex-start',
          marginTop: size * 0.05,
        }}
      />
    </View>
  );
}
