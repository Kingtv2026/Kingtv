import React, { useEffect, useState } from 'react';
import { ActivityIndicator, BackHandler, ScrollView, StyleSheet, Text, View } from 'react-native';
import Focusable from './Focusable';
import Icon from './Icon';
import { colors } from '../theme';
import { formatTime } from '../api/epg';
import { Program } from '../types';
import {
  RecVolume,
  formatSize,
  getPreferredVolume,
  getVolumes,
  recordingSupported,
  startRecording,
} from '../record';

type Props = {
  url: string;
  channel: string;
  /** Émission en cours (enregistrer maintenant) ou à venir (programmer) */
  program?: Program | null;
  onClose: () => void;
  onDone: (message: string) => void;
};

type Choice = { key: string; label: string; sub?: string; startAt: number; endAt: number; title: string; padding?: boolean };

export default function RecordSheet({ url, channel, program, onClose, onDone }: Props) {
  const [vols, setVols] = useState<RecVolume[] | null>(null);
  const [vol, setVol] = useState<RecVolume | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    getVolumes().then(async v => {
      setVols(v);
      setVol(await getPreferredVolume(v));
    });
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      onClose();
      return true;
    });
    return () => sub.remove();
  }, [onClose]);

  const now = Date.now();
  const future = !!program && program.start > now;
  const choices: Choice[] = [];
  if (program && program.end > now) {
    choices.push({
      key: 'prog',
      label: future ? `Programmer « ${program.title} »` : `Jusqu’à la fin de « ${program.title} »`,
      sub: future
        ? `${dayLabel(program.start)} ${formatTime(program.start)} — ${formatTime(program.end)}`
        : `Fin à ${formatTime(program.end)} (+3 min de marge)`,
      startAt: program.start,
      endAt: program.end,
      title: program.title,
      padding: true,
    });
  }
  if (!future) {
    for (const [min, label] of [
      [30, '30 minutes'],
      [60, '1 heure'],
      [120, '2 heures'],
      [180, '3 heures'],
    ] as const) {
      choices.push({ key: `m${min}`, label, startAt: now, endAt: now + min * 60000, title: program?.title || channel });
    }
  }

  const go = async (c: Choice) => {
    if (!vol) return;
    setBusy(true);
    setErr(null);
    try {
      await startRecording({ url, channel, title: c.title, startAt: c.startAt, endAt: c.endAt, volume: vol, padding: c.padding });
      onDone(
        c.startAt > Date.now() + 5000
          ? `Enregistrement programmé : ${c.title}, ${dayLabel(c.startAt)} à ${formatTime(c.startAt)}`
          : `Enregistrement lancé sur ${vol.label}`,
      );
    } catch (e: any) {
      setErr(e?.message || 'Impossible de lancer l’enregistrement.');
      setBusy(false);
    }
  };

  return (
    <View style={styles.overlay}>
      <View style={styles.box}>
        <View style={styles.head}>
          <Icon name="record" size={26} color={colors.live} />
          <View style={{ flex: 1, marginLeft: 12 }}>
            <Text style={styles.title}>Enregistrer</Text>
            <Text style={styles.sub} numberOfLines={1}>
              {channel}
            </Text>
          </View>
        </View>

        {!recordingSupported ? (
          <Text style={styles.err}>Cette version de l’app ne peut pas enregistrer. Fais la mise à jour.</Text>
        ) : !vols ? (
          <ActivityIndicator color={colors.accent} style={{ margin: 20 }} />
        ) : vols.length === 0 ? (
          <Text style={styles.err}>Aucun espace de stockage disponible sur cet appareil.</Text>
        ) : (
          <ScrollView style={{ maxHeight: 420 }} contentContainerStyle={{ gap: 8 }}>
            <Text style={styles.section}>Où enregistrer</Text>
            <View style={styles.vols}>
              {vols.map(v => {
                const on = vol?.path === v.path;
                return (
                  <Focusable key={v.path} style={[styles.vol, on && styles.volOn]} onPress={() => setVol(v)}>
                    <Icon name={v.removable ? 'usb' : 'tv'} size={20} color={on ? '#fff' : colors.muted} />
                    <View style={{ marginLeft: 8 }}>
                      <Text style={styles.volName} numberOfLines={1}>
                        {v.label}
                      </Text>
                      <Text style={styles.volFree}>{formatSize(v.free)} libres</Text>
                    </View>
                  </Focusable>
                );
              })}
            </View>
            {vols.length === 1 && (
              <Text style={styles.hint}>Branche une clé USB pour pouvoir l’utiliser (elle apparaîtra ici).</Text>
            )}

            <Text style={styles.section}>{future ? 'Programmation' : 'Durée'}</Text>
            {choices.map((c, i) => (
              <Focusable
                key={c.key}
                hasTVPreferredFocus={i === 0}
                disabled={busy}
                style={[styles.choice, i === 0 && styles.choiceMain]}
                onPress={() => go(c)}>
                <Icon name={c.startAt > now + 5000 ? 'clock' : 'record'} size={20} color={i === 0 ? '#fff' : colors.live} />
                <View style={{ flex: 1, marginLeft: 12 }}>
                  <Text style={styles.choiceText} numberOfLines={1}>
                    {c.label}
                  </Text>
                  {!!c.sub && <Text style={styles.choiceSub}>{c.sub}</Text>}
                </View>
              </Focusable>
            ))}
          </ScrollView>
        )}

        {!!err && <Text style={styles.err}>{err}</Text>}
        {busy && <ActivityIndicator color={colors.accent} style={{ marginTop: 10 }} />}

        <Focusable style={styles.cancel} onPress={onClose}>
          <Text style={styles.cancelText}>Annuler</Text>
        </Focusable>
      </View>
    </View>
  );
}

function dayLabel(ms: number): string {
  const d = new Date(ms);
  const today = new Date();
  const tomorrow = new Date(Date.now() + 86400000);
  if (d.toDateString() === today.toDateString()) return 'aujourd’hui';
  if (d.toDateString() === tomorrow.toDateString()) return 'demain';
  const days = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'];
  return `${days[d.getDay()]} ${d.getDate()}`;
}

const styles = StyleSheet.create({
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.75)',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
    zIndex: 60,
  },
  box: {
    width: '100%',
    maxWidth: 480,
    padding: 20,
    borderRadius: 22,
    backgroundColor: colors.panelSolid,
    borderWidth: 1,
    borderColor: colors.border,
  },
  head: { flexDirection: 'row', alignItems: 'center', marginBottom: 6 },
  title: { color: colors.text, fontSize: 20, fontWeight: '900' },
  sub: { color: colors.muted, fontSize: 13, marginTop: 2 },
  section: { color: colors.muted, fontSize: 12, fontWeight: '800', letterSpacing: 1, marginTop: 10, textTransform: 'uppercase' },
  vols: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  vol: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 9,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: colors.border,
    backgroundColor: colors.panel,
    maxWidth: 220,
  },
  volOn: { borderColor: colors.accent, backgroundColor: 'rgba(79,140,255,0.25)' },
  volName: { color: colors.text, fontSize: 14, fontWeight: '800' },
  volFree: { color: colors.muted, fontSize: 11 },
  hint: { color: colors.muted, fontSize: 12 },
  choice: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 14,
    paddingVertical: 12,
    borderRadius: 14,
    backgroundColor: colors.panelAlt,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  choiceMain: { backgroundColor: colors.live },
  choiceText: { color: colors.text, fontSize: 15, fontWeight: '800' },
  choiceSub: { color: 'rgba(255,255,255,0.75)', fontSize: 12, marginTop: 2 },
  err: { color: colors.danger, fontSize: 14, marginTop: 12, textAlign: 'center' },
  cancel: {
    marginTop: 14,
    alignSelf: 'center',
    paddingHorizontal: 26,
    paddingVertical: 10,
    borderRadius: 12,
    backgroundColor: colors.panel,
    borderWidth: 2,
    borderColor: colors.border,
  },
  cancelText: { color: colors.text, fontSize: 15, fontWeight: '800' },
});
