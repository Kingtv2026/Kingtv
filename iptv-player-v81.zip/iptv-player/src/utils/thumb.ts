import { PixelRatio } from 'react-native';

/**
 * Version légère d'une affiche pour les grilles : les fournisseurs envoient souvent
 * l'image originale de TMDB (lourde à télécharger et à décoder sur un boîtier).
 * On demande la taille juste assez grande pour la carte affichée.
 */
export function thumb(url: string | undefined, widthDp: number): string | undefined {
  if (!url) return url;
  const px = widthDp * PixelRatio.get();
  const size = px <= 160 ? 'w154' : px <= 200 ? 'w185' : px <= 360 ? 'w342' : 'w500';
  return url.replace(/(image\.tmdb\.org\/t\/p\/)(original|w\d+(?:_and_h\d+[^/]*)?)(\/)/, `$1${size}$3`);
}
