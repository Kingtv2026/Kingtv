import { Linking } from 'react-native';

/** Ouvre la bande-annonce dans l'app YouTube (ou le navigateur si elle n'est pas installée). */
export async function openTrailer(id: string): Promise<boolean> {
  const urls = [`vnd.youtube:${id}`, `https://www.youtube.com/watch?v=${id}`];
  for (const u of urls) {
    try {
      await Linking.openURL(u);
      return true;
    } catch {}
  }
  return false;
}
