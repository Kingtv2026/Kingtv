import AsyncStorage from '@react-native-async-storage/async-storage';
import { useEffect, useState } from 'react';

/** Logo du vendeur (revendeur) envoyé par le panneau. Vide = logo Kingtv. */
export interface Brand {
  /** Nom du vendeur affiché aux clients (ex. « Oh-Ben TV ») */
  name?: string;
  logo?: string;
  w?: number;
  h?: number;
}

const K_BRAND = 'iptv.brand';
let current: Brand = {};
const listeners = new Set<(b: Brand) => void>();

export async function loadBrand() {
  try {
    const raw = await AsyncStorage.getItem(K_BRAND);
    if (raw) {
      current = JSON.parse(raw) || {};
      listeners.forEach(l => l(current));
    }
  } catch {}
}

export async function setBrand(b: any) {
  const next: Brand = {};
  if (b && typeof b.logo === 'string' && /^https?:\/\//.test(b.logo)) {
    next.logo = b.logo;
    next.w = Number(b.w) || undefined;
    next.h = Number(b.h) || undefined;
  }
  if (b && typeof b.name === 'string' && b.name.trim()) {
    next.name = b.name.trim().slice(0, 40);
  }
  if (JSON.stringify(next) === JSON.stringify(current)) return;
  current = next;
  listeners.forEach(l => l(current));
  try {
    await AsyncStorage.setItem(K_BRAND, JSON.stringify(next));
  } catch {}
}

export function useBrand(): Brand {
  const [b, setB] = useState<Brand>(current);
  useEffect(() => {
    listeners.add(setB);
    setB(current);
    return () => {
      listeners.delete(setB);
    };
  }, []);
  return b;
}

/** Nom à afficher : celui du vendeur, sinon Ktv. */
export function brandName(b: Brand): string {
  return b.name || 'Ktv';
}
