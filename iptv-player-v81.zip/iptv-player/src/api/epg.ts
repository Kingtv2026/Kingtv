import { Channel, Program, Source } from '../types';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getFullEpg, getShortEpg } from './xtream';

const TTL = 5 * 60 * 1000;
const cache = new Map<string, { at: number; data: Program[] }>();

/** Émission en cours + suivante pour une chaîne (vide si non disponible). */
export async function getNowNext(source: Source, channel: Channel): Promise<Program[]> {
  if (source.type !== 'xtream') {
    return []; // Guide XMLTV pour les listes M3U : version suivante
  }
  const key = `${source.id}:${channel.id}`;
  const hit = cache.get(key);
  const now = Date.now();
  if (hit && now - hit.at < TTL) {
    return hit.data.filter(p => p.end > now).slice(0, 2);
  }
  try {
    const data = await getShortEpg(source, channel.id, 4);
    cache.set(key, { at: now, data });
    return data.filter(p => p.end > now).slice(0, 2);
  } catch {
    return [];
  }
}

export function formatTime(ms: number): string {
  const d = new Date(ms);
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}

export function progressOf(p: Program): number {
  const now = Date.now();
  return Math.min(1, Math.max(0, (now - p.start) / (p.end - p.start)));
}

// ---------- Guide en grille : plusieurs heures par chaîne ----------
const fullCache = new Map<string, { at: number; data: Program[] }>();
const inflight = new Map<string, Promise<Program[]>>();

export function getPrograms(source: Source, channel: Channel): Promise<Program[]> {
  if (source.type !== 'xtream') {
    return Promise.resolve([]);
  }
  const key = `${source.id}:${channel.id}`;
  const hit = fullCache.get(key);
  if (hit && Date.now() - hit.at < 15 * 60 * 1000) {
    return Promise.resolve(hit.data);
  }
  const running = inflight.get(key);
  if (running) {
    return running;
  }
  // Guide complet (émissions passées incluses) ; version courte si le serveur ne le fournit pas
  const p = getFullEpg(source, channel.id)
    .then(list => {
      // on garde seulement d'hier à demain pour ménager la mémoire
      const from = Date.now() - 26 * 3600 * 1000;
      const to = Date.now() + 26 * 3600 * 1000;
      const kept = cleanPrograms(list.filter(x => x.end > from && x.start < to));
      return kept.length ? kept : getShortEpg(source, channel.id, 24).then(cleanPrograms);
    })
    .catch(() => getShortEpg(source, channel.id, 24).then(cleanPrograms))
    .catch(() => [] as Program[])
    .then(data => {
      fullCache.set(key, { at: Date.now(), data });
      inflight.delete(key);
      return data;
    });
  inflight.set(key, p);
  return p;
}

/**
 * Nettoie la liste d'un fournisseur : retire les doublons et les émissions
 * qui chevauchent la précédente (certains guides mélangent deux horaires).
 */
export function cleanPrograms(list: Program[]): Program[] {
  const sorted = [...list].sort((a, b) => a.start - b.start || b.end - a.end);
  const out: Program[] = [];
  const TOL = 2 * 60 * 1000;
  for (const p of sorted) {
    const prev = out[out.length - 1];
    if (!prev) {
      out.push(p);
      continue;
    }
    if (p.start >= prev.end) {
      out.push(p);
    } else if (p.start >= prev.end - TOL && p.end > prev.end) {
      // petit chevauchement : on raccourcit la précédente
      out[out.length - 1] = { ...prev, end: p.start };
      out.push(p);
    }
    // sinon : doublon ou chevauchement important → ignoré
  }
  return out;
}

// ---------- Affichage rapide du guide ----------
// 1) copie sur l'appareil (instantané), 2) émissions à venir (petite requête rapide),
// 3) guide complet avec les émissions passées (plus lourd, arrive ensuite).
const DISK_FRESH = 45 * 60 * 1000;
const DISK_MAX_AGE = 8 * 3600 * 1000;
const DISK_MAX_CHANNELS = 150;
const INDEX_KEY = 'iptv.epg.index';
const epgKey = (source: Source, channel: Channel) => `iptv.epg.${source.id}.${channel.id}`;

async function readEpgDisk(k: string): Promise<{ at: number; data: Program[] } | null> {
  try {
    const raw = await AsyncStorage.getItem(k);
    if (!raw) return null;
    const v = JSON.parse(raw);
    return Date.now() - v.at < DISK_MAX_AGE ? v : null;
  } catch {
    return null;
  }
}

let indexChain: Promise<void> = Promise.resolve();
function writeEpgDisk(k: string, data: Program[]) {
  const now = Date.now();
  // on garde de 6 h avant à 24 h après, descriptions raccourcies (place limitée)
  const slim = data
    .filter(p => p.end > now - 6 * 3600 * 1000 && p.start < now + 24 * 3600 * 1000)
    .map(p => ({ ...p, description: (p.description || '').slice(0, 280) }));
  indexChain = indexChain.then(async () => {
    try {
      await AsyncStorage.setItem(k, JSON.stringify({ at: now, data: slim }));
      const idx: string[] = JSON.parse((await AsyncStorage.getItem(INDEX_KEY)) || '[]').filter((x: string) => x !== k);
      idx.push(k);
      const drop = idx.length > DISK_MAX_CHANNELS ? idx.splice(0, idx.length - DISK_MAX_CHANNELS) : [];
      if (drop.length) await AsyncStorage.multiRemove(drop);
      await AsyncStorage.setItem(INDEX_KEY, JSON.stringify(idx));
    } catch {}
  });
}

// Pas plus de 2 guides complets téléchargés en même temps (les plus récents d'abord)
let running = 0;
const waiting: (() => void)[] = [];
async function limited<T>(job: () => Promise<T>, stillWanted: () => boolean): Promise<T> {
  if (running >= 2) {
    await new Promise<void>(res => waiting.unshift(res));
  }
  running++;
  try {
    if (!stillWanted()) return [] as any;
    return await job();
  } finally {
    running--;
    waiting.shift()?.();
  }
}

/**
 * Donne le guide d'une chaîne le plus vite possible, puis la version complète.
 * `cb` peut être appelé plusieurs fois. Retourne une fonction pour arrêter.
 */
export function watchPrograms(source: Source, channel: Channel, cb: (p: Program[]) => void): () => void {
  let alive = true;
  let gotFull = false;
  const send = (d: Program[]) => alive && cb(d);
  if (source.type !== 'xtream') {
    send([]);
    return () => {};
  }
  const key = `${source.id}:${channel.id}`;
  const hit = fullCache.get(key);
  if (hit && Date.now() - hit.at < 15 * 60 * 1000) {
    send(hit.data);
    return () => {
      alive = false;
    };
  }
  const k = epgKey(source, channel);
  (async () => {
    // on attend que la ligne reste à l'écran (pas pendant un défilement rapide)
    await new Promise(res => setTimeout(res, 300));
    if (!alive) return;
    const disk = await readEpgDisk(k);
    if (disk && disk.data.length) {
      send(disk.data);
      if (Date.now() - disk.at < DISK_FRESH) {
        fullCache.set(key, { at: disk.at, data: disk.data });
        return;
      }
    } else {
      getShortEpg(source, channel.id, 10)
        .then(cleanPrograms)
        .then(d => {
          if (!gotFull && d.length) send(d);
        })
        .catch(() => {});
    }
    const full = await limited(() => getPrograms(source, channel), () => alive);
    if (!alive) return;
    gotFull = true;
    if (full.length || !disk) send(full);
    if (full.length) writeEpgDisk(k, full);
  })().catch(() => send([]));
  return () => {
    alive = false;
  };
}

export function clearEpgCache() {
  cache.clear();
  fullCache.clear();
  inflight.clear();
  indexChain = indexChain.then(async () => {
    try {
      const idx: string[] = JSON.parse((await AsyncStorage.getItem(INDEX_KEY)) || '[]');
      await AsyncStorage.multiRemove([...idx, INDEX_KEY]);
    } catch {}
  });
}
