import { Playlist, Source } from '../types';
import { loadM3u } from './m3u';
import { loadXtream } from './xtream';
import { clearEpgCache } from './epg';
import { clearCatalog } from './catalog';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Garde la liste en mémoire 10 min (évite de tout recharger entre la TV en direct et le guide)
const cache = new Map<string, { at: number; data: Playlist }>();

export async function loadPlaylist(source: Source): Promise<Playlist> {
  const hit = cache.get(source.id);
  if (hit && Date.now() - hit.at < 10 * 60 * 1000) {
    return hit.data;
  }
  const data = source.type === 'xtream' ? await loadXtream(source) : await loadM3u(source);
  cache.set(source.id, { at: Date.now(), data });
  return data;
}

/** Oublie le contenu en mémoire : la prochaine ouverture recharge tout du serveur. */
export function clearCaches(sourceId?: string) {
  if (sourceId) {
    cache.delete(sourceId);
    AsyncStorage.removeItem(`iptv.home.${sourceId}`).catch(() => {});
  } else {
    cache.clear();
  }
  clearEpgCache();
  clearCatalog(sourceId);
}
