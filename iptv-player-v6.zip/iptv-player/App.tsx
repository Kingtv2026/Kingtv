import React from 'react';
import { StatusBar } from 'react-native';
import { StackNavigator } from './src/nav/Navigator';
import SourcesScreen from './src/screens/SourcesScreen';
import AddSourceScreen from './src/screens/AddSourceScreen';
import HomeScreen from './src/screens/HomeScreen';
import ChannelsScreen from './src/screens/ChannelsScreen';
import MediaScreen from './src/screens/MediaScreen';
import MovieDetailScreen from './src/screens/MovieDetailScreen';
import SeriesDetailScreen from './src/screens/SeriesDetailScreen';
import PlayerScreen from './src/screens/PlayerScreen';
import { colors } from './src/theme';

export default function App() {
  return (
    <>
      <StatusBar barStyle="light-content" backgroundColor={colors.bg} />
      <StackNavigator
        initial="Sources"
        screens={{
          Sources: { component: SourcesScreen, headerShown: false },
          AddSource: { component: AddSourceScreen, title: 'Nouvelle liste' },
          Home: { component: HomeScreen, headerShown: false },
          Channels: { component: ChannelsScreen },
          Media: { component: MediaScreen },
          MovieDetail: { component: MovieDetailScreen },
          SeriesDetail: { component: SeriesDetailScreen },
          Player: { component: PlayerScreen, headerShown: false },
        }}
      />
    </>
  );
}
