import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  Image,
  StyleSheet,
  Text,
  TextInput,
  useWindowDimensions,
  View,
} from 'react-native';
import { ScreenProps } from '../nav/Navigator';
import Focusable from '../components/Focusable';
import {
  getSeries,
  getSeriesCategories,
  getVodCategories,
  getVodStreams,
} from '../api/xtream';
import { colors } from '../theme';
import { Category, VodItem } from '../types';

type Props = ScreenProps<'Media'>;

const CARD_W = 150;

export default function MediaScreen({ route, navigation }: Props) {
  const { source, kind } = route.params;
  const { width } = useWindowDimensions();
  const wide = width >= 700;

  const [categories, setCategories] = useState<Category[] | null>(null);
  const [categoryId, setCategoryId] = useState<string | null>(null);
  const [items, setItems] = useState<VodItem[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const cache = useRef(new Map<string, VodItem[]>());

  useEffect(() => {
    navigation.setOptions({ title: kind === 'movie' ? 'Films' : 'Séries' });
    (kind === 'movie' ? getVodCategories(source) : getSeriesCategories(source))
      .then(cats => {
        setCategories(cats);
        if (cats.length > 0) {
          setCategoryId(cats[0].id);
        } else {
          setItems([]);
        }
      })
      .catch(e => setError(e?.message || 'Chargement impossible'));
  }, [kind, navigation, source]);

  // Charge la catégorie choisie (petit délai pour ne pas tout charger en défilant)
  useEffect(() => {
    if (!categoryId) {
      return;
    }
    const cached = cache.current.get(categoryId);
    if (cached) {
      setItems(cached);
      return;
    }
    setItems(null);
    let cancelled = false;
    const t = setTimeout(async () => {
      try {
        const list =
          kind === 'movie'
            ? await getVodStreams(source, categoryId)
            : await getSeries(source, categoryId);
        cache.current.set(categoryId, list);
        if (!cancelled) {
          setItems(list);
        }
      } catch (e: any) {
        if (!cancelled) {
          setError(e?.message || 'Chargement impossible');
        }
      }
    }, 350);
    return () => {
      cancelled = true;
      clearTimeout(t);
    };
  }, [categoryId, kind, source]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return !items ? [] : q ? items.filter(i => i.name.toLowerCase().includes(q)) : items;
  }, [items, search]);

  const paneWidth = wide ? width - 280 : width;
  const cols = Math.max(2, Math.floor((paneWidth - 24) / (CARD_W + 16)));

  const open = (item: VodItem) => {
    if (kind === 'movie') {
      navigation.navigate('MovieDetail', { source, item });
    } else {
      navigation.navigate('SeriesDetail', { source, item });
    }
  };

  if (error) {
    return (
      <View style={styles.center}>
        <Text style={styles.error}>{error}</Text>
      </View>
    );
  }

  if (!categories) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={colors.accent} />
      </View>
    );
  }

  return (
    <View style={[styles.container, wide && { flexDirection: 'row' }]}>
      <FlatList
        data={categories}
        horizontal={!wide}
        keyExtractor={c => c.id}
        style={wide ? styles.catColumn : styles.catBar}
        showsHorizontalScrollIndicator={false}
        renderItem={({ item, index }) => (
          <Focusable
            hasTVPreferredFocus={index === 0}
            style={[
              wide ? styles.catRow : styles.catChip,
              item.id === categoryId && styles.catActive,
            ]}
            onFocus={() => wide && setCategoryId(item.id)}
            onPress={() => setCategoryId(item.id)}>
            <Text
              style={[styles.catText, item.id === categoryId && { color: '#fff', fontWeight: '800' }]}
              numberOfLines={1}>
              {item.name}
            </Text>
          </Focusable>
        )}
      />

      <View style={styles.gridPane}>
        <TextInput
          value={search}
          onChangeText={setSearch}
          placeholder={kind === 'movie' ? '🔍  Rechercher un film' : '🔍  Rechercher une série'}
          placeholderTextColor={colors.muted}
          style={styles.search}
          autoCorrect={false}
        />
        {items === null ? (
          <ActivityIndicator color={colors.accent} style={{ marginTop: 40 }} />
        ) : (
          <FlatList
            key={cols}
            data={filtered}
            numColumns={cols}
            keyExtractor={i => i.id}
            initialNumToRender={cols * 3}
            windowSize={7}
            ListEmptyComponent={<Text style={styles.muted}>Rien ici.</Text>}
            renderItem={({ item }) => (
              <Focusable
                style={styles.card}
                scale={1.08}
                onPress={() => open(item)}>
                {item.poster ? (
                  <Image source={{ uri: item.poster }} style={styles.poster} resizeMode="cover" />
                ) : (
                  <View style={[styles.poster, styles.posterEmpty]}>
                    <Text style={styles.posterLetter}>{item.name.charAt(0)}</Text>
                  </View>
                )}
                {Number(item.rating) > 0 && (
                  <View style={styles.rating}>
                    <Text style={styles.ratingText}>★ {Number(item.rating).toFixed(1)}</Text>
                  </View>
                )}
                <Text style={styles.cardName} numberOfLines={2}>
                  {item.name}
                </Text>
              </Focusable>
            )}
          />
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  error: { color: colors.danger, fontSize: 16, padding: 24, textAlign: 'center' },
  muted: { color: colors.muted, fontSize: 15, padding: 12 },
  catColumn: { width: 270, flexGrow: 0, paddingLeft: 16 },
  catBar: { flexGrow: 0, paddingVertical: 8, paddingHorizontal: 16 },
  catRow: {
    paddingHorizontal: 14,
    paddingVertical: 11,
    marginBottom: 4,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  catChip: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginRight: 8,
    borderRadius: 20,
    borderWidth: 2,
    borderColor: colors.border,
    backgroundColor: colors.panel,
  },
  catActive: { backgroundColor: 'rgba(79,140,255,0.18)', borderColor: 'rgba(79,140,255,0.45)' },
  catText: { color: colors.text, fontSize: 15 },
  gridPane: { flex: 1, paddingHorizontal: 12 },
  search: {
    backgroundColor: colors.panel,
    color: colors.text,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: 16,
    paddingVertical: 10,
    marginHorizontal: 8,
    marginBottom: 8,
    fontSize: 15,
  },
  card: {
    width: CARD_W,
    margin: 8,
    padding: 4,
    borderRadius: 14,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  poster: { width: CARD_W - 12, height: (CARD_W - 12) * 1.5, borderRadius: 10 },
  posterEmpty: { backgroundColor: colors.panelAlt, alignItems: 'center', justifyContent: 'center' },
  posterLetter: { color: colors.muted, fontSize: 40, fontWeight: '900' },
  rating: {
    position: 'absolute',
    top: 10,
    right: 10,
    backgroundColor: 'rgba(0,0,0,0.72)',
    borderRadius: 8,
    paddingHorizontal: 6,
    paddingVertical: 2,
  },
  ratingText: { color: colors.star, fontSize: 12, fontWeight: '800' },
  cardName: { color: colors.text, fontSize: 13, fontWeight: '600', marginTop: 8, marginHorizontal: 2 },
});
