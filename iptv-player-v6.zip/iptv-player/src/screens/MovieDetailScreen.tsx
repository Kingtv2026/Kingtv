import React, { useEffect, useState } from 'react';
import { ActivityIndicator, ScrollView, StyleSheet, Text } from 'react-native';
import { ScreenProps } from '../nav/Navigator';
import DetailHeader from '../components/DetailHeader';
import Focusable from '../components/Focusable';
import { getMovieInfo } from '../api/xtream';
import { colors } from '../theme';
import { MovieInfo } from '../types';

type Props = ScreenProps<'MovieDetail'>;

export default function MovieDetailScreen({ route, navigation }: Props) {
  const { source, item } = route.params;
  const [info, setInfo] = useState<MovieInfo | null>(null);

  useEffect(() => {
    navigation.setOptions({ title: item.name });
    getMovieInfo(source, item.id)
      .then(setInfo)
      .catch(() => setInfo({}));
  }, [item, navigation, source]);

  const play = () => {
    if (item.url) {
      navigation.navigate('Player', { vod: { url: item.url, title: item.name } });
    }
  };

  return (
    <ScrollView style={styles.container}>
      {info === null ? (
        <ActivityIndicator color={colors.accent} style={{ marginTop: 60 }} />
      ) : (
        <DetailHeader title={item.name} info={info} fallbackPoster={item.poster}>
          <Focusable hasTVPreferredFocus scale={1.06} style={styles.play} onPress={play}>
            <Text style={styles.playText}>▶   Regarder</Text>
          </Focusable>
        </DetailHeader>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  play: {
    marginTop: 24,
    alignSelf: 'flex-start',
    backgroundColor: colors.accent,
    borderWidth: 2,
    borderColor: colors.accent,
    borderRadius: 14,
    paddingHorizontal: 36,
    paddingVertical: 14,
  },
  playText: { color: '#fff', fontSize: 18, fontWeight: '900', letterSpacing: 0.5 },
});
