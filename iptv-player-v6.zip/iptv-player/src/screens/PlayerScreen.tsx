import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Image,
  Platform,
  Pressable,
  StatusBar,
  StyleSheet,
  Text,
  useTVEventHandler,
  View,
} from 'react-native';
import Video from 'react-native-video';
import { ScreenProps } from '../nav/Navigator';
import { getNowNext } from '../api/epg';
import NowNext from '../components/NowNext';
import Logo from '../components/Logo';
import Clock from '../components/Clock';
import { getQueue, getQueueSource } from '../playerQueue';
import { colors } from '../theme';
import { Program } from '../types';

type Props = ScreenProps<'Player'>;

export default function PlayerScreen({ route }: Props) {
  const vod = route.params.vod;
  const isLive = !vod;

  const queue = getQueue();
  const source = getQueueSource();
  const [index, setIndex] = useState(route.params.index ?? 0);
  const [buffering, setBuffering] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [overlay, setOverlay] = useState(true);
  const [epg, setEpg] = useState<Program[]>([]);
  const hideTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const channel = isLive ? queue[index] : undefined;
  const url = vod ? vod.url : channel?.streamUrl;
  const title = vod ? vod.title : channel?.name;

  const showOverlay = useCallback(() => {
    setOverlay(true);
    if (hideTimer.current) {
      clearTimeout(hideTimer.current);
    }
    hideTimer.current = setTimeout(() => setOverlay(false), 5000);
  }, []);

  const zap = useCallback(
    (delta: number) => {
      if (!isLive || queue.length === 0) {
        return;
      }
      setIndex(i => (i + delta + queue.length) % queue.length);
      setError(null);
      setBuffering(true);
      showOverlay();
    },
    [isLive, queue.length, showOverlay],
  );

  useEffect(() => {
    showOverlay();
    return () => {
      if (hideTimer.current) {
        clearTimeout(hideTimer.current);
      }
    };
  }, [showOverlay]);

  // Guide horaire de la chaîne en cours
  useEffect(() => {
    if (!channel || !source) {
      return;
    }
    let cancelled = false;
    setEpg([]);
    getNowNext(source, channel).then(data => {
      if (!cancelled) {
        setEpg(data);
      }
    });
    return () => {
      cancelled = true;
    };
  }, [channel, source]);

  // Télécommande (direct seulement) : haut/bas = changer de chaîne, OK = infos.
  // En film/série, les contrôles natifs du lecteur gèrent la télécommande.
  useTVEventHandler(evt => {
    if (!evt || !isLive) {
      return;
    }
    if (evt.eventType === 'up' || evt.eventType === 'channelUp') {
      zap(-1);
    } else if (evt.eventType === 'down' || evt.eventType === 'channelDown') {
      zap(1);
    } else if (evt.eventType === 'select') {
      showOverlay();
    }
  });

  if (!url) {
    return (
      <View style={styles.container}>
        <Text style={styles.errorText}>Rien à lire.</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <StatusBar hidden />
      <Video
        key={url}
        source={{ uri: url }}
        style={StyleSheet.absoluteFill}
        resizeMode="contain"
        controls={!isLive}
        onLoad={() => setBuffering(false)}
        onBuffer={({ isBuffering }) => setBuffering(isBuffering)}
        onError={() => {
          setBuffering(false);
          setError(
            isLive
              ? 'Cette chaîne ne joue pas en ce moment.'
              : 'Impossible de lire ce contenu.',
          );
        }}
        bufferConfig={{
          minBufferMs: 5000,
          maxBufferMs: 30000,
          bufferForPlaybackMs: 1500,
          bufferForPlaybackAfterRebufferMs: 3000,
        }}
      />

      {/* Zone tactile (téléphone, direct) pour afficher les infos */}
      {isLive && (
        <Pressable
          style={StyleSheet.absoluteFill}
          onPress={showOverlay}
          focusable={false}
        />
      )}

      {buffering && !error && (
        <ActivityIndicator size="large" color={colors.accent} style={styles.spinner} />
      )}

      {error && (
        <View style={styles.errorBox}>
          <Text style={styles.errorText}>{error}</Text>
        </View>
      )}

      {overlay && isLive && (
        <>
          <View style={styles.topBar} pointerEvents="none">
            <Logo size={22} />
            <Clock />
          </View>
          <View style={styles.overlay} pointerEvents="box-none">
            <View style={styles.info}>
              <View style={styles.infoHead}>
                <View style={styles.logoBox}>
                  {channel?.logo ? (
                    <Image source={{ uri: channel.logo }} style={styles.logo} resizeMode="contain" />
                  ) : (
                    <Text style={styles.logoLetter}>{(title || '?').charAt(0)}</Text>
                  )}
                </View>
                <Text style={styles.number}>{index + 1}</Text>
                <View style={{ flex: 1 }}>
                  <Text style={styles.name} numberOfLines={1}>
                    {title}
                  </Text>
                  <View style={styles.livePill}>
                    <View style={styles.liveDot} />
                    <Text style={styles.liveText}>EN DIRECT</Text>
                  </View>
                </View>
              </View>
              {epg.length > 0 && <NowNext programs={epg} />}
            </View>
            {!Platform.isTV && (
              <View style={styles.zapButtons}>
                <Pressable style={styles.zapBtn} onPress={() => zap(-1)}>
                  <Text style={styles.zapText}>▲</Text>
                </Pressable>
                <Pressable style={styles.zapBtn} onPress={() => zap(1)}>
                  <Text style={styles.zapText}>▼</Text>
                </Pressable>
              </View>
            )}
          </View>
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000', justifyContent: 'center' },
  spinner: { position: 'absolute', alignSelf: 'center' },
  errorBox: {
    position: 'absolute',
    alignSelf: 'center',
    backgroundColor: 'rgba(7,10,18,0.85)',
    padding: 18,
    borderRadius: 14,
  },
  errorText: { color: colors.text, fontSize: 16, textAlign: 'center' },
  topBar: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    paddingHorizontal: 28,
    paddingVertical: 18,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'rgba(7,10,18,0.55)',
  },
  overlay: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    padding: 24,
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
  },
  info: {
    flex: 1,
    maxWidth: 760,
    backgroundColor: 'rgba(7,10,18,0.82)',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
    paddingHorizontal: 22,
    paddingVertical: 18,
  },
  infoHead: { flexDirection: 'row', alignItems: 'center', marginBottom: 14 },
  logoBox: {
    width: 72,
    height: 50,
    borderRadius: 10,
    backgroundColor: 'rgba(255,255,255,0.08)',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 14,
    overflow: 'hidden',
  },
  logo: { width: '86%', height: '86%' },
  logoLetter: { color: colors.muted, fontSize: 22, fontWeight: '900' },
  number: { color: colors.accent, fontSize: 28, fontWeight: '900', marginRight: 14 },
  name: { color: '#fff', fontSize: 22, fontWeight: '800' },
  livePill: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 4 },
  liveDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: colors.live },
  liveText: { color: colors.live, fontSize: 11, fontWeight: '900', letterSpacing: 1 },
  zapButtons: { gap: 12, marginLeft: 14 },
  zapBtn: {
    backgroundColor: 'rgba(7,10,18,0.82)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
    width: 56,
    height: 56,
    borderRadius: 28,
    alignItems: 'center',
    justifyContent: 'center',
  },
  zapText: { color: '#fff', fontSize: 20 },
});
