import React from 'react';
import { Image, StyleSheet, Text, View } from 'react-native';
import { colors } from '../theme';
import { MovieInfo } from '../types';

/** Grande fiche film/série : image de fond, affiche, titre, infos, résumé. */
export default function DetailHeader({
  title,
  info,
  fallbackPoster,
  children,
}: {
  title: string;
  info: MovieInfo;
  fallbackPoster?: string;
  children?: React.ReactNode;
}) {
  const poster = info.poster || fallbackPoster;
  const backdrop = info.backdrop || poster;
  const genres = (info.genre || '')
    .split(/[,/]/)
    .map(g => g.trim())
    .filter(Boolean)
    .slice(0, 3);
  const chips = [info.year, ...genres, info.duration].filter(Boolean) as string[];
  const rating = Number(info.rating);

  return (
    <View style={styles.hero}>
      {backdrop && (
        <Image source={{ uri: backdrop }} style={styles.backdrop} resizeMode="cover" blurRadius={info.backdrop ? 0 : 12} />
      )}
      <View style={[StyleSheet.absoluteFill, { backgroundColor: 'rgba(7,10,18,0.62)' }]} />
      {/* Fondu vers le bas */}
      <View style={styles.fade} pointerEvents="none">
        {[0.15, 0.3, 0.5, 0.7, 0.88, 1].map((o, i) => (
          <View key={i} style={{ flex: 1, backgroundColor: colors.bg, opacity: o }} />
        ))}
      </View>

      <View style={styles.row}>
        {poster ? (
          <Image source={{ uri: poster }} style={styles.poster} />
        ) : (
          <View style={[styles.poster, { backgroundColor: colors.panelAlt }]} />
        )}
        <View style={styles.text}>
          <Text style={styles.title}>{title}</Text>

          <View style={styles.chips}>
            {rating > 0 && (
              <View style={[styles.chip, styles.ratingChip]}>
                <Text style={styles.ratingText}>★ {rating.toFixed(1)}</Text>
              </View>
            )}
            {chips.map((c, i) => (
              <View key={i} style={styles.chip}>
                <Text style={styles.chipText}>{c}</Text>
              </View>
            ))}
          </View>

          {!!info.plot && (
            <Text style={styles.plot} numberOfLines={5}>
              {info.plot}
            </Text>
          )}
          {!!info.director && (
            <Text style={styles.small}>
              <Text style={styles.smallLabel}>Réalisation  </Text>
              {info.director}
            </Text>
          )}
          {!!info.cast && (
            <Text style={styles.small} numberOfLines={2}>
              <Text style={styles.smallLabel}>Avec  </Text>
              {info.cast}
            </Text>
          )}
          {children}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  hero: { paddingHorizontal: 28, paddingTop: 24, paddingBottom: 36, overflow: 'hidden' },
  backdrop: { ...StyleSheet.absoluteFillObject, opacity: 0.55 },
  fade: { position: 'absolute', left: 0, right: 0, bottom: 0, height: 180 },
  row: { flexDirection: 'row', flexWrap: 'wrap', gap: 28 },
  poster: {
    width: 200,
    height: 300,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.15)',
  },
  text: { flex: 1, minWidth: 280, justifyContent: 'center' },
  title: { color: '#fff', fontSize: 36, fontWeight: '900', letterSpacing: 0.3 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 12 },
  chip: {
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 4,
    backgroundColor: 'rgba(255,255,255,0.12)',
  },
  chipText: { color: colors.text, fontSize: 13, fontWeight: '600' },
  ratingChip: { backgroundColor: 'rgba(255,201,60,0.18)' },
  ratingText: { color: colors.star, fontSize: 13, fontWeight: '900' },
  plot: { color: 'rgba(244,246,251,0.9)', fontSize: 16, lineHeight: 24, marginTop: 16 },
  small: { color: colors.text, fontSize: 14, marginTop: 10 },
  smallLabel: { color: colors.muted, fontWeight: '700' },
});
