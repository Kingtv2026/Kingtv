/**
 * Applique les réglages Android nécessaires au projet généré :
 *  - flux http:// autorisés (aussi en version release)
 *  - Android TV (leanback, pas d'écran tactile requis, bannière)
 *
 * Usage : node scripts/patch-android.js <dossier-du-projet>
 */
const fs = require('fs');
const path = require('path');

const root = path.resolve(process.argv[2] || '.');
const here = path.resolve(__dirname, '..');

// ---------- AndroidManifest.xml ----------
const manifestPath = path.join(root, 'android/app/src/main/AndroidManifest.xml');
let m = fs.readFileSync(manifestPath, 'utf8');

if (/android:usesCleartextTraffic="[^"]*"/.test(m)) {
  m = m.replace(/android:usesCleartextTraffic="[^"]*"/, 'android:usesCleartextTraffic="true"');
} else {
  m = m.replace('<application', '<application\n      android:usesCleartextTraffic="true"');
}

for (const feature of ['android.software.leanback', 'android.hardware.touchscreen']) {
  if (!m.includes(feature)) {
    m = m.replace(
      '<application',
      `<uses-feature android:name="${feature}" android:required="false" />\n    <application`,
    );
  }
}

if (!m.includes('LEANBACK_LAUNCHER')) {
  m = m.replace(
    '<category android:name="android.intent.category.LAUNCHER" />',
    '<category android:name="android.intent.category.LAUNCHER" />\n        <category android:name="android.intent.category.LEANBACK_LAUNCHER" />',
  );
}

const banner = path.join(here, 'assets/banner.png');
if (fs.existsSync(banner)) {
  const drawable = path.join(root, 'android/app/src/main/res/drawable');
  fs.mkdirSync(drawable, { recursive: true });
  fs.copyFileSync(banner, path.join(drawable, 'banner.png'));
  if (!m.includes('android:banner')) {
    m = m.replace('<application', '<application\n      android:banner="@drawable/banner"');
  }
}

fs.writeFileSync(manifestPath, m);
console.log('AndroidManifest.xml modifié');

// ---------- Nom de l'app ----------
const APP_NAME = 'Kingtv';
const stringsPath = path.join(root, 'android/app/src/main/res/values/strings.xml');
if (fs.existsSync(stringsPath)) {
  let x = fs.readFileSync(stringsPath, 'utf8');
  x = x.replace(/<string name="app_name">[^<]*<\/string>/, `<string name="app_name">${APP_NAME}</string>`);
  fs.writeFileSync(stringsPath, x);
  console.log(`Nom de l'app : ${APP_NAME}`);
}

// ---------- Icône ----------
const res = path.join(root, 'android/app/src/main/res');
const iconDir = path.join(here, 'assets/icon');
if (fs.existsSync(iconDir)) {
  for (const d of ['mdpi', 'hdpi', 'xhdpi', 'xxhdpi', 'xxxhdpi']) {
    const dest = path.join(res, `mipmap-${d}`);
    fs.mkdirSync(dest, { recursive: true });
    fs.copyFileSync(path.join(iconDir, `ic_launcher-${d}.png`), path.join(dest, 'ic_launcher.png'));
    fs.copyFileSync(path.join(iconDir, `ic_launcher_round-${d}.png`), path.join(dest, 'ic_launcher_round.png'));
  }
  // Une icône « adaptative » du gabarit passerait par-dessus la nôtre
  fs.rmSync(path.join(res, 'mipmap-anydpi-v26'), { recursive: true, force: true });
  fs.rmSync(path.join(res, 'mipmap-anydpi'), { recursive: true, force: true });
  console.log('Icône remplacée');
}
