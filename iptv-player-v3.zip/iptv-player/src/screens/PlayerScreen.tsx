import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Platform,
  Pressable,
  StatusBar,
  StyleSheet,
  Text,
  useTVEventHandler,
  View,
} from 'react-native';
import Video from 'react-native-video';
import { ScreenProps } from '../nav/Navigator';
import { getNowNext } from '../api/epg';
import NowNext from '../components/NowNext';
import { getQueue, getQueueSource } from '../playerQueue';
import { colors } from '../theme';
import { Program } from '../types';

type Props = ScreenProps<'Player'>;

export default function PlayerScreen({ route }: Props) {
  const vod = route.params.vod;
  const isLive = !vod;

  const queue = getQueue();
  const source = getQueueSource();
  const [index, setIndex] = useState(route.params.index ?? 0);
  const [buffering, setBuffering] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [overlay, setOverlay] = useState(true);
  const [epg, setEpg] = useState<Program[]>([]);
  const hideTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const channel = isLive ? queue[index] : undefined;
  const url = vod ? vod.url : channel?.streamUrl;
  const title = vod ? vod.title : channel?.name;

  const showOverlay = useCallback(() => {
    setOverlay(true);
    if (hideTimer.current) {
      clearTimeout(hideTimer.current);
    }
    hideTimer.current = setTimeout(() => setOverlay(false), 5000);
  }, []);

  const zap = useCallback(
    (delta: number) => {
      if (!isLive || queue.length === 0) {
        return;
      }
      setIndex(i => (i + delta + queue.length) % queue.length);
      setError(null);
      setBuffering(true);
      showOverlay();
    },
    [isLive, queue.length, showOverlay],
  );

  useEffect(() => {
    showOverlay();
    return () => {
      if (hideTimer.current) {
        clearTimeout(hideTimer.current);
      }
    };
  }, [showOverlay]);

  // Guide horaire de la chaîne en cours
  useEffect(() => {
    if (!channel || !source) {
      return;
    }
    let cancelled = false;
    setEpg([]);
    getNowNext(source, channel).then(data => {
      if (!cancelled) {
        setEpg(data);
      }
    });
    return () => {
      cancelled = true;
    };
  }, [channel, source]);

  // Télécommande (direct seulement) : haut/bas = changer de chaîne, OK = infos.
  // En film/série, les contrôles natifs du lecteur gèrent la télécommande.
  useTVEventHandler(evt => {
    if (!evt || !isLive) {
      return;
    }
    if (evt.eventType === 'up' || evt.eventType === 'channelUp') {
      zap(-1);
    } else if (evt.eventType === 'down' || evt.eventType === 'channelDown') {
      zap(1);
    } else if (evt.eventType === 'select') {
      showOverlay();
    }
  });

  if (!url) {
    return (
      <View style={styles.container}>
        <Text style={styles.errorText}>Rien à lire.</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <StatusBar hidden />
      <Video
        key={url}
        source={{ uri: url }}
        style={StyleSheet.absoluteFill}
        resizeMode="contain"
        controls={!isLive}
        onLoad={() => setBuffering(false)}
        onBuffer={({ isBuffering }) => setBuffering(isBuffering)}
        onError={() => {
          setBuffering(false);
          setError(
            isLive
              ? 'Cette chaîne ne joue pas en ce moment.'
              : 'Impossible de lire ce contenu.',
          );
        }}
        bufferConfig={{
          minBufferMs: 5000,
          maxBufferMs: 30000,
          bufferForPlaybackMs: 1500,
          bufferForPlaybackAfterRebufferMs: 3000,
        }}
      />

      {/* Zone tactile (téléphone, direct) pour afficher les infos */}
      {isLive && (
        <Pressable
          style={StyleSheet.absoluteFill}
          onPress={showOverlay}
          focusable={false}
        />
      )}

      {buffering && !error && (
        <ActivityIndicator size="large" color={colors.accent} style={styles.spinner} />
      )}

      {error && (
        <View style={styles.errorBox}>
          <Text style={styles.errorText}>{error}</Text>
        </View>
      )}

      {overlay && isLive && (
        <View style={styles.overlay} pointerEvents="box-none">
          <View style={styles.info}>
            <View style={styles.infoHead}>
              <Text style={styles.number}>{index + 1}</Text>
              <Text style={styles.name} numberOfLines={1}>
                {title}
              </Text>
            </View>
            {epg.length > 0 && <NowNext programs={epg} />}
          </View>
          {!Platform.isTV && (
            <View style={styles.zapButtons}>
              <Pressable style={styles.zapBtn} onPress={() => zap(-1)}>
                <Text style={styles.zapText}>▲</Text>
              </Pressable>
              <Pressable style={styles.zapBtn} onPress={() => zap(1)}>
                <Text style={styles.zapText}>▼</Text>
              </Pressable>
            </View>
          )}
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000', justifyContent: 'center' },
  spinner: { position: 'absolute', alignSelf: 'center' },
  errorBox: {
    position: 'absolute',
    alignSelf: 'center',
    backgroundColor: 'rgba(0,0,0,0.75)',
    padding: 16,
    borderRadius: 8,
  },
  errorText: { color: colors.text, fontSize: 16, textAlign: 'center' },
  overlay: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
  },
  info: {
    backgroundColor: 'rgba(0,0,0,0.75)',
    borderRadius: 10,
    paddingHorizontal: 18,
    paddingVertical: 14,
    flexShrink: 1,
    maxWidth: 620,
  },
  infoHead: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  number: { color: colors.accent, fontSize: 22, fontWeight: '700', marginRight: 12 },
  name: { color: '#fff', fontSize: 20, fontWeight: '600', flexShrink: 1 },
  zapButtons: { gap: 10, marginLeft: 12 },
  zapBtn: {
    backgroundColor: 'rgba(0,0,0,0.7)',
    width: 52,
    height: 52,
    borderRadius: 26,
    alignItems: 'center',
    justifyContent: 'center',
  },
  zapText: { color: '#fff', fontSize: 20 },
});
