import React, { useEffect, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  Image,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { ScreenProps } from '../nav/Navigator';
import DetailHeader from '../components/DetailHeader';
import Focusable from '../components/Focusable';
import { getSeriesInfo } from '../api/xtream';
import { colors } from '../theme';
import { SeriesInfo } from '../types';

type Props = ScreenProps<'SeriesDetail'>;

export default function SeriesDetailScreen({ route, navigation }: Props) {
  const { source, item } = route.params;
  const [data, setData] = useState<SeriesInfo | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [seasonIdx, setSeasonIdx] = useState(0);

  useEffect(() => {
    navigation.setOptions({ title: item.name });
    getSeriesInfo(source, item.id)
      .then(setData)
      .catch(e => setError(e?.message || 'Chargement impossible'));
  }, [item, navigation, source]);

  if (error) {
    return (
      <View style={styles.center}>
        <Text style={styles.error}>{error}</Text>
      </View>
    );
  }
  if (!data) {
    return (
      <View style={styles.center}>
        <ActivityIndicator color={colors.accent} size="large" />
      </View>
    );
  }

  const season = data.seasons[seasonIdx];

  return (
    <ScrollView style={styles.container}>
      <DetailHeader title={item.name} info={data.info} fallbackPoster={item.poster} />

      {data.seasons.length === 0 ? (
        <Text style={styles.muted}>Aucun épisode disponible.</Text>
      ) : (
        <View style={styles.body}>
          <FlatList
            horizontal
            data={data.seasons}
            keyExtractor={s => String(s.number)}
            showsHorizontalScrollIndicator={false}
            style={{ flexGrow: 0, marginBottom: 12 }}
            renderItem={({ item: s, index }) => (
              <Focusable
                hasTVPreferredFocus={index === 0}
                style={[styles.chip, index === seasonIdx && styles.chipActive]}
                onFocus={() => setSeasonIdx(index)}
                onPress={() => setSeasonIdx(index)}>
                <Text style={styles.chipText}>Saison {s.number}</Text>
              </Focusable>
            )}
          />

          {season?.episodes.map(ep => (
            <Focusable
              key={ep.id}
              style={styles.episode}
              onPress={() =>
                navigation.navigate('Player', {
                  vod: {
                    url: ep.url,
                    title: `${item.name} – S${season.number}E${ep.num} ${ep.title}`,
                  },
                })
              }>
              {ep.image ? (
                <Image source={{ uri: ep.image }} style={styles.thumb} />
              ) : (
                <View style={[styles.thumb, styles.thumbEmpty]}>
                  <Text style={styles.thumbNum}>{ep.num}</Text>
                </View>
              )}
              <View style={{ flex: 1 }}>
                <Text style={styles.epTitle} numberOfLines={1}>
                  {ep.num}. {ep.title}
                </Text>
                {!!ep.duration && <Text style={styles.epMeta}>{ep.duration}</Text>}
                {!!ep.plot && (
                  <Text style={styles.epPlot} numberOfLines={2}>
                    {ep.plot}
                  </Text>
                )}
              </View>
            </Focusable>
          ))}
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  center: { flex: 1, backgroundColor: colors.bg, alignItems: 'center', justifyContent: 'center' },
  error: { color: colors.danger, fontSize: 16, padding: 24 },
  muted: { color: colors.muted, padding: 24 },
  body: { paddingHorizontal: 24, paddingBottom: 40 },
  chip: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginRight: 8,
    borderRadius: 18,
    borderWidth: 2,
    borderColor: colors.border,
    backgroundColor: colors.panel,
  },
  chipActive: { backgroundColor: colors.accent, borderColor: colors.accent },
  chipText: { color: colors.text, fontSize: 15, fontWeight: '600' },
  episode: {
    flexDirection: 'row',
    gap: 14,
    alignItems: 'center',
    padding: 10,
    marginBottom: 8,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: 'transparent',
    backgroundColor: colors.panel,
  },
  thumb: { width: 160, height: 90, borderRadius: 6 },
  thumbEmpty: { backgroundColor: colors.panelAlt, alignItems: 'center', justifyContent: 'center' },
  thumbNum: { color: colors.muted, fontSize: 28, fontWeight: '700' },
  epTitle: { color: colors.text, fontSize: 16, fontWeight: '600' },
  epMeta: { color: colors.muted, fontSize: 13, marginTop: 2 },
  epPlot: { color: colors.muted, fontSize: 13, marginTop: 4 },
});
