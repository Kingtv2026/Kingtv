import React from 'react';
import { Image, StyleSheet, Text, View } from 'react-native';
import { colors } from '../theme';
import { MovieInfo } from '../types';

/** Affiche, titre, année, genre, durée, note et résumé d'un film ou d'une série. */
export default function DetailHeader({
  title,
  info,
  fallbackPoster,
  children,
}: {
  title: string;
  info: MovieInfo;
  fallbackPoster?: string;
  children?: React.ReactNode;
}) {
  const poster = info.poster || fallbackPoster;
  const meta = [info.year, info.genre, info.duration, info.rating && `★ ${info.rating}`]
    .filter(Boolean)
    .join('  ·  ');

  return (
    <View style={styles.wrap}>
      {info.backdrop && (
        <Image source={{ uri: info.backdrop }} style={styles.backdrop} blurRadius={2} />
      )}
      <View style={styles.row}>
        {poster ? (
          <Image source={{ uri: poster }} style={styles.poster} />
        ) : (
          <View style={[styles.poster, { backgroundColor: colors.panelAlt }]} />
        )}
        <View style={styles.text}>
          <Text style={styles.title}>{title}</Text>
          {!!meta && <Text style={styles.meta}>{meta}</Text>}
          {!!info.plot && (
            <Text style={styles.plot} numberOfLines={6}>
              {info.plot}
            </Text>
          )}
          {!!info.director && <Text style={styles.small}>Réalisation : {info.director}</Text>}
          {!!info.cast && (
            <Text style={styles.small} numberOfLines={2}>
              Avec : {info.cast}
            </Text>
          )}
          {children}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { padding: 24 },
  backdrop: { ...StyleSheet.absoluteFillObject, opacity: 0.18 },
  row: { flexDirection: 'row', flexWrap: 'wrap', gap: 24 },
  poster: { width: 180, height: 270, borderRadius: 10 },
  text: { flex: 1, minWidth: 260 },
  title: { color: colors.text, fontSize: 28, fontWeight: '800' },
  meta: { color: colors.muted, fontSize: 15, marginTop: 6 },
  plot: { color: colors.text, fontSize: 15, lineHeight: 22, marginTop: 14 },
  small: { color: colors.muted, fontSize: 13, marginTop: 8 },
});
