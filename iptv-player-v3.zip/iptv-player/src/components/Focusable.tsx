import React, { useState } from 'react';
import { Pressable, PressableProps, StyleProp, ViewStyle } from 'react-native';
import { colors } from '../theme';

type Props = Omit<PressableProps, 'style'> & {
  style?: StyleProp<ViewStyle>;
  focusedStyle?: StyleProp<ViewStyle>;
  children?: React.ReactNode;
};

/**
 * Bouton qui s'illumine quand il a le focus de la télécommande (Android TV),
 * et se comporte comme un bouton normal au toucher sur téléphone.
 */
export default function Focusable({
  style,
  focusedStyle,
  onFocus,
  onBlur,
  children,
  ...rest
}: Props) {
  const [focused, setFocused] = useState(false);
  return (
    <Pressable
      {...rest}
      onFocus={e => {
        setFocused(true);
        onFocus?.(e);
      }}
      onBlur={e => {
        setFocused(false);
        onBlur?.(e);
      }}
      style={({ pressed }) => [
        style,
        (focused || pressed) && {
          borderColor: colors.focus,
          backgroundColor: colors.panelAlt,
        },
        focused && focusedStyle,
      ]}>
      {children}
    </Pressable>
  );
}
