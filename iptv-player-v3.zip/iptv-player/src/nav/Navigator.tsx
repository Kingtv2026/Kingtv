/**
 * Petite navigation « pile d'écrans » en JavaScript pur (aucun code natif).
 * Remplace react-navigation / react-native-screens, qui posaient problème
 * avec la version TV de React Native.
 */
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { BackHandler, Pressable, StyleSheet, Text, View } from 'react-native';
import { colors } from '../theme';
import { RootStackParamList } from '../navigation';

type RouteName = keyof RootStackParamList;

export interface Nav {
  navigate<N extends RouteName>(name: N, params?: RootStackParamList[N]): void;
  replace<N extends RouteName>(name: N, params?: RootStackParamList[N]): void;
  goBack(): void;
  setOptions(options: { title?: string }): void;
}

export type ScreenProps<N extends RouteName> = {
  navigation: Nav;
  route: { name: N; params: RootStackParamList[N] };
};

export interface ScreenConfig {
  component: React.ComponentType<any>;
  title?: string;
  headerShown?: boolean;
}

interface Entry {
  key: string;
  name: RouteName;
  params: any;
  title?: string;
}

const FocusContext = createContext(true);

/** Vrai quand l'écran est celui du dessus. */
export function useIsFocused(): boolean {
  return useContext(FocusContext);
}

/** Exécute `effect` chaque fois que l'écran redevient visible. */
export function useFocusEffect(effect: () => void | (() => void)) {
  const focused = useIsFocused();
  useEffect(() => {
    if (focused) {
      return effect();
    }
  }, [focused, effect]);
}

let keyCounter = 0;
const newKey = () => `s${++keyCounter}`;

export function StackNavigator({
  screens,
  initial,
}: {
  screens: Record<RouteName, ScreenConfig>;
  initial: RouteName;
}) {
  const [stack, setStack] = useState<Entry[]>([
    { key: newKey(), name: initial, params: undefined },
  ]);
  const stackRef = useRef(stack);
  stackRef.current = stack;

  const push = useCallback((name: RouteName, params?: any) => {
    setStack(s => [...s, { key: newKey(), name, params }]);
  }, []);
  const replaceTop = useCallback((name: RouteName, params?: any) => {
    setStack(s => [...s.slice(0, -1), { key: newKey(), name, params }]);
  }, []);
  const pop = useCallback(() => {
    setStack(s => (s.length > 1 ? s.slice(0, -1) : s));
  }, []);
  const setTitle = useCallback((key: string, title?: string) => {
    setStack(s => s.map(e => (e.key === key ? { ...e, title } : e)));
  }, []);

  // Bouton « Retour » du téléphone ou de la télécommande
  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (stackRef.current.length > 1) {
        pop();
        return true;
      }
      return false; // dernier écran : on laisse Android fermer l'app
    });
    return () => sub.remove();
  }, [pop]);

  return (
    <View style={styles.root}>
      {stack.map((entry, i) => (
        <ScreenHost
          key={entry.key}
          entry={entry}
          config={screens[entry.name]}
          focused={i === stack.length - 1}
          canGoBack={i > 0}
          push={push}
          replaceTop={replaceTop}
          pop={pop}
          setTitle={setTitle}
        />
      ))}
    </View>
  );
}

function ScreenHost({
  entry,
  config,
  focused,
  canGoBack,
  push,
  replaceTop,
  pop,
  setTitle,
}: {
  entry: Entry;
  config: ScreenConfig;
  focused: boolean;
  canGoBack: boolean;
  push: (n: RouteName, p?: any) => void;
  replaceTop: (n: RouteName, p?: any) => void;
  pop: () => void;
  setTitle: (key: string, title?: string) => void;
}) {
  const navigation: Nav = useMemo(
    () => ({
      navigate: (name, params) => push(name, params),
      replace: (name, params) => replaceTop(name, params),
      goBack: pop,
      setOptions: ({ title }) => setTitle(entry.key, title),
    }),
    [entry.key, push, replaceTop, pop, setTitle],
  );
  const route = useMemo(
    () => ({ name: entry.name, params: entry.params }),
    [entry.name, entry.params],
  );
  const Component = config.component;
  const title = entry.title ?? config.title ?? '';

  return (
    // Les écrans du dessous restent montés (on garde leur état) mais cachés
    <View style={[StyleSheet.absoluteFill, !focused && styles.hidden]}>
      <FocusContext.Provider value={focused}>
        {config.headerShown !== false && (
          <View style={styles.header}>
            {canGoBack && (
              <Pressable onPress={pop} focusable={false} style={styles.back} hitSlop={12}>
                <Text style={styles.backText}>‹</Text>
              </Pressable>
            )}
            <Text style={styles.title} numberOfLines={1}>
              {title}
            </Text>
          </View>
        )}
        <View style={styles.body}>
          <Component navigation={navigation} route={route} />
        </View>
      </FocusContext.Provider>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  hidden: { display: 'none' },
  header: {
    height: 56,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    backgroundColor: colors.panel,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  back: { paddingHorizontal: 10, paddingVertical: 4, marginRight: 4 },
  backText: { color: colors.text, fontSize: 32, lineHeight: 34 },
  title: { color: colors.text, fontSize: 19, fontWeight: '700', flex: 1 },
  body: { flex: 1 },
});
