export const colors = {
  bg: '#0e1116',
  panel: '#171b22',
  panelAlt: '#1f2530',
  border: '#2a3140',
  text: '#e8ecf2',
  muted: '#8a94a6',
  accent: '#3b82f6',
  focus: '#3b82f6',
  danger: '#ef4444',
  star: '#facc15',
};
