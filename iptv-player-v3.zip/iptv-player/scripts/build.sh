#!/usr/bin/env bash
# Construit l'APK : crée le projet React Native TV, ajoute le code de l'app, compile.
# Lancé par GitHub Actions (voir .github/workflows/build-apk.yml).
set -euo pipefail

HERE="$(cd "$(dirname "$0")/.." && pwd)"   # dossier du code de l'app
WORK="${GITHUB_WORKSPACE:-$PWD}"
cd "$WORK"

rm -rf build-app
npx --yes @react-native-community/cli@latest init IptvPlayer \
  --template @react-native-tvos/template-tv \
  --directory build-app \
  --skip-git-init \
  --install-pods false \
  --pm npm

cd build-app
echo "Version de React Native :"
node -p "require('react-native/package.json').version"

# Seulement deux librairies natives, versions majeures fixées
npm install react-native-video@^6 @react-native-async-storage/async-storage@^2

cp "$HERE/App.tsx" ./App.tsx
rm -rf src && cp -r "$HERE/src" ./src
node "$HERE/scripts/patch-android.js" .

cd android
chmod +x gradlew
./gradlew assembleRelease --no-daemon
