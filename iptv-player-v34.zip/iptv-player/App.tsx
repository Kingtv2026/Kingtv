import React from 'react';
import { StatusBar } from 'react-native';
import { StackNavigator } from './src/nav/Navigator';
import ErrorBoundary from './src/components/ErrorBoundary';
import UpdateGate from './src/components/UpdateDialog';
import { loadPrefs } from './src/prefs';
import { loadParental } from './src/parental';

loadPrefs();
loadParental();
import SourcesScreen from './src/screens/SourcesScreen';
import AddSourceScreen from './src/screens/AddSourceScreen';
import HomeScreen from './src/screens/HomeScreen';
import ChannelsScreen from './src/screens/ChannelsScreen';
import MediaScreen from './src/screens/MediaScreen';
import MovieDetailScreen from './src/screens/MovieDetailScreen';
import SeriesDetailScreen from './src/screens/SeriesDetailScreen';
import PlayerScreen from './src/screens/PlayerScreen';
import GuideScreen from './src/screens/GuideScreen';
import CatchupScreen from './src/screens/CatchupScreen';
import SettingsScreen from './src/screens/SettingsScreen';
import SearchScreen from './src/screens/SearchScreen';
import ActivationScreen from './src/screens/ActivationScreen';
import { licensingEnabled } from './src/license';
import { CAT_FAVORITES } from './src/types';

export default function App() {
  return (
    <ErrorBoundary>
      <StatusBar hidden />
      <StackNavigator
        initial={licensingEnabled() ? 'Activation' : 'Sources'}
        screens={{
          Activation: { component: ActivationScreen, headerShown: false },
          Sources: { component: SourcesScreen, headerShown: false },
          AddSource: { component: AddSourceScreen, title: 'Nouvelle liste' },
          Home: { component: HomeScreen, headerShown: false, tab: () => 'home' },
          Channels: {
            component: ChannelsScreen,
            tab: p => (p?.initialCategory === CAT_FAVORITES ? 'favs' : 'live'),
          },
          Guide: { component: GuideScreen, title: 'Guide TV' },
          Catchup: { component: CatchupScreen, title: 'Rattrapage' },
          Settings: { component: SettingsScreen, title: 'Paramètres' },
          Search: { component: SearchScreen, title: 'Recherche' },
          Media: { component: MediaScreen, tab: p => (p?.kind === 'movie' ? 'movies' : 'series') },
          MovieDetail: { component: MovieDetailScreen },
          SeriesDetail: { component: SeriesDetailScreen },
          Player: { component: PlayerScreen, headerShown: false, fullscreen: true },
        }}
      />
      <UpdateGate />
    </ErrorBoundary>
  );
}
