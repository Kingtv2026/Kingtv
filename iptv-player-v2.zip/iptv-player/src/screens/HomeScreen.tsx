import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, useWindowDimensions, View } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import Focusable from '../components/Focusable';
import { xtreamLogin } from '../api/xtream';
import { colors } from '../theme';
import { RootStackParamList } from '../navigation';

type Props = NativeStackScreenProps<RootStackParamList, 'Home'>;

export default function HomeScreen({ route, navigation }: Props) {
  const { source } = route.params;
  const { width } = useWindowDimensions();
  const wide = width >= 700;
  const [expiry, setExpiry] = useState<string | null>(null);

  useEffect(() => {
    navigation.setOptions({ title: source.name });
    xtreamLogin(source)
      .then(data => {
        const exp = Number(data?.user_info?.exp_date);
        if (exp > 0) {
          const d = new Date(exp * 1000);
          setExpiry(
            `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(
              d.getDate(),
            ).padStart(2, '0')}`,
          );
        }
      })
      .catch(() => {});
  }, [navigation, source]);

  const tiles = [
    { key: 'live', label: 'TV en direct', icon: '📺', go: () => navigation.navigate('Channels', { source }) },
    { key: 'movie', label: 'Films', icon: '🎬', go: () => navigation.navigate('Media', { source, kind: 'movie' }) },
    { key: 'series', label: 'Séries', icon: '🍿', go: () => navigation.navigate('Media', { source, kind: 'series' }) },
  ];

  return (
    <View style={styles.container}>
      <View style={[styles.tiles, !wide && { flexDirection: 'column' }]}>
        {tiles.map((t, i) => (
          <Focusable
            key={t.key}
            hasTVPreferredFocus={i === 0}
            style={[styles.tile, !wide && styles.tileNarrow]}
            focusedStyle={{ transform: [{ scale: 1.05 }] }}
            onPress={t.go}>
            <Text style={styles.icon}>{t.icon}</Text>
            <Text style={styles.label}>{t.label}</Text>
          </Focusable>
        ))}
      </View>
      {expiry && <Text style={styles.expiry}>Abonnement valide jusqu’au {expiry}</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg, justifyContent: 'center', padding: 24 },
  tiles: { flexDirection: 'row', justifyContent: 'center', gap: 24 },
  tile: {
    width: 220,
    height: 180,
    borderRadius: 14,
    borderWidth: 3,
    borderColor: colors.border,
    backgroundColor: colors.panel,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tileNarrow: { width: '100%', height: 110 },
  icon: { fontSize: 44 },
  label: { color: colors.text, fontSize: 20, fontWeight: '700', marginTop: 10 },
  expiry: { color: colors.muted, textAlign: 'center', marginTop: 28, fontSize: 14 },
});
