import React, { useEffect, useState } from 'react';
import { ActivityIndicator, ScrollView, StyleSheet, Text } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import DetailHeader from '../components/DetailHeader';
import Focusable from '../components/Focusable';
import { getMovieInfo } from '../api/xtream';
import { colors } from '../theme';
import { MovieInfo } from '../types';
import { RootStackParamList } from '../navigation';

type Props = NativeStackScreenProps<RootStackParamList, 'MovieDetail'>;

export default function MovieDetailScreen({ route, navigation }: Props) {
  const { source, item } = route.params;
  const [info, setInfo] = useState<MovieInfo | null>(null);

  useEffect(() => {
    navigation.setOptions({ title: item.name });
    getMovieInfo(source, item.id)
      .then(setInfo)
      .catch(() => setInfo({}));
  }, [item, navigation, source]);

  const play = () => {
    if (item.url) {
      navigation.navigate('Player', { vod: { url: item.url, title: item.name } });
    }
  };

  return (
    <ScrollView style={styles.container}>
      {info === null ? (
        <ActivityIndicator color={colors.accent} style={{ marginTop: 60 }} />
      ) : (
        <DetailHeader title={item.name} info={info} fallbackPoster={item.poster}>
          <Focusable hasTVPreferredFocus style={styles.play} onPress={play}>
            <Text style={styles.playText}>▶  Lire le film</Text>
          </Focusable>
        </DetailHeader>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  play: {
    marginTop: 20,
    alignSelf: 'flex-start',
    backgroundColor: colors.accent,
    borderWidth: 2,
    borderColor: colors.accent,
    borderRadius: 8,
    paddingHorizontal: 28,
    paddingVertical: 12,
  },
  playText: { color: '#fff', fontSize: 17, fontWeight: '700' },
});
