import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  Image,
  StyleSheet,
  Text,
  TextInput,
  useWindowDimensions,
  View,
} from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import Focusable from '../components/Focusable';
import { loadPlaylist } from '../api';
import { setQueue } from '../playerQueue';
import { getFavorites, toggleFavorite } from '../storage';
import { colors } from '../theme';
import { getNowNext } from '../api/epg';
import NowNext from '../components/NowNext';
import {
  CAT_ALL,
  CAT_FAVORITES,
  Category,
  Channel,
  Playlist,
  Program,
} from '../types';
import { RootStackParamList } from '../navigation';

type Props = NativeStackScreenProps<RootStackParamList, 'Channels'>;

const ROW_HEIGHT = 64;

export default function ChannelsScreen({ route, navigation }: Props) {
  const { source } = route.params;
  const { width } = useWindowDimensions();
  const wide = width >= 700; // télé / tablette : catégories à gauche

  const [playlist, setPlaylist] = useState<Playlist | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [categoryId, setCategoryId] = useState<string>(CAT_ALL);
  const [search, setSearch] = useState('');

  const load = useCallback(async () => {
    setError(null);
    setPlaylist(null);
    try {
      const [pl, favs] = await Promise.all([
        loadPlaylist(source),
        getFavorites(source.id),
      ]);
      setPlaylist(pl);
      setFavorites(favs);
    } catch (e: any) {
      setError(e?.message || 'Chargement impossible');
    }
  }, [source]);

  useEffect(() => {
    navigation.setOptions({ title: source.name });
    load();
  }, [load, navigation, source.name]);

  const categories: Category[] = useMemo(
    () => [
      { id: CAT_ALL, name: 'Toutes les chaînes' },
      { id: CAT_FAVORITES, name: '★ Favoris' },
      ...(playlist?.categories || []),
    ],
    [playlist],
  );

  const channels: Channel[] = useMemo(() => {
    if (!playlist) {
      return [];
    }
    let list = playlist.channels;
    if (categoryId === CAT_FAVORITES) {
      list = list.filter(c => favorites.includes(c.id));
    } else if (categoryId !== CAT_ALL) {
      list = list.filter(c => c.categoryId === categoryId);
    }
    const q = search.trim().toLowerCase();
    if (q) {
      list = list.filter(c => c.name.toLowerCase().includes(q));
    }
    return list;
  }, [playlist, categoryId, favorites, search]);

  // Guide horaire de la chaîne qui a le focus (panneau de droite sur télé)
  const [focused, setFocused] = useState<Channel | null>(null);
  const [epg, setEpg] = useState<Program[] | null>(null);
  useEffect(() => {
    if (!wide || !focused) {
      return;
    }
    setEpg(null);
    let cancelled = false;
    const t = setTimeout(async () => {
      const data = await getNowNext(source, focused);
      if (!cancelled) {
        setEpg(data);
      }
    }, 300);
    return () => {
      cancelled = true;
      clearTimeout(t);
    };
  }, [focused, wide, source]);

  const play = (index: number) => {
    setQueue(channels, source);
    navigation.navigate('Player', { index });
  };

  const onToggleFav = async (ch: Channel) => {
    setFavorites(await toggleFavorite(source.id, ch.id));
  };

  if (error) {
    return (
      <View style={styles.center}>
        <Text style={styles.error}>{error}</Text>
        <Focusable hasTVPreferredFocus style={styles.retry} onPress={load}>
          <Text style={styles.retryText}>Réessayer</Text>
        </Focusable>
      </View>
    );
  }

  if (!playlist) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={colors.accent} />
        <Text style={styles.muted}>Chargement des chaînes…</Text>
      </View>
    );
  }

  const categoryList = (
    <FlatList
      data={categories}
      horizontal={!wide}
      keyExtractor={c => c.id}
      style={wide ? styles.catColumn : styles.catBar}
      showsHorizontalScrollIndicator={false}
      renderItem={({ item, index }) => (
        <Focusable
          hasTVPreferredFocus={index === 0}
          style={[
            wide ? styles.catRow : styles.catChip,
            item.id === categoryId && styles.catActive,
          ]}
          onFocus={() => wide && setCategoryId(item.id)}
          onPress={() => setCategoryId(item.id)}>
          <Text style={styles.catText} numberOfLines={1}>
            {item.name}
          </Text>
        </Focusable>
      )}
    />
  );

  return (
    <View style={[styles.container, wide && { flexDirection: 'row' }]}>
      {categoryList}

      <View style={styles.channelPane}>
        <TextInput
          value={search}
          onChangeText={setSearch}
          placeholder="Rechercher une chaîne"
          placeholderTextColor={colors.muted}
          style={styles.search}
          autoCorrect={false}
        />
        <Text style={styles.count}>
          {channels.length} chaîne{channels.length > 1 ? 's' : ''} · appui long =
          favori
        </Text>
        <FlatList
          data={channels}
          keyExtractor={c => c.id}
          initialNumToRender={20}
          windowSize={11}
          getItemLayout={(_, i) => ({
            length: ROW_HEIGHT,
            offset: ROW_HEIGHT * i,
            index: i,
          })}
          ListEmptyComponent={
            <Text style={styles.muted}>Aucune chaîne ici.</Text>
          }
          renderItem={({ item, index }) => (
            <Focusable
              style={styles.channelRow}
              onFocus={() => setFocused(item)}
              onPress={() => play(index)}
              onLongPress={() => onToggleFav(item)}>
              {item.logo ? (
                <Image
                  source={{ uri: item.logo }}
                  style={styles.logo}
                  resizeMode="contain"
                />
              ) : (
                <View style={[styles.logo, styles.logoEmpty]} />
              )}
              <Text style={styles.channelName} numberOfLines={1}>
                {item.name}
              </Text>
              {favorites.includes(item.id) && <Text style={styles.star}>★</Text>}
            </Focusable>
          )}
        />
      </View>

      {wide && (
        <View style={styles.infoPane}>
          {focused ? (
            <>
              {focused.logo && (
                <Image
                  source={{ uri: focused.logo }}
                  style={styles.infoLogo}
                  resizeMode="contain"
                />
              )}
              <Text style={styles.infoName} numberOfLines={2}>
                {focused.name}
              </Text>
              {epg === null ? (
                <ActivityIndicator color={colors.accent} />
              ) : (
                <NowNext programs={epg} showDescription />
              )}
            </>
          ) : (
            <Text style={styles.muted}>Choisis une chaîne</Text>
          )}
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  center: {
    flex: 1,
    backgroundColor: colors.bg,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
    gap: 12,
  },
  muted: { color: colors.muted, fontSize: 15, padding: 12 },
  error: { color: colors.danger, fontSize: 16, textAlign: 'center' },
  retry: {
    backgroundColor: colors.panel,
    borderWidth: 2,
    borderColor: colors.border,
    borderRadius: 8,
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  retryText: { color: colors.text, fontSize: 16 },

  catColumn: {
    width: 280,
    flexGrow: 0,
    backgroundColor: colors.panel,
    borderRightWidth: 1,
    borderRightColor: colors.border,
  },
  catBar: { flexGrow: 0, paddingVertical: 8, paddingHorizontal: 8 },
  catRow: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  catChip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    marginRight: 8,
    borderRadius: 18,
    borderWidth: 2,
    borderColor: colors.border,
    backgroundColor: colors.panel,
  },
  catActive: { backgroundColor: colors.accent, borderColor: colors.accent },
  catText: { color: colors.text, fontSize: 15 },

  channelPane: { flex: 1, paddingHorizontal: 12 },
  search: {
    backgroundColor: colors.panel,
    color: colors.text,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: 12,
    paddingVertical: 8,
    marginTop: 10,
    fontSize: 15,
  },
  count: { color: colors.muted, fontSize: 12, marginVertical: 6 },
  channelRow: {
    height: ROW_HEIGHT - 6,
    marginBottom: 6,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    borderRadius: 8,
    borderWidth: 2,
    borderColor: 'transparent',
    backgroundColor: colors.panel,
  },
  logo: { width: 48, height: 36, marginRight: 12 },
  logoEmpty: { backgroundColor: colors.panelAlt, borderRadius: 4 },
  channelName: { color: colors.text, fontSize: 16, flex: 1 },
  star: { color: colors.star, fontSize: 18, marginLeft: 8 },

  infoPane: {
    width: 320,
    padding: 20,
    backgroundColor: colors.panel,
    borderLeftWidth: 1,
    borderLeftColor: colors.border,
  },
  infoLogo: { width: 120, height: 70, marginBottom: 12 },
  infoName: { color: colors.text, fontSize: 20, fontWeight: '700', marginBottom: 16 },
});
