import React, { useState } from 'react';
import {
  ActivityIndicator,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import Focusable from '../components/Focusable';
import { loadM3u } from '../api/m3u';
import { xtreamLogin } from '../api/xtream';
import { saveSource } from '../storage';
import { colors } from '../theme';
import { Source } from '../types';
import { openSource, RootStackParamList } from '../navigation';

type Props = NativeStackScreenProps<RootStackParamList, 'AddSource'>;

export default function AddSourceScreen({ navigation }: Props) {
  const [type, setType] = useState<'xtream' | 'm3u'>('xtream');
  const [name, setName] = useState('');
  const [server, setServer] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [url, setUrl] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submit = async () => {
    setError(null);
    const id = String(Date.now());
    let source: Source;

    if (type === 'xtream') {
      if (!server || !username || !password) {
        setError('Remplis le serveur, le nom d’utilisateur et le mot de passe.');
        return;
      }
      source = {
        id,
        type: 'xtream',
        name: name.trim() || server.trim(),
        server,
        username: username.trim(),
        password,
      };
    } else {
      if (!url) {
        setError('Entre le lien de la liste M3U.');
        return;
      }
      source = { id, type: 'm3u', name: name.trim() || 'Liste M3U', url };
    }

    setBusy(true);
    try {
      // Valide la connexion avant d'enregistrer
      if (source.type === 'xtream') {
        await xtreamLogin(source);
      } else {
        await loadM3u(source);
      }
      await saveSource(source);
      openSource(navigation, source, true);
    } catch (e: any) {
      setError(e?.message || 'Connexion impossible');
    } finally {
      setBusy(false);
    }
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.title}>Ajouter une liste</Text>

      <View style={styles.tabs}>
        {(['xtream', 'm3u'] as const).map(t => (
          <Focusable
            key={t}
            hasTVPreferredFocus={t === 'xtream'}
            style={[styles.tab, type === t && styles.tabActive]}
            onPress={() => setType(t)}>
            <Text style={styles.tabText}>
              {t === 'xtream' ? 'Xtream Codes' : 'Lien M3U'}
            </Text>
          </Focusable>
        ))}
      </View>

      <Field label="Nom (optionnel)" value={name} onChange={setName} />

      {type === 'xtream' ? (
        <>
          <Field
            label="Serveur (ex. http://exemple.com:8080)"
            value={server}
            onChange={setServer}
            keyboardType="url"
          />
          <Field label="Nom d’utilisateur" value={username} onChange={setUsername} />
          <Field label="Mot de passe" value={password} onChange={setPassword} secure />
        </>
      ) : (
        <Field
          label="Lien de la liste (http://…)"
          value={url}
          onChange={setUrl}
          keyboardType="url"
        />
      )}

      {error && <Text style={styles.error}>{error}</Text>}

      <Focusable style={styles.submit} onPress={submit} disabled={busy}>
        {busy ? (
          <ActivityIndicator color={colors.text} />
        ) : (
          <Text style={styles.submitText}>Connexion</Text>
        )}
      </Focusable>
    </ScrollView>
  );
}

function Field(props: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  secure?: boolean;
  keyboardType?: 'default' | 'url';
}) {
  const [focused, setFocused] = useState(false);
  return (
    <View style={styles.field}>
      <Text style={styles.label}>{props.label}</Text>
      <TextInput
        value={props.value}
        onChangeText={props.onChange}
        secureTextEntry={props.secure}
        keyboardType={props.keyboardType || 'default'}
        autoCapitalize="none"
        autoCorrect={false}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        placeholderTextColor={colors.muted}
        style={[styles.input, focused && { borderColor: colors.focus }]}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  content: { padding: 24, maxWidth: 640, width: '100%', alignSelf: 'center' },
  title: { color: colors.text, fontSize: 26, fontWeight: '700', marginBottom: 16 },
  tabs: { flexDirection: 'row', gap: 10, marginBottom: 16 },
  tab: {
    flex: 1,
    padding: 12,
    borderRadius: 8,
    borderWidth: 2,
    borderColor: colors.border,
    backgroundColor: colors.panel,
    alignItems: 'center',
  },
  tabActive: { backgroundColor: colors.accent, borderColor: colors.accent },
  tabText: { color: colors.text, fontWeight: '600', fontSize: 16 },
  field: { marginBottom: 14 },
  label: { color: colors.muted, marginBottom: 6, fontSize: 14 },
  input: {
    backgroundColor: colors.panel,
    color: colors.text,
    borderWidth: 2,
    borderColor: colors.border,
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 16,
  },
  error: { color: colors.danger, marginVertical: 8, fontSize: 15 },
  submit: {
    marginTop: 8,
    backgroundColor: colors.accent,
    borderWidth: 2,
    borderColor: colors.accent,
    borderRadius: 8,
    padding: 14,
    alignItems: 'center',
  },
  submitText: { color: '#fff', fontSize: 17, fontWeight: '700' },
});
