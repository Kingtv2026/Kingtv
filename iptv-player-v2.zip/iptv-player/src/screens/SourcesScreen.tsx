import React, { useCallback, useState } from 'react';
import { Alert, FlatList, StyleSheet, Text, View } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import Focusable from '../components/Focusable';
import { getSources, removeSource } from '../storage';
import { colors } from '../theme';
import { Source } from '../types';
import { openSource, RootStackParamList } from '../navigation';

type Props = NativeStackScreenProps<RootStackParamList, 'Sources'>;

export default function SourcesScreen({ navigation }: Props) {
  const [sources, setSources] = useState<Source[]>([]);

  useFocusEffect(
    useCallback(() => {
      getSources().then(setSources);
    }, []),
  );

  const confirmDelete = (s: Source) => {
    Alert.alert('Supprimer', `Supprimer « ${s.name} » ?`, [
      { text: 'Annuler', style: 'cancel' },
      {
        text: 'Supprimer',
        style: 'destructive',
        onPress: async () => {
          await removeSource(s.id);
          setSources(await getSources());
        },
      },
    ]);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Mes listes</Text>

      <FlatList
        data={sources}
        keyExtractor={s => s.id}
        ListEmptyComponent={
          <Text style={styles.empty}>
            Aucune liste. Ajoute ton abonnement Xtream ou un lien M3U.
          </Text>
        }
        renderItem={({ item, index }) => (
          <Focusable
            hasTVPreferredFocus={index === 0}
            style={styles.row}
            onPress={() => openSource(navigation, item)}
            onLongPress={() => confirmDelete(item)}>
            <Text style={styles.rowName}>{item.name}</Text>
            <Text style={styles.rowType}>
              {item.type === 'xtream' ? 'Xtream Codes' : 'M3U'}
            </Text>
          </Focusable>
        )}
      />

      <Focusable
        hasTVPreferredFocus={sources.length === 0}
        style={[styles.row, styles.addBtn]}
        onPress={() => navigation.navigate('AddSource')}>
        <Text style={styles.addText}>+ Ajouter une liste</Text>
      </Focusable>

      <Text style={styles.hint}>Appui long sur une liste pour la supprimer</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg, padding: 24 },
  title: { color: colors.text, fontSize: 28, fontWeight: '700', marginBottom: 16 },
  empty: { color: colors.muted, fontSize: 16, marginVertical: 24 },
  row: {
    backgroundColor: colors.panel,
    borderWidth: 2,
    borderColor: colors.border,
    borderRadius: 10,
    padding: 16,
    marginBottom: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  rowName: { color: colors.text, fontSize: 18, fontWeight: '600' },
  rowType: { color: colors.muted, fontSize: 14 },
  addBtn: { justifyContent: 'center', marginTop: 8 },
  addText: { color: colors.accent, fontSize: 18, fontWeight: '700' },
  hint: { color: colors.muted, fontSize: 12, textAlign: 'center', marginTop: 8 },
});
