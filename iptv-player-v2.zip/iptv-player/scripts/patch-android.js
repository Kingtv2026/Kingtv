/**
 * Applique les réglages Android nécessaires au projet généré :
 *  - flux http:// autorisés (aussi en version release)
 *  - Android TV (leanback, pas d'écran tactile requis, bannière)
 *  - correctif react-native-screens dans MainActivity
 *
 * Usage : node scripts/patch-android.js <dossier-du-projet>
 */
const fs = require('fs');
const path = require('path');

const root = path.resolve(process.argv[2] || '.');
const here = path.resolve(__dirname, '..');

// ---------- AndroidManifest.xml ----------
const manifestPath = path.join(root, 'android/app/src/main/AndroidManifest.xml');
let m = fs.readFileSync(manifestPath, 'utf8');

if (/android:usesCleartextTraffic="[^"]*"/.test(m)) {
  m = m.replace(/android:usesCleartextTraffic="[^"]*"/, 'android:usesCleartextTraffic="true"');
} else {
  m = m.replace('<application', '<application\n      android:usesCleartextTraffic="true"');
}

for (const feature of ['android.software.leanback', 'android.hardware.touchscreen']) {
  if (!m.includes(feature)) {
    m = m.replace(
      '<application',
      `<uses-feature android:name="${feature}" android:required="false" />\n    <application`,
    );
  }
}

if (!m.includes('LEANBACK_LAUNCHER')) {
  m = m.replace(
    '<category android:name="android.intent.category.LAUNCHER" />',
    '<category android:name="android.intent.category.LAUNCHER" />\n        <category android:name="android.intent.category.LEANBACK_LAUNCHER" />',
  );
}

const banner = path.join(here, 'assets/banner.png');
if (fs.existsSync(banner)) {
  const drawable = path.join(root, 'android/app/src/main/res/drawable');
  fs.mkdirSync(drawable, { recursive: true });
  fs.copyFileSync(banner, path.join(drawable, 'banner.png'));
  if (!m.includes('android:banner')) {
    m = m.replace('<application', '<application\n      android:banner="@drawable/banner"');
  }
}

fs.writeFileSync(manifestPath, m);
console.log('AndroidManifest.xml modifié');

// ---------- MainActivity.kt ----------
function find(dir, name) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      const r = find(p, name);
      if (r) return r;
    } else if (entry.name === name) {
      return p;
    }
  }
  return null;
}

const activity = find(path.join(root, 'android/app/src/main/java'), 'MainActivity.kt');
if (activity) {
  let a = fs.readFileSync(activity, 'utf8');
  if (!a.includes('onCreate')) {
    if (!a.includes('import android.os.Bundle')) {
      a = a.replace(/^(package .*)$/m, '$1\n\nimport android.os.Bundle');
    }
    a = a.replace(
      /(class MainActivity\s*:\s*ReactActivity\(\)\s*\{)/,
      '$1\n\n  override fun onCreate(savedInstanceState: Bundle?) {\n    super.onCreate(null)\n  }\n',
    );
    fs.writeFileSync(activity, a);
    console.log('MainActivity.kt modifié');
  }
} else {
  console.warn('MainActivity.kt introuvable : correctif react-native-screens non appliqué');
}
