import React, { useEffect, useState } from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { ScreenProps } from '../nav/Navigator';
import Focusable from '../components/Focusable';
import { xtreamLogin } from '../api/xtream';
import { clearCaches, loadPlaylist } from '../api';
import { clearEpgCache } from '../api/epg';
import { colors } from '../theme';
import { BUILD } from '../buildInfo';
import { getLiveEngine, LiveEngine, setLiveEngine } from '../prefs';
import { checkForUpdate, UpdateInfo } from '../update';
import { UpdateDialog } from '../components/UpdateDialog';

type Props = ScreenProps<'Settings'>;


export default function SettingsScreen({ route, navigation }: Props) {
  const { source } = route.params;
  const [account, setAccount] = useState<{ expiry?: string; conn?: string; status?: string } | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [update, setUpdate] = useState<UpdateInfo | null>(null);
  const [engine, setEngine] = useState<LiveEngine>(getLiveEngine());

  const checkUpdate = async () => {
    setMsg('Recherche d’une mise à jour…');
    try {
      const u = await checkForUpdate();
      if (u) {
        setMsg(null);
        setUpdate(u);
      } else {
        setMsg('✓ Tu as déjà la dernière version');
      }
    } catch {
      setMsg('Impossible de vérifier pour le moment');
    }
  };

  useEffect(() => {
    xtreamLogin(source)
      .then(data => {
        const u = data?.user_info || {};
        const exp = Number(u.exp_date);
        let expiry: string | undefined;
        if (exp > 0) {
          const d = new Date(exp * 1000);
          expiry = `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`;
        }
        setAccount({
          expiry: expiry ?? 'Illimité',
          conn: u.max_connections ? String(u.max_connections) : undefined,
          status: u.status,
        });
      })
      .catch(() => setAccount({}));
  }, [source]);

  const refresh = async () => {
    setBusy(true);
    setMsg(null);
    clearCaches(source.id);
    try {
      const pl = await loadPlaylist(source);
      setMsg(`✓ Contenu actualisé : ${pl.channels.length} chaînes`);
    } catch (e: any) {
      setMsg(`Échec : ${e?.message || 'serveur injoignable'}`);
    } finally {
      setBusy(false);
    }
  };

  const host = source.server.replace(/^https?:\/\//i, '').split('/')[0];

  return (
    <View style={{ flex: 1 }}>
    <ScrollView contentContainerStyle={styles.content}>
      <Group title="Abonnement">
        <Info icon="📡" label={source.name} value={host} />
        <Info icon="✅" label="Statut" value={account ? account.status || '—' : '…'} />
        <Info icon="📅" label="Expiration" value={account ? account.expiry || '—' : '…'} />
        <Info icon="🔗" label="Connexions permises" value={account ? account.conn || '—' : '…'} last />
      </Group>

      <Group title="Contenu">
        <Row
          preferred
          icon="🔄"
          label={busy ? 'Actualisation…' : 'Actualiser le contenu'}
          sub="Recharge chaînes, films, séries et guide"
          onPress={refresh}
        />
        <Row
          icon="🗓"
          label="Données de l’EPG"
          sub="Vider le guide horaire en mémoire"
          onPress={() => {
            clearEpgCache();
            setMsg('✓ Le guide sera rechargé à la prochaine ouverture');
          }}
        />
        <Row icon="📅" label="Guide TV" onPress={() => navigation.navigate('Guide', { source })} last />
      </Group>

      {!!msg && <Text style={styles.msg}>{msg}</Text>}

      <Group title="Lecteur">
        <Row
          icon="▶️"
          label={`Télé en direct : ${engine === 'vlc' ? 'VLC (recommandé)' : 'Lecteur Android'}`}
          sub="Appuie pour changer · essaie l’autre si une chaîne saccade ou recule"
          onPress={() => {
            const next: LiveEngine = engine === 'vlc' ? 'exo' : 'vlc';
            setEngine(next);
            setLiveEngine(next);
          }}
          last
        />
      </Group>

      <Group title="Sources">
        <Row
          icon="✏️"
          label="Modifier cette liste"
          onPress={() => navigation.navigate('AddSource', { edit: source })}
        />
        <Row icon="📋" label="Mes listes" sub="Changer ou ajouter un abonnement" onPress={() => navigation.popToTop()} last />
      </Group>

      <Group title="Application">
        <Row icon="🚀" label="Rechercher une mise à jour" sub={`Version installée : ${BUILD}`} onPress={checkUpdate} />
        <Info icon="ℹ️" label="À propos" value={`Kingtv · version ${BUILD}`} />
        <Info icon="🛡" label="Contenu" value="Lecteur seulement, aucune chaîne incluse" last />
      </Group>
    </ScrollView>
    {update && <UpdateDialog info={update} onClose={() => setUpdate(null)} />}
    </View>
  );
}

function Group({ title, children }: { title: string; children?: React.ReactNode }) {
  return (
    <View style={{ marginBottom: 18 }}>
      <Text style={styles.groupTitle}>{title}</Text>
      <View style={styles.group}>{children}</View>
    </View>
  );
}

function Row({
  icon,
  label,
  sub,
  onPress,
  last,
  preferred,
}: {
  icon: string;
  label: string;
  sub?: string;
  onPress: () => void;
  last?: boolean;
  preferred?: boolean;
}) {
  return (
    <Focusable hasTVPreferredFocus={preferred} style={[styles.row, !last && styles.sep]} onPress={onPress}>
      <Text style={styles.icon}>{icon}</Text>
      <View style={{ flex: 1 }}>
        <Text style={styles.label}>{label}</Text>
        {!!sub && <Text style={styles.sub}>{sub}</Text>}
      </View>
      <Text style={styles.chev}>›</Text>
    </Focusable>
  );
}

function Info({ icon, label, value, last }: { icon: string; label: string; value: string; last?: boolean }) {
  return (
    <View style={[styles.row, !last && styles.sep]}>
      <Text style={styles.icon}>{icon}</Text>
      <Text style={[styles.label, { flex: 1 }]} numberOfLines={1}>
        {label}
      </Text>
      <Text style={styles.value} numberOfLines={1}>
        {value}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  content: { padding: 16, paddingBottom: 40, width: '100%', maxWidth: 720, alignSelf: 'center' },
  groupTitle: { color: colors.muted, fontSize: 13, fontWeight: '800', marginLeft: 8, marginBottom: 8, letterSpacing: 0.5 },
  group: { borderRadius: 18, backgroundColor: colors.panel, borderWidth: 1, borderColor: colors.border, overflow: 'hidden' },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    paddingHorizontal: 18,
    paddingVertical: 16,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  sep: { borderBottomColor: colors.border, borderBottomWidth: 1 },
  icon: { fontSize: 20, width: 28, textAlign: 'center' },
  label: { color: colors.text, fontSize: 16, fontWeight: '700' },
  sub: { color: colors.muted, fontSize: 12, marginTop: 2 },
  value: { color: colors.muted, fontSize: 14, maxWidth: '55%' },
  chev: { color: colors.muted, fontSize: 24 },
  msg: { color: colors.cyan, fontSize: 14, textAlign: 'center', marginTop: -6, marginBottom: 16 },
});
