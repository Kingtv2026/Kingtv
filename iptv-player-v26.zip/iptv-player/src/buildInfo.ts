/** Numéro de version : remplacé automatiquement par GitHub au moment de la compilation. */
export const BUILD = 0;

/** Dépôt GitHub où sont publiées les versions (pour la mise à jour automatique). */
export const UPDATE_REPO = 'Kingtv2026/Kingtv';
