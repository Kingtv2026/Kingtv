#!/usr/bin/env bash
# Construit l'APK : crée le projet React Native TV, ajoute le code de l'app, compile.
# Lancé par GitHub Actions (voir .github/workflows/build-apk.yml).
set -euo pipefail

HERE="$(cd "$(dirname "$0")/.." && pwd)"   # dossier du code de l'app
WORK="${GITHUB_WORKSPACE:-$PWD}"
cd "$WORK"

# ---- Journal + rapport d'erreur lisible sans connexion (annotation GitHub) ----
LOG="$WORK/build.log"
exec > >(tee "$LOG") 2>&1
report() {
  local code=$?
  if [ "$code" -ne 0 ]; then
    sleep 1
    {
      echo "=== Étape : ${STEP:-?} ==="
      grep -n -A 20 "What went wrong" "$LOG" | head -n 40 || true
      echo "=== Fin du journal ==="
      tail -n 60 "$LOG"
    } > "$WORK/error-report.txt"
    local msg
    msg=$(sed -e 's/%/%25/g' -e 's/\r//g' "$WORK/error-report.txt" | sed ':a;N;$!ba;s/\n/%0A/g')
    echo "::error title=Echec - ${STEP:-?}::${msg}"
  fi
}
trap report EXIT

# La version TV de React Native a un numéro « 0.xx.x-0 » que certaines
# librairies ne reconnaissent pas : on ne bloque pas sur ces vérifications.
export NPM_CONFIG_LEGACY_PEER_DEPS=true

STEP="Création du projet React Native TV"
rm -rf build-app
npx --yes @react-native-community/cli@latest init IptvPlayer \
  --template @react-native-tvos/template-tv \
  --directory build-app \
  --skip-git-init \
  --install-pods false \
  --pm npm

cd build-app
echo "Version de React Native :"
node -p "require('react-native/package.json').version"

STEP="Installation des librairies"
npm install --legacy-peer-deps \
  react-native-video@^6 \
  @react-native-async-storage/async-storage@^2 \
  react-native-vlc-media-player@^1

STEP="Ajout du code de l'app"
cp "$HERE/App.tsx" ./App.tsx
rm -rf src && cp -r "$HERE/src" ./src
node "$HERE/scripts/patch-android.js" .

STEP="Compilation Android (Gradle)"
cd android
chmod +x gradlew
./gradlew assembleRelease --no-daemon
STEP="Terminé"
