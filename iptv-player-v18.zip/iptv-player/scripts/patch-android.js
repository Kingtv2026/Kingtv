/**
 * Applique les réglages Android nécessaires au projet généré :
 *  - flux http:// autorisés (aussi en version release)
 *  - Android TV (leanback, pas d'écran tactile requis, bannière)
 *
 * Usage : node scripts/patch-android.js <dossier-du-projet>
 */
const fs = require('fs');
const path = require('path');

const root = path.resolve(process.argv[2] || '.');
const here = path.resolve(__dirname, '..');

// ---------- AndroidManifest.xml ----------
const manifestPath = path.join(root, 'android/app/src/main/AndroidManifest.xml');
let m = fs.readFileSync(manifestPath, 'utf8');

if (/android:usesCleartextTraffic="[^"]*"/.test(m)) {
  m = m.replace(/android:usesCleartextTraffic="[^"]*"/, 'android:usesCleartextTraffic="true"');
} else {
  m = m.replace('<application', '<application\n      android:usesCleartextTraffic="true"');
}

for (const feature of ['android.software.leanback', 'android.hardware.touchscreen']) {
  if (!m.includes(feature)) {
    m = m.replace(
      '<application',
      `<uses-feature android:name="${feature}" android:required="false" />\n    <application`,
    );
  }
}

if (!m.includes('LEANBACK_LAUNCHER')) {
  m = m.replace(
    '<category android:name="android.intent.category.LAUNCHER" />',
    '<category android:name="android.intent.category.LAUNCHER" />\n        <category android:name="android.intent.category.LEANBACK_LAUNCHER" />',
  );
}

const banner = path.join(here, 'assets/banner.png');
if (fs.existsSync(banner)) {
  const drawable = path.join(root, 'android/app/src/main/res/drawable');
  fs.mkdirSync(drawable, { recursive: true });
  fs.copyFileSync(banner, path.join(drawable, 'banner.png'));
  if (!m.includes('android:banner')) {
    m = m.replace('<application', '<application\n      android:banner="@drawable/banner"');
  }
}

fs.writeFileSync(manifestPath, m);
console.log('AndroidManifest.xml modifié');

// ---------- Nom de l'app ----------
const APP_NAME = 'Kingtv';
const stringsPath = path.join(root, 'android/app/src/main/res/values/strings.xml');
if (fs.existsSync(stringsPath)) {
  let x = fs.readFileSync(stringsPath, 'utf8');
  x = x.replace(/<string name="app_name">[^<]*<\/string>/, `<string name="app_name">${APP_NAME}</string>`);
  fs.writeFileSync(stringsPath, x);
  console.log(`Nom de l'app : ${APP_NAME}`);
}

// ---------- Icône ----------
const res = path.join(root, 'android/app/src/main/res');
const iconDir = path.join(here, 'assets/icon');
if (fs.existsSync(iconDir)) {
  for (const d of ['mdpi', 'hdpi', 'xhdpi', 'xxhdpi', 'xxxhdpi']) {
    const dest = path.join(res, `mipmap-${d}`);
    fs.mkdirSync(dest, { recursive: true });
    fs.copyFileSync(path.join(iconDir, `ic_launcher-${d}.png`), path.join(dest, 'ic_launcher.png'));
    fs.copyFileSync(path.join(iconDir, `ic_launcher_round-${d}.png`), path.join(dest, 'ic_launcher_round.png'));
  }
  // Une icône « adaptative » du gabarit passerait par-dessus la nôtre
  fs.rmSync(path.join(res, 'mipmap-anydpi-v26'), { recursive: true, force: true });
  fs.rmSync(path.join(res, 'mipmap-anydpi'), { recursive: true, force: true });
  console.log('Icône remplacée');
}

// ---------- Moteur VLC : processeurs ARM seulement + bibliothèque C++ en double ----------
const gradleProps = path.join(root, 'android/gradle.properties');
if (fs.existsSync(gradleProps)) {
  let g = fs.readFileSync(gradleProps, 'utf8');
  // Téléphones, Fire Stick et boîtiers Android TV sont tous ARM : APK beaucoup plus léger
  if (/^reactNativeArchitectures=.*$/m.test(g)) {
    g = g.replace(/^reactNativeArchitectures=.*$/m, 'reactNativeArchitectures=armeabi-v7a,arm64-v8a');
  } else {
    g += '\nreactNativeArchitectures=armeabi-v7a,arm64-v8a\n';
  }
  fs.writeFileSync(gradleProps, g);
  console.log('Architectures : armeabi-v7a, arm64-v8a');
}

const appGradle = path.join(root, 'android/app/build.gradle');
if (fs.existsSync(appGradle)) {
  let b = fs.readFileSync(appGradle, 'utf8');
  if (!b.includes('libc++_shared.so')) {
    b = b.replace(
      /\nandroid\s*\{/,
      "\nandroid {\n    packagingOptions {\n        pickFirst '**/libc++_shared.so'\n    }\n",
    );
    fs.writeFileSync(appGradle, b);
    console.log('packagingOptions ajouté');
  }
}

// ---------- Android minimum 8.0 (API 26), exigé par le moteur VLC ----------
const rootGradle = path.join(root, 'android/build.gradle');
if (fs.existsSync(rootGradle)) {
  let r = fs.readFileSync(rootGradle, 'utf8');
  if (/minSdkVersion\s*=\s*\d+/.test(r)) {
    r = r.replace(/minSdkVersion\s*=\s*\d+/, 'minSdkVersion = 26');
    fs.writeFileSync(rootGradle, r);
    console.log('minSdkVersion = 26');
  } else {
    console.warn('minSdkVersion introuvable dans android/build.gradle');
  }
}

function find(dir, name) {
  if (!fs.existsSync(dir)) return null;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      const r = find(p, name);
      if (r) return r;
    } else if (entry.name === name) {
      return p;
    }
  }
  return null;
}

// ---------- Plein écran : masque la barre de navigation et la barre d'état ----------
// (elles réapparaissent un moment en glissant depuis le bord de l'écran)
const mainActivity = find(path.join(root, 'android/app/src/main/java'), 'MainActivity.kt');
if (mainActivity) {
  let a = fs.readFileSync(mainActivity, 'utf8');
  if (!a.includes('hideSystemBars')) {
    a = a.replace(/^(package .*)$/m, '$1\n\nimport android.view.View');
    const end = a.lastIndexOf('}');
    a =
      a.slice(0, end) +
      `
  override fun onWindowFocusChanged(hasFocus: Boolean) {
    super.onWindowFocusChanged(hasFocus)
    if (hasFocus) hideSystemBars()
  }

  @Suppress("DEPRECATION")
  private fun hideSystemBars() {
    window.decorView.systemUiVisibility =
      View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
      View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
      View.SYSTEM_UI_FLAG_FULLSCREEN
  }
` +
      a.slice(end);
    fs.writeFileSync(mainActivity, a);
    console.log('Plein écran activé (MainActivity)');
  }
}
