import React from 'react';
import { StatusBar } from 'react-native';
import { StackNavigator } from './src/nav/Navigator';
import ErrorBoundary from './src/components/ErrorBoundary';
import SourcesScreen from './src/screens/SourcesScreen';
import AddSourceScreen from './src/screens/AddSourceScreen';
import HomeScreen from './src/screens/HomeScreen';
import ChannelsScreen from './src/screens/ChannelsScreen';
import MediaScreen from './src/screens/MediaScreen';
import MovieDetailScreen from './src/screens/MovieDetailScreen';
import SeriesDetailScreen from './src/screens/SeriesDetailScreen';
import PlayerScreen from './src/screens/PlayerScreen';
import GuideScreen from './src/screens/GuideScreen';
import CatchupScreen from './src/screens/CatchupScreen';

export default function App() {
  return (
    <ErrorBoundary>
      <StatusBar hidden />
      <StackNavigator
        initial="Sources"
        screens={{
          Sources: { component: SourcesScreen, headerShown: false },
          AddSource: { component: AddSourceScreen, title: 'Nouvelle liste' },
          Home: { component: HomeScreen, headerShown: false },
          Channels: { component: ChannelsScreen },
          Guide: { component: GuideScreen, title: 'Guide TV' },
          Catchup: { component: CatchupScreen, title: 'Rattrapage' },
          Media: { component: MediaScreen },
          MovieDetail: { component: MovieDetailScreen },
          SeriesDetail: { component: SeriesDetailScreen },
          Player: { component: PlayerScreen, headerShown: false, fullscreen: true },
        }}
      />
    </ErrorBoundary>
  );
}
