/**
 * Lecteur films/séries basé sur le moteur VLC (libVLC) intégré à l'app.
 * Lit les formats que le lecteur Android ne lit pas : MKV, AVI, son AC3/DTS, HEVC…
 */
import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  BackHandler,
  ScrollView,
  Pressable,
  StatusBar,
  StyleSheet,
  Text,
  useTVEventHandler,
  View,
} from 'react-native';
// @ts-ignore : la librairie n'a pas de types TypeScript
import { VLCPlayer } from 'react-native-vlc-media-player';
import Focusable from '../components/Focusable';
import Clock from '../components/Clock';
import { openInVlc } from '../utils/external';
import { colors } from '../theme';

function fmt(ms: number): string {
  const total = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const mm = h > 0 ? String(m).padStart(2, '0') : String(m);
  return `${h > 0 ? h + ':' : ''}${mm}:${String(s).padStart(2, '0')}`;
}

interface Track {
  id: number;
  name: string;
}

export default function VodPlayer({ url, title }: { url: string; title: string }) {
  const [audioTracks, setAudioTracks] = useState<Track[]>([]);
  const [textTracks, setTextTracks] = useState<Track[]>([]);
  const [audioTrack, setAudioTrack] = useState<number | undefined>(undefined);
  const [textTrack, setTextTrack] = useState<number | undefined>(undefined);
  const [panel, setPanel] = useState(false);
  const panelRef = useRef(false);
  panelRef.current = panel;
  const [paused, setPaused] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [started, setStarted] = useState(false);
  const [stalled, setStalled] = useState(true);
  const [slow, setSlow] = useState(false);
  const [cur, setCur] = useState(0);
  const [dur, setDur] = useState(0);
  const [seek, setSeek] = useState<number | undefined>(undefined);
  const [controls, setControls] = useState(true);
  const [attempt, setAttempt] = useState(0);
  const [barWidth, setBarWidth] = useState(1);

  const hideTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const curRef = useRef(0);
  const durRef = useRef(0);
  const lastProgress = useRef(0);
  const pausedRef = useRef(false);
  pausedRef.current = paused;

  const poke = useCallback(() => {
    setControls(true);
    if (hideTimer.current) {
      clearTimeout(hideTimer.current);
    }
    hideTimer.current = setTimeout(() => setControls(false), 4500);
  }, []);

  useEffect(() => {
    poke();
    return () => {
      if (hideTimer.current) {
        clearTimeout(hideTimer.current);
      }
    };
  }, [poke]);

  // Bouton Retour : ferme le panneau langues/sous-titres au lieu de quitter
  useEffect(() => {
    if (!panel) {
      return;
    }
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      setPanel(false);
      return true;
    });
    return () => sub.remove();
  }, [panel]);

  // Détecte quand la vidéo n'avance plus (chargement)
  useEffect(() => {
    const t = setInterval(() => {
      setStalled(!pausedRef.current && Date.now() - lastProgress.current > 2000);
    }, 1000);
    return () => clearInterval(t);
  }, []);

  // Rien après 25 s : on propose VLC externe
  useEffect(() => {
    setSlow(false);
    if (started || error) {
      return;
    }
    const t = setTimeout(() => setSlow(true), 25000);
    return () => clearTimeout(t);
  }, [started, error, attempt]);

  const seekTo = useCallback(
    (ms: number) => {
      const d = durRef.current;
      if (!d) {
        return;
      }
      const target = Math.min(Math.max(ms, 0), d - 1500);
      curRef.current = target;
      setCur(target);
      // petite variation pour que deux sauts identiques soient bien appliqués
      setSeek(target / d + Math.random() * 1e-6);
      poke();
    },
    [poke],
  );

  const seekBy = useCallback((delta: number) => seekTo(curRef.current + delta), [seekTo]);

  const toggle = useCallback(() => {
    setPaused(p => !p);
    poke();
  }, [poke]);

  const retry = () => {
    setError(null);
    setStarted(false);
    lastProgress.current = 0;
    setAttempt(a => a + 1);
  };

  // Télécommande : ◀ -10 s, ▶ +30 s, OK/lecture = pause, ▲▼ = afficher les contrôles
  useTVEventHandler(evt => {
    if (!evt || error || panelRef.current) {
      return;
    }
    switch (evt.eventType) {
      case 'left':
      case 'rewind':
        seekBy(-10000);
        break;
      case 'right':
      case 'fastForward':
        seekBy(30000);
        break;
      case 'select':
      case 'playPause':
        toggle();
        break;
      case 'up':
      case 'menu':
        setPanel(true);
        break;
      case 'down':
        poke();
        break;
    }
  });

  const progress = dur > 0 ? cur / dur : 0;
  const showSpinner = !error && (!started || stalled);

  return (
    <View style={styles.container}>
      <StatusBar hidden />
      <VLCPlayer
        key={`${url}#${attempt}`}
        style={StyleSheet.absoluteFill}
        source={{
          uri: url,
          initType: 2,
          initOptions: ['--network-caching=2500', '--http-reconnect'],
        }}
        autoplay
        paused={paused}
        {...(seek !== undefined ? { seek } : {})}
        {...(audioTrack !== undefined ? { audioTrack } : {})}
        {...(textTrack !== undefined ? { textTrack } : {})}
        onLoad={(e: any) => {
          const norm = (list: any): Track[] =>
            (Array.isArray(list) ? list : [])
              .map((t: any) => ({ id: Number(t.id), name: String(t.name ?? `Piste ${t.id}`) }))
              .filter((t: Track) => !Number.isNaN(t.id));
          setAudioTracks(norm(e?.audioTracks));
          setTextTracks(norm(e?.textTracks));
        }}
        onProgress={(e: any) => {
          lastProgress.current = Date.now();
          if (!started) {
            setStarted(true);
          }
          if (e?.duration > 0) {
            durRef.current = e.duration;
            setDur(e.duration);
          }
          if (typeof e?.currentTime === 'number') {
            curRef.current = e.currentTime;
            setCur(e.currentTime);
          }
        }}
        onPlaying={() => {
          lastProgress.current = Date.now();
          setError(null);
        }}
        onError={() => setError('Impossible de lire ce contenu.')}
        onEnd={() => {
          setPaused(true);
          setControls(true);
        }}
      />

      {/* Toucher l'écran (téléphone) : afficher/cacher les contrôles */}
      <Pressable
        style={StyleSheet.absoluteFill}
        focusable={false}
        onPress={() => (controls ? setControls(false) : poke())}
      />

      {showSpinner && <ActivityIndicator size="large" color={colors.accent} style={styles.spinner} />}

      {(error || (slow && !started)) && (
        <View style={styles.errorBox}>
          <Text style={styles.errorText}>
            {error || 'Le chargement est long… le serveur ne répond peut-être pas.'}
          </Text>
          <View style={styles.errorButtons}>
            <Focusable hasTVPreferredFocus style={styles.errBtn} onPress={retry}>
              <Text style={styles.errBtnText}>↻  Réessayer</Text>
            </Focusable>
            <Focusable style={[styles.errBtn, styles.vlcBtn]} onPress={() => openInVlc(url)}>
              <Text style={styles.errBtnText}>Ouvrir avec l’app VLC</Text>
            </Focusable>
          </View>
        </View>
      )}

      {(controls || paused) && !error && (
        <>
          <View style={styles.topBar} pointerEvents="none">
            <Text style={styles.title} numberOfLines={1}>
              {title}
            </Text>
            <Clock />
          </View>

          <View style={styles.bottom} pointerEvents="box-none">
            <Pressable
              focusable={false}
              onLayout={e => setBarWidth(e.nativeEvent.layout.width || 1)}
              onPress={e => seekTo((e.nativeEvent.locationX / barWidth) * durRef.current)}
              style={styles.barTouch}>
              <View style={styles.track}>
                <View style={[styles.fill, { width: `${progress * 100}%` }]} />
                <View style={[styles.knob, { left: `${progress * 100}%` }]} />
              </View>
            </Pressable>

            <View style={styles.controlsRow}>
              <Text style={styles.time}>{fmt(cur)}</Text>
              <View style={styles.buttons}>
                <Pressable focusable={false} style={styles.ctrlBtn} onPress={() => seekBy(-10000)}>
                  <Text style={styles.ctrlText}>↺ 10</Text>
                </Pressable>
                <Pressable focusable={false} style={[styles.ctrlBtn, styles.playBtn]} onPress={toggle}>
                  <Text style={[styles.ctrlText, { fontSize: 24 }]}>{paused ? '▶' : '❚❚'}</Text>
                </Pressable>
                <Pressable focusable={false} style={styles.ctrlBtn} onPress={() => seekBy(30000)}>
                  <Text style={styles.ctrlText}>30 ↻</Text>
                </Pressable>
                <Pressable focusable={false} style={styles.ctrlBtn} onPress={() => setPanel(true)}>
                  <Text style={styles.ctrlText}>🔊 💬</Text>
                </Pressable>
              </View>
              <Text style={styles.time}>{dur > 0 ? fmt(dur) : '--:--'}</Text>
            </View>
            <Text style={styles.hint}>Télécommande : ◀ −10 s  ·  ▶ +30 s  ·  OK = pause  ·  ▲ = langues et sous-titres</Text>
          </View>
        </>
      )}
      {panel && (
        <View style={styles.panelWrap}>
          <Pressable style={StyleSheet.absoluteFill} focusable={false} onPress={() => setPanel(false)} />
          <View style={styles.panel}>
            <ScrollView>
              <Text style={styles.panelTitle}>🔊  Langue audio</Text>
              {audioTracks.length === 0 && <Text style={styles.panelEmpty}>Une seule langue disponible</Text>}
              {audioTracks.map((t, i) => {
                const selected = audioTrack === undefined ? i === 0 : audioTrack === t.id;
                return (
                  <Focusable
                    key={`a${t.id}`}
                    hasTVPreferredFocus={selected}
                    style={[styles.trackRow, selected && styles.trackActive]}
                    onPress={() => setAudioTrack(t.id)}>
                    <Text style={styles.trackText} numberOfLines={1}>
                      {t.name}
                    </Text>
                    {selected && <Text style={styles.check}>✓</Text>}
                  </Focusable>
                );
              })}

              <Text style={[styles.panelTitle, { marginTop: 18 }]}>💬  Sous-titres</Text>
              {[
                ...(textTracks.some(t => t.id === -1) ? [] : [{ id: -1, name: 'Aucun' }]),
                ...textTracks,
              ].map(t => {
                const selected = (textTrack ?? -1) === t.id;
                return (
                  <Focusable
                    key={`t${t.id}`}
                    hasTVPreferredFocus={audioTracks.length === 0 && selected}
                    style={[styles.trackRow, selected && styles.trackActive]}
                    onPress={() => setTextTrack(t.id)}>
                    <Text style={styles.trackText} numberOfLines={1}>
                      {t.id === -1 ? 'Aucun' : t.name}
                    </Text>
                    {selected && <Text style={styles.check}>✓</Text>}
                  </Focusable>
                );
              })}
              {textTracks.filter(t => t.id !== -1).length === 0 && (
                <Text style={styles.panelEmpty}>Aucun sous-titre dans ce fichier</Text>
              )}
            </ScrollView>
            <Focusable style={styles.closeBtn} onPress={() => setPanel(false)}>
              <Text style={styles.errBtnText}>Fermer</Text>
            </Focusable>
          </View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000', justifyContent: 'center' },
  spinner: { position: 'absolute', alignSelf: 'center' },
  errorBox: {
    position: 'absolute',
    alignSelf: 'center',
    backgroundColor: 'rgba(7,10,18,0.9)',
    padding: 22,
    borderRadius: 16,
    maxWidth: 560,
  },
  errorText: { color: colors.text, fontSize: 17, fontWeight: '700', textAlign: 'center' },
  errorButtons: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, justifyContent: 'center', marginTop: 16 },
  errBtn: {
    paddingHorizontal: 20,
    paddingVertical: 11,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: colors.border,
    backgroundColor: colors.panelAlt,
  },
  vlcBtn: { backgroundColor: '#f97316', borderColor: '#f97316' },
  errBtnText: { color: '#fff', fontSize: 15, fontWeight: '800' },
  topBar: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    paddingHorizontal: 28,
    paddingVertical: 18,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 20,
    backgroundColor: 'rgba(7,10,18,0.6)',
  },
  title: { color: '#fff', fontSize: 20, fontWeight: '800', flex: 1 },
  bottom: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 28,
    paddingTop: 18,
    paddingBottom: 20,
    backgroundColor: 'rgba(7,10,18,0.72)',
  },
  barTouch: { paddingVertical: 10 },
  track: { height: 6, borderRadius: 3, backgroundColor: 'rgba(255,255,255,0.2)' },
  fill: { height: 6, borderRadius: 3, backgroundColor: colors.accent },
  knob: {
    position: 'absolute',
    top: -5,
    width: 16,
    height: 16,
    marginLeft: -8,
    borderRadius: 8,
    backgroundColor: '#fff',
  },
  controlsRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 6 },
  time: { color: colors.text, fontSize: 13, fontWeight: '700', minWidth: 56 },
  buttons: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  ctrlBtn: {
    minWidth: 50,
    height: 46,
    borderRadius: 23,
    paddingHorizontal: 10,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.1)',
  },
  playBtn: { width: 64, height: 64, borderRadius: 32, backgroundColor: colors.accent },
  ctrlText: { color: '#fff', fontSize: 15, fontWeight: '800' },
  hint: { color: colors.muted, fontSize: 12, textAlign: 'center', marginTop: 10 },
  panelWrap: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.45)', alignItems: 'flex-end' },
  panel: {
    width: 380,
    maxWidth: '88%',
    height: '100%',
    backgroundColor: 'rgba(12,16,28,0.97)',
    borderLeftWidth: 1,
    borderLeftColor: colors.border,
    paddingHorizontal: 20,
    paddingTop: 28,
    paddingBottom: 20,
  },
  panelTitle: { color: colors.text, fontSize: 17, fontWeight: '900', marginBottom: 10 },
  panelEmpty: { color: colors.muted, fontSize: 13, marginBottom: 6 },
  trackRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 14,
    paddingVertical: 11,
    marginBottom: 6,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: 'transparent',
    backgroundColor: colors.panel,
  },
  trackActive: { backgroundColor: 'rgba(79,140,255,0.2)', borderColor: 'rgba(79,140,255,0.5)' },
  trackText: { color: colors.text, fontSize: 15, flex: 1 },
  check: { color: colors.accent, fontSize: 18, fontWeight: '900', marginLeft: 8 },
  closeBtn: {
    marginTop: 12,
    paddingVertical: 12,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: colors.border,
    backgroundColor: colors.panelAlt,
    alignItems: 'center',
  },
});
