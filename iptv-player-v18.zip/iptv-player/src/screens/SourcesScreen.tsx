import React, { useCallback, useState } from 'react';
import { Alert, ScrollView, StyleSheet, Text, View } from 'react-native';
import { ScreenProps, useFocusEffect } from '../nav/Navigator';
import Focusable from '../components/Focusable';
import Logo from '../components/Logo';
import Clock from '../components/Clock';
import { getSources, removeSource } from '../storage';
import { colors } from '../theme';
import { Source } from '../types';
import { openSource } from '../navigation';

type Props = ScreenProps<'Sources'>;

const host = (s: string) => s.replace(/^https?:\/\//i, '').split('/')[0];

export default function SourcesScreen({ navigation }: Props) {
  const [sources, setSources] = useState<Source[]>([]);

  useFocusEffect(
    useCallback(() => {
      getSources().then(setSources);
    }, []),
  );

  const confirmDelete = (s: Source) => {
    Alert.alert('Supprimer', `Supprimer « ${s.name} » ?`, [
      { text: 'Annuler', style: 'cancel' },
      {
        text: 'Supprimer',
        style: 'destructive',
        onPress: async () => {
          await removeSource(s.id);
          setSources(await getSources());
        },
      },
    ]);
  };

  return (
    <ScrollView contentContainerStyle={styles.content}>
      <View style={styles.top}>
        <Logo size={34} />
        <Clock />
      </View>

      <View style={styles.inner}>
        <Text style={styles.h1}>Bienvenue</Text>
        <Text style={styles.sub}>Choisis la liste à ouvrir</Text>

        {sources.map((s, i) => (
          <Focusable
            key={s.id}
            hasTVPreferredFocus={i === 0}
            scale={1.02}
            style={styles.card}
            onPress={() => openSource(navigation, s)}
            onLongPress={() => confirmDelete(s)}>
            <View style={[styles.iconBox, { backgroundColor: 'rgba(79,140,255,0.16)' }]}>
              <Text style={styles.icon}>{s.type === 'xtream' ? '📡' : '📄'}</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.name} numberOfLines={1}>
                {s.name}
              </Text>
              <Text style={styles.meta} numberOfLines={1}>
                {s.type === 'xtream' ? `Xtream Codes · ${host(s.server)}` : 'Liste M3U'}
              </Text>
            </View>
            <Text style={styles.chevron}>›</Text>
          </Focusable>
        ))}

        <Focusable
          hasTVPreferredFocus={sources.length === 0}
          scale={1.02}
          style={[styles.card, styles.addCard]}
          onPress={() => navigation.navigate('AddSource')}>
          <View style={[styles.iconBox, { backgroundColor: colors.accent }]}>
            <Text style={[styles.icon, { color: '#fff', fontWeight: '900' }]}>+</Text>
          </View>
          <Text style={styles.addText}>Ajouter une liste</Text>
        </Focusable>

        {sources.length > 0 && (
          <Text style={styles.hint}>Appui long sur une liste pour la supprimer</Text>
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  content: { padding: 28, flexGrow: 1 },
  top: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  inner: { width: '100%', maxWidth: 640, alignSelf: 'center', marginTop: 36 },
  h1: { color: colors.text, fontSize: 34, fontWeight: '900' },
  sub: { color: colors.muted, fontSize: 16, marginTop: 4, marginBottom: 24 },
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    padding: 16,
    marginBottom: 12,
    borderRadius: 18,
    borderWidth: 2,
    borderColor: colors.border,
    backgroundColor: colors.panel,
  },
  addCard: { borderStyle: 'dashed', borderColor: 'rgba(79,140,255,0.45)' },
  iconBox: { width: 52, height: 52, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  icon: { fontSize: 26 },
  name: { color: colors.text, fontSize: 19, fontWeight: '700' },
  meta: { color: colors.muted, fontSize: 14, marginTop: 3 },
  chevron: { color: colors.muted, fontSize: 30 },
  addText: { color: colors.text, fontSize: 18, fontWeight: '700' },
  hint: { color: colors.muted, fontSize: 12, textAlign: 'center', marginTop: 10 },
});
