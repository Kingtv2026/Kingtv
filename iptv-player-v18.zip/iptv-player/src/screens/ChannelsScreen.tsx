import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  BackHandler,
  FlatList,
  Image,
  StyleSheet,
  Text,
  TextInput,
  useWindowDimensions,
  View,
} from 'react-native';
import Video from 'react-native-video';
import { ScreenProps, useIsFocused } from '../nav/Navigator';
import Focusable from '../components/Focusable';
import NowNext from '../components/NowNext';
import { loadPlaylist } from '../api';
import { getNowNext } from '../api/epg';
import { setQueue } from '../playerQueue';
import { getFavorites, toggleFavorite } from '../storage';
import { colors } from '../theme';
import { CAT_ALL, CAT_FAVORITES, Category, Channel, Playlist, Program } from '../types';

type Props = ScreenProps<'Channels'>;

const ROW_HEIGHT = 66;

export default function ChannelsScreen({ route, navigation }: Props) {
  const { source, initialCategory } = route.params;
  const isFocused = useIsFocused();
  const { width } = useWindowDimensions();
  const wide = width >= 700; // télé / tablette : 3 colonnes avec aperçu

  const [playlist, setPlaylist] = useState<Playlist | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [categoryId, setCategoryId] = useState<string>(initialCategory ?? CAT_ALL);
  const [search, setSearch] = useState('');
  // Téléphone : d'abord la liste des groupes, puis les chaînes du groupe
  const [showGroups, setShowGroups] = useState(!initialCategory);
  useEffect(() => {
    if (!isFocused || wide || showGroups) {
      return;
    }
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      setShowGroups(true);
      return true;
    });
    return () => sub.remove();
  }, [isFocused, wide, showGroups]);
  const [preview, setPreview] = useState<Channel | null>(null);
  const [previewError, setPreviewError] = useState(false);
  const [focused, setFocused] = useState<Channel | null>(null);
  const [epg, setEpg] = useState<Program[] | null>(null);

  const load = useCallback(async () => {
    setError(null);
    setPlaylist(null);
    try {
      const [pl, favs] = await Promise.all([loadPlaylist(source), getFavorites(source.id)]);
      setPlaylist(pl);
      setFavorites(favs);
    } catch (e: any) {
      setError(e?.message || 'Chargement impossible');
    }
  }, [source]);

  useEffect(() => {
    navigation.setOptions({ title: 'TV en direct' });
    load();
  }, [load, navigation]);

  const counts = useMemo(() => {
    const m = new Map<string, number>();
    for (const c of playlist?.channels || []) {
      m.set(c.categoryId, (m.get(c.categoryId) || 0) + 1);
    }
    return m;
  }, [playlist]);

  const categories: Category[] = useMemo(
    () => [
      { id: CAT_ALL, name: 'Toutes les chaînes' },
      { id: CAT_FAVORITES, name: '★  Favoris' },
      ...(playlist?.categories || []),
    ],
    [playlist],
  );

  const countOf = (id: string) =>
    id === CAT_ALL
      ? playlist?.channels.length || 0
      : id === CAT_FAVORITES
        ? favorites.length
        : counts.get(id) || 0;

  const channels: Channel[] = useMemo(() => {
    if (!playlist) {
      return [];
    }
    let list = playlist.channels;
    if (categoryId === CAT_FAVORITES) {
      list = list.filter(c => favorites.includes(c.id));
    } else if (categoryId !== CAT_ALL) {
      list = list.filter(c => c.categoryId === categoryId);
    }
    const q = search.trim().toLowerCase();
    if (q) {
      list = list.filter(c => c.name.toLowerCase().includes(q));
    }
    return list;
  }, [playlist, categoryId, favorites, search]);

  // Guide horaire de la chaîne survolée (ou de l'aperçu)
  const epgTarget = focused ?? preview;
  useEffect(() => {
    if (!wide || !epgTarget) {
      return;
    }
    setEpg(null);
    let cancelled = false;
    const t = setTimeout(async () => {
      const data = await getNowNext(source, epgTarget);
      if (!cancelled) {
        setEpg(data);
      }
    }, 300);
    return () => {
      cancelled = true;
      clearTimeout(t);
    };
  }, [epgTarget, wide, source]);

  const openFull = (index: number) => {
    setQueue(channels, source);
    navigation.navigate('Player', { index });
  };

  // Télé : 1er OK = aperçu, 2e OK = plein écran. Téléphone : plein écran direct.
  const onChannelPress = (ch: Channel, index: number) => {
    if (!wide || preview?.id === ch.id) {
      if (preview) {
        // on coupe l'aperçu avant le plein écran : une seule connexion au serveur
        setPreview(null);
        setTimeout(() => openFull(index), 600);
      } else {
        openFull(index);
      }
    } else {
      setPreview(ch);
      setPreviewError(false);
    }
  };

  const onToggleFav = async (ch: Channel) => {
    setFavorites(await toggleFavorite(source.id, ch.id));
  };

  if (error) {
    return (
      <View style={styles.center}>
        <Text style={styles.error}>{error}</Text>
        <Focusable hasTVPreferredFocus style={styles.retry} onPress={load}>
          <Text style={styles.retryText}>Réessayer</Text>
        </Focusable>
      </View>
    );
  }

  if (!playlist) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={colors.accent} />
        <Text style={styles.muted}>Chargement des chaînes…</Text>
      </View>
    );
  }

  // ---- Téléphone : écran des groupes ----
  if (!wide && showGroups) {
    return (
      <FlatList
        data={categories}
        keyExtractor={c => c.id}
        contentContainerStyle={{ padding: 16, paddingBottom: 30 }}
        ListHeaderComponent={<Text style={styles.groupsTitle}>Groupes de chaînes</Text>}
        renderItem={({ item, index }) => (
          <Focusable
            hasTVPreferredFocus={index === 0}
            style={styles.groupRow}
            onPress={() => {
              setCategoryId(item.id);
              setSearch('');
              setShowGroups(false);
            }}>
            <Text style={styles.groupIcon}>
              {item.id === CAT_FAVORITES ? '⭐' : item.id === CAT_ALL ? '📺' : '📁'}
            </Text>
            <Text style={styles.groupName} numberOfLines={1}>
              {item.name.replace('★  ', '')}
            </Text>
            <View style={styles.countBadge}>
              <Text style={styles.countText}>{countOf(item.id)}</Text>
            </View>
            <Text style={styles.chev}>›</Text>
          </Focusable>
        )}
      />
    );
  }

  const groupName = categories.find(c => c.id === categoryId)?.name.replace('★  ', '') ?? '';

  return (
    <View style={[styles.container, wide && { flexDirection: 'row' }]}>
      {/* Catégories (télé) */}
      {wide && (
      <FlatList
        data={categories}
        horizontal={!wide}
        keyExtractor={c => c.id}
        style={wide ? styles.catColumn : styles.catBar}
        contentContainerStyle={wide ? { paddingVertical: 4 } : { paddingHorizontal: 16 }}
        showsHorizontalScrollIndicator={false}
        renderItem={({ item, index }) => {
          const active = item.id === categoryId;
          return (
            <Focusable
              hasTVPreferredFocus={index === 0 && !initialCategory}
              style={[wide ? styles.catRow : styles.catChip, active && styles.catActive]}
              onFocus={() => wide && setCategoryId(item.id)}
              onPress={() => setCategoryId(item.id)}>
              <Text style={[styles.catText, active && { color: '#fff', fontWeight: '800' }]} numberOfLines={1}>
                {item.name}
              </Text>
              {wide && (
                <View style={[styles.countBadge, active && { backgroundColor: colors.accent }]}>
                  <Text style={styles.countText}>{countOf(item.id)}</Text>
                </View>
              )}
            </Focusable>
          );
        }}
      />
      )}

      {/* Chaînes */}
      <View style={styles.channelPane}>
        {!wide && (
          <View style={styles.groupBar}>
            <Focusable style={styles.backGroups} onPress={() => setShowGroups(true)}>
              <Text style={styles.backGroupsText}>‹  Groupes</Text>
            </Focusable>
            <Text style={styles.groupBarTitle} numberOfLines={1}>
              {groupName}
            </Text>
          </View>
        )}
        <View style={styles.searchRow}>
          <TextInput
            value={search}
            onChangeText={setSearch}
            placeholder="🔍  Rechercher une chaîne"
            placeholderTextColor={colors.muted}
            style={[styles.search, { flex: 1 }]}
            autoCorrect={false}
          />
          {source.type === 'xtream' && (
            <Focusable
              style={styles.guideBtn}
              onPress={() => navigation.navigate('Guide', { source })}>
              <Text style={styles.guideText}>📅 Guide</Text>
            </Focusable>
          )}
        </View>
        <Text style={styles.count}>
          {channels.length} chaîne{channels.length > 1 ? 's' : ''}  ·  appui long = favori
        </Text>
        <FlatList
          data={channels}
          keyExtractor={c => c.id}
          initialNumToRender={20}
          windowSize={11}
          getItemLayout={(_, i) => ({ length: ROW_HEIGHT, offset: ROW_HEIGHT * i, index: i })}
          ListEmptyComponent={<Text style={styles.muted}>Aucune chaîne ici.</Text>}
          renderItem={({ item, index }) => {
            const isPreview = preview?.id === item.id;
            const fav = favorites.includes(item.id);
            const archive = source.type === 'xtream' && (item.archiveDays || 0) > 0;
            return (
              <View style={styles.rowWrap}>
              <Focusable
                hasTVPreferredFocus={index === 0 && !!initialCategory}
                style={[styles.channelRow, { flex: 1 }, isPreview && styles.channelActive]}
                onFocus={() => setFocused(item)}
                onPress={() => onChannelPress(item, index)}
                onLongPress={() => onToggleFav(item)}>
                <Text style={styles.num}>{index + 1}</Text>
                <View style={styles.logoBox}>
                  {item.logo ? (
                    <Image source={{ uri: item.logo }} style={styles.logo} resizeMode="contain" />
                  ) : (
                    <Text style={styles.logoLetter}>{item.name.charAt(0)}</Text>
                  )}
                </View>
                <Text style={[styles.channelName, isPreview && { color: '#fff' }]} numberOfLines={1}>
                  {item.name}
                </Text>
                {fav && <Text style={styles.star}>★</Text>}
                {isPreview && (
                  <View style={styles.playingPill}>
                    <Text style={styles.playingText}>▶</Text>
                  </View>
                )}
              </Focusable>
              {archive && source.type === 'xtream' && (
                <Focusable
                  style={styles.catchupBtn}
                  onPress={() => navigation.navigate('Catchup', { source, channel: item })}>
                  <Text style={styles.catchupIcon}>⏪</Text>
                  <Text style={styles.catchupDays}>{item.archiveDays} j</Text>
                </Focusable>
              )}
              </View>
            );
          }}
        />
      </View>

      {/* Aperçu + guide (télé) */}
      {wide && (
        <View style={styles.previewPane}>
          <View style={styles.previewBox}>
            {preview && isFocused && !previewError ? (
              <Video
                key={preview.streamUrl}
                source={{ uri: preview.streamUrl }}
                style={StyleSheet.absoluteFill}
                resizeMode="contain"
                onError={() => setPreviewError(true)}
              />
            ) : (
              <View style={styles.previewEmpty}>
                <Text style={styles.previewIcon}>{previewError ? '⚠️' : '📺'}</Text>
                <Text style={styles.previewHint}>
                  {previewError ? 'Cette chaîne ne joue pas en ce moment' : 'OK sur une chaîne pour l’aperçu'}
                </Text>
              </View>
            )}
            {preview && !previewError && (
              <View style={styles.liveBadge}>
                <View style={styles.liveDot} />
                <Text style={styles.liveText}>EN DIRECT</Text>
              </View>
            )}
          </View>
          {preview && <Text style={styles.previewHelp}>OK une 2e fois = plein écran</Text>}

          {epgTarget && (
            <View style={styles.infoCard}>
              <View style={styles.infoHead}>
                <View style={[styles.logoBox, { width: 64, height: 44 }]}>
                  {epgTarget.logo ? (
                    <Image source={{ uri: epgTarget.logo }} style={styles.logo} resizeMode="contain" />
                  ) : (
                    <Text style={styles.logoLetter}>{epgTarget.name.charAt(0)}</Text>
                  )}
                </View>
                <Text style={styles.infoName} numberOfLines={2}>
                  {epgTarget.name}
                </Text>
              </View>
              {epg === null ? (
                <ActivityIndicator color={colors.accent} />
              ) : (
                <NowNext programs={epg} showDescription />
              )}
            </View>
          )}
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, paddingBottom: 12 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24, gap: 12 },
  muted: { color: colors.muted, fontSize: 15, padding: 12 },
  error: { color: colors.danger, fontSize: 16, textAlign: 'center' },
  retry: {
    backgroundColor: colors.panel,
    borderWidth: 2,
    borderColor: colors.border,
    borderRadius: 12,
    paddingHorizontal: 24,
    paddingVertical: 12,
  },
  retryText: { color: colors.text, fontSize: 16, fontWeight: '700' },

  catColumn: { width: 270, flexGrow: 0, paddingLeft: 16 },
  catBar: { flexGrow: 0, paddingVertical: 8 },
  catRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 14,
    paddingVertical: 11,
    marginBottom: 4,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  catChip: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginRight: 8,
    borderRadius: 20,
    borderWidth: 2,
    borderColor: colors.border,
    backgroundColor: colors.panel,
  },
  catActive: { backgroundColor: 'rgba(79,140,255,0.18)', borderColor: 'rgba(79,140,255,0.45)' },
  catText: { color: colors.text, fontSize: 15, flex: 1 },
  countBadge: {
    minWidth: 30,
    paddingHorizontal: 7,
    paddingVertical: 2,
    borderRadius: 10,
    backgroundColor: colors.panelAlt,
    alignItems: 'center',
    marginLeft: 8,
  },
  countText: { color: colors.text, fontSize: 12, fontWeight: '700' },

  channelPane: { flex: 1, paddingHorizontal: 16 },
  rowWrap: { flexDirection: 'row', gap: 8 },
  catchupBtn: {
    height: ROW_HEIGHT - 8,
    width: 58,
    marginBottom: 8,
    borderRadius: 14,
    borderWidth: 2,
    borderColor: 'rgba(168,85,247,0.45)',
    backgroundColor: 'rgba(168,85,247,0.16)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  catchupIcon: { fontSize: 16 },
  catchupDays: { color: colors.text, fontSize: 11, fontWeight: '800', marginTop: 1 },
  searchRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  guideBtn: {
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 14,
    borderWidth: 2,
    borderColor: 'rgba(34,211,238,0.5)',
    backgroundColor: 'rgba(34,211,238,0.15)',
  },
  guideText: { color: '#fff', fontSize: 14, fontWeight: '800' },
  groupsTitle: { color: colors.text, fontSize: 22, fontWeight: '900', marginBottom: 12, marginLeft: 4 },
  groupRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: 14,
    paddingVertical: 14,
    marginBottom: 8,
    borderRadius: 14,
    borderWidth: 2,
    borderColor: colors.border,
    backgroundColor: colors.panel,
  },
  groupIcon: { fontSize: 20 },
  groupName: { color: colors.text, fontSize: 17, fontWeight: '700', flex: 1 },
  chev: { color: colors.muted, fontSize: 24, marginLeft: 4 },
  groupBar: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 10 },
  backGroups: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 18,
    borderWidth: 2,
    borderColor: 'rgba(79,140,255,0.45)',
    backgroundColor: 'rgba(79,140,255,0.18)',
  },
  backGroupsText: { color: '#fff', fontSize: 14, fontWeight: '800' },
  groupBarTitle: { color: colors.text, fontSize: 18, fontWeight: '900', flex: 1 },
  search: {
    backgroundColor: colors.panel,
    color: colors.text,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: 16,
    paddingVertical: 10,
    fontSize: 15,
  },
  count: { color: colors.muted, fontSize: 12, marginVertical: 8, marginLeft: 4 },
  channelRow: {
    height: ROW_HEIGHT - 8,
    marginBottom: 8,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    borderRadius: 14,
    borderWidth: 2,
    borderColor: 'transparent',
    backgroundColor: colors.panel,
  },
  channelActive: { backgroundColor: 'rgba(255,59,92,0.16)', borderColor: 'rgba(255,59,92,0.5)' },
  num: { color: colors.muted, fontSize: 14, fontWeight: '700', width: 40 },
  logoBox: {
    width: 56,
    height: 40,
    borderRadius: 8,
    backgroundColor: 'rgba(255,255,255,0.07)',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 14,
    overflow: 'hidden',
  },
  logo: { width: '86%', height: '86%' },
  logoLetter: { color: colors.muted, fontSize: 18, fontWeight: '900' },
  channelName: { color: colors.text, fontSize: 16, fontWeight: '600', flex: 1 },
  star: { color: colors.star, fontSize: 18, marginLeft: 8 },
  playingPill: {
    marginLeft: 10,
    backgroundColor: colors.live,
    borderRadius: 10,
    paddingHorizontal: 8,
    paddingVertical: 2,
  },
  playingText: { color: '#fff', fontSize: 12, fontWeight: '900' },

  previewPane: { width: '38%', paddingRight: 20 },
  previewBox: {
    width: '100%',
    aspectRatio: 16 / 9,
    borderRadius: 16,
    overflow: 'hidden',
    backgroundColor: '#000',
    borderWidth: 1,
    borderColor: colors.border,
  },
  previewEmpty: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 8 },
  previewIcon: { fontSize: 34 },
  previewHint: { color: colors.muted, fontSize: 14, textAlign: 'center', paddingHorizontal: 16 },
  liveBadge: {
    position: 'absolute',
    top: 10,
    left: 10,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(0,0,0,0.6)',
    borderRadius: 8,
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  liveDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: colors.live },
  liveText: { color: '#fff', fontSize: 11, fontWeight: '900', letterSpacing: 1 },
  previewHelp: { color: colors.muted, fontSize: 12, marginTop: 8, textAlign: 'center' },
  infoCard: {
    marginTop: 14,
    padding: 18,
    borderRadius: 16,
    backgroundColor: colors.panel,
    borderWidth: 1,
    borderColor: colors.border,
  },
  infoHead: { flexDirection: 'row', alignItems: 'center', marginBottom: 14 },
  infoName: { color: colors.text, fontSize: 19, fontWeight: '800', flex: 1 },
});
