/**
 * Guide horaire en grille (style MyTVOnline) :
 * chaînes à gauche, heures en haut, émissions en blocs, ligne rouge = maintenant.
 */
import React, { memo, useCallback, useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  BackHandler,
  FlatList,
  Image,
  StyleSheet,
  Text,
  useWindowDimensions,
  View,
} from 'react-native';
import { ScreenProps, useIsFocused } from '../nav/Navigator';
import Focusable from '../components/Focusable';
import { loadPlaylist } from '../api';
import { formatTime, getPrograms } from '../api/epg';
import { setQueue } from '../playerQueue';
import { getFavorites } from '../storage';
import { colors } from '../theme';
import { CAT_ALL, CAT_FAVORITES, Category, Channel, Playlist, Program, Source } from '../types';

type Props = ScreenProps<'Guide'>;

const SLOT_MIN = 30;
const MIN = 60 * 1000;

const JOURS = ['dim.', 'lun.', 'mar.', 'mer.', 'jeu.', 'ven.', 'sam.'];

export default function GuideScreen({ route, navigation }: Props) {
  const { source } = route.params;
  const isFocused = useIsFocused();
  const { width } = useWindowDimensions();
  const wide = width >= 700;

  // Dimensions de la grille
  const CH_W = wide ? 230 : 104;
  const ROW_H = wide ? 64 : 58;
  const WINDOW_MIN = wide ? 180 : 120;
  const gridW = width - CH_W - (wide ? 36 : 12);
  const pxPerMin = gridW / WINDOW_MIN;

  const [playlist, setPlaylist] = useState<Playlist | null>(null);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [categoryId, setCategoryId] = useState<string | null>(null);
  const [picker, setPicker] = useState(false);
  const [now, setNow] = useState(Date.now());
  const [offset, setOffset] = useState(0); // en tranches de 30 min
  const [selected, setSelected] = useState<{ channel: Channel; program: Program } | null>(null);

  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 30000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    Promise.all([loadPlaylist(source), getFavorites(source.id)])
      .then(([pl, favs]) => {
        setPlaylist(pl);
        setFavorites(favs);
        setCategoryId(favs.length > 0 ? CAT_FAVORITES : pl.categories[0]?.id ?? CAT_ALL);
      })
      .catch(e => setError(e?.message || 'Chargement impossible'));
  }, [source]);

  // Retour : ferme la liste des groupes
  useEffect(() => {
    if (!picker || !isFocused) {
      return;
    }
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      setPicker(false);
      return true;
    });
    return () => sub.remove();
  }, [picker, isFocused]);

  const categories: Category[] = useMemo(
    () => [
      { id: CAT_FAVORITES, name: '⭐ Favoris' },
      { id: CAT_ALL, name: 'Toutes les chaînes' },
      ...(playlist?.categories || []),
    ],
    [playlist],
  );

  const channels = useMemo(() => {
    if (!playlist) {
      return [];
    }
    if (categoryId === CAT_FAVORITES) {
      return playlist.channels.filter(c => favorites.includes(c.id));
    }
    if (categoryId === CAT_ALL) {
      return playlist.channels;
    }
    return playlist.channels.filter(c => c.categoryId === categoryId);
  }, [playlist, categoryId, favorites]);

  // Fenêtre de temps affichée
  const base = Math.floor(now / (SLOT_MIN * MIN)) * SLOT_MIN * MIN;
  const winStart = base + offset * SLOT_MIN * MIN;
  const winEnd = winStart + WINDOW_MIN * MIN;
  const slots = Array.from({ length: WINDOW_MIN / SLOT_MIN }, (_, i) => winStart + i * SLOT_MIN * MIN);
  const nowX = (now - winStart) / MIN * pxPerMin;
  const winDay = new Date(winStart);

  const play = useCallback(
    (index: number) => {
      setQueue(channels, source);
      navigation.navigate('Player', { index });
    },
    [channels, source, navigation],
  );

  const onPressProgram = useCallback(
    (index: number, channel: Channel, program: Program) => {
      const t = Date.now();
      if (program.start <= t && program.end > t) {
        play(index);
      } else {
        setSelected({ channel, program });
      }
    },
    [play],
  );

  const onFocusProgram = useCallback((channel: Channel, program: Program) => {
    setSelected({ channel, program });
  }, []);

  if (error) {
    return (
      <View style={styles.center}>
        <Text style={styles.error}>{error}</Text>
      </View>
    );
  }
  if (!playlist || !categoryId) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={colors.accent} />
        <Text style={styles.muted}>Chargement du guide…</Text>
      </View>
    );
  }

  const catName = categories.find(c => c.id === categoryId)?.name ?? '';
  const sel = selected?.program;

  return (
    <View style={styles.container}>
      {/* Fiche de l'émission choisie */}
      <View style={[styles.info, { height: wide ? 128 : 104 }]}>
        {sel && selected ? (
          <>
            <Text style={styles.infoChannel} numberOfLines={1}>
              {selected.channel.name}
            </Text>
            <Text style={styles.infoTitle} numberOfLines={1}>
              {sel.title || 'Sans titre'}
            </Text>
            <Text style={styles.infoTime}>
              {JOURS[new Date(sel.start).getDay()]} {formatTime(sel.start)} – {formatTime(sel.end)}
              {sel.start <= now && sel.end > now ? '   ●  EN COURS · OK pour regarder' : ''}
            </Text>
            {!!sel.description && (
              <Text style={styles.infoDesc} numberOfLines={wide ? 2 : 1}>
                {sel.description}
              </Text>
            )}
          </>
        ) : (
          <Text style={styles.muted}>
            Choisis une émission pour voir son résumé. Une émission en cours = lecture de la chaîne.
          </Text>
        )}
      </View>

      {/* Barre : groupe + navigation dans le temps */}
      <View style={styles.toolbar}>
        <Focusable style={styles.groupBtn} onPress={() => setPicker(true)}>
          <Text style={styles.groupBtnText} numberOfLines={1}>
            {catName}  ▾
          </Text>
        </Focusable>
        <Focusable style={styles.timeBtn} onPress={() => setOffset(o => Math.max(o - 1, -2))}>
          <Text style={styles.timeBtnText}>◀</Text>
        </Focusable>
        <Focusable style={styles.timeBtn} onPress={() => setOffset(0)}>
          <Text style={styles.timeBtnText}>Maintenant</Text>
        </Focusable>
        <Focusable style={styles.timeBtn} onPress={() => setOffset(o => Math.min(o + 1, 40))}>
          <Text style={styles.timeBtnText}>▶</Text>
        </Focusable>
      </View>

      {/* Règle des heures */}
      <View style={styles.ruler}>
        <View style={{ width: CH_W, justifyContent: 'center', paddingLeft: 6 }}>
          <Text style={styles.dayText}>
            {JOURS[winDay.getDay()]} {winDay.getDate()}
          </Text>
        </View>
        <View style={{ width: gridW, height: 28 }}>
          {slots.map(t => (
            <Text key={t} style={[styles.slotText, { left: (t - winStart) / MIN * pxPerMin + 4 }]}>
              {formatTime(t)}
            </Text>
          ))}
        </View>
      </View>

      {/* Grille */}
      <View style={{ flex: 1 }}>
        <FlatList
          data={channels}
          keyExtractor={c => c.id}
          initialNumToRender={10}
          windowSize={5}
          getItemLayout={(_, i) => ({ length: ROW_H, offset: ROW_H * i, index: i })}
          ListEmptyComponent={
            <Text style={styles.muted}>
              {categoryId === CAT_FAVORITES
                ? 'Aucun favori. Ajoute des chaînes en favori (appui long) dans TV en direct.'
                : 'Aucune chaîne dans ce groupe.'}
            </Text>
          }
          renderItem={({ item, index }) => (
            <GuideRow
              source={source}
              channel={item}
              index={index}
              preferred={index === 0}
              chW={CH_W}
              rowH={ROW_H}
              gridW={gridW}
              winStart={winStart}
              winEnd={winEnd}
              pxPerMin={pxPerMin}
              now={now}
              wide={wide}
              onPlay={play}
              onFocusProgram={onFocusProgram}
              onPressProgram={onPressProgram}
            />
          )}
        />
        {nowX >= 0 && nowX <= gridW && (
          <View pointerEvents="none" style={[styles.nowLine, { left: CH_W + nowX }]} />
        )}
      </View>

      {/* Liste des groupes */}
      {picker && (
        <View style={styles.pickerWrap}>
          <View style={styles.picker}>
            <Text style={styles.pickerTitle}>Groupes</Text>
            <FlatList
              data={categories}
              keyExtractor={c => c.id}
              renderItem={({ item }) => (
                <Focusable
                  hasTVPreferredFocus={item.id === categoryId}
                  style={[styles.pickRow, item.id === categoryId && styles.pickActive]}
                  onPress={() => {
                    setCategoryId(item.id);
                    setSelected(null);
                    setPicker(false);
                  }}>
                  <Text style={styles.pickText} numberOfLines={1}>
                    {item.name}
                  </Text>
                </Focusable>
              )}
            />
            <Focusable style={styles.closeBtn} onPress={() => setPicker(false)}>
              <Text style={styles.timeBtnText}>Fermer</Text>
            </Focusable>
          </View>
        </View>
      )}
    </View>
  );
}

const GuideRow = memo(function GuideRow({
  source,
  channel,
  index,
  preferred,
  chW,
  rowH,
  gridW,
  winStart,
  winEnd,
  pxPerMin,
  now,
  wide,
  onPlay,
  onFocusProgram,
  onPressProgram,
}: {
  source: Source;
  channel: Channel;
  index: number;
  preferred: boolean;
  chW: number;
  rowH: number;
  gridW: number;
  winStart: number;
  winEnd: number;
  pxPerMin: number;
  now: number;
  wide: boolean;
  onPlay: (index: number) => void;
  onFocusProgram: (c: Channel, p: Program) => void;
  onPressProgram: (i: number, c: Channel, p: Program) => void;
}) {
  const [programs, setPrograms] = useState<Program[] | null>(null);

  useEffect(() => {
    let cancelled = false;
    getPrograms(source, channel).then(p => {
      if (!cancelled) {
        setPrograms(p);
      }
    });
    return () => {
      cancelled = true;
    };
  }, [source, channel]);

  const visible = (programs || []).filter(p => p.end > winStart && p.start < winEnd);

  return (
    <View style={[styles.row, { height: rowH }]}>
      <Focusable
        hasTVPreferredFocus={preferred}
        style={[styles.chCell, { width: chW - 4, height: rowH - 4 }]}
        onPress={() => onPlay(index)}>
        <Text style={styles.chNum}>{index + 1}</Text>
        {channel.logo ? (
          <Image source={{ uri: channel.logo }} style={wide ? styles.chLogo : styles.chLogoSmall} resizeMode="contain" />
        ) : null}
        {(wide || !channel.logo) && (
          <Text style={styles.chName} numberOfLines={2}>
            {channel.name}
          </Text>
        )}
      </Focusable>

      <View style={{ width: gridW, height: rowH }}>
        {programs === null ? (
          <View style={[styles.empty, { width: gridW }]}>
            <ActivityIndicator size="small" color={colors.muted} />
          </View>
        ) : visible.length === 0 ? (
          <View style={[styles.empty, { width: gridW }]}>
            <Text style={styles.emptyText}>Pas d’information</Text>
          </View>
        ) : (
          visible.map(p => {
            const s = Math.max(p.start, winStart);
            const e = Math.min(p.end, winEnd);
            const left = (s - winStart) / MIN * pxPerMin;
            const w = (e - s) / MIN * pxPerMin;
            const live = p.start <= now && p.end > now;
            const past = p.end <= now;
            return (
              <Focusable
                key={`${p.start}`}
                style={[
                  styles.prog,
                  { left, width: Math.max(w - 3, 6) },
                  live && styles.progLive,
                  past && styles.progPast,
                ]}
                onFocus={() => onFocusProgram(channel, p)}
                onPress={() => onPressProgram(index, channel, p)}>
                <Text style={[styles.progTitle, past && { color: colors.muted }]} numberOfLines={1}>
                  {p.title || '—'}
                </Text>
                {w > 80 && (
                  <Text style={styles.progTime} numberOfLines={1}>
                    {formatTime(p.start)} – {formatTime(p.end)}
                  </Text>
                )}
              </Focusable>
            );
          })
        )}
      </View>
    </View>
  );
});

const styles = StyleSheet.create({
  container: { flex: 1, paddingHorizontal: 6 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12 },
  error: { color: colors.danger, fontSize: 16, padding: 24, textAlign: 'center' },
  muted: { color: colors.muted, fontSize: 14, padding: 10 },

  info: {
    marginHorizontal: 6,
    marginBottom: 8,
    padding: 14,
    borderRadius: 16,
    backgroundColor: colors.panel,
    borderWidth: 1,
    borderColor: colors.border,
    justifyContent: 'center',
  },
  infoChannel: { color: colors.accent, fontSize: 12, fontWeight: '800', letterSpacing: 0.5 },
  infoTitle: { color: colors.text, fontSize: 19, fontWeight: '900', marginTop: 2 },
  infoTime: { color: colors.muted, fontSize: 13, marginTop: 3 },
  infoDesc: { color: 'rgba(244,246,251,0.8)', fontSize: 13, marginTop: 5 },

  toolbar: { flexDirection: 'row', alignItems: 'center', gap: 8, marginHorizontal: 6, marginBottom: 6 },
  groupBtn: {
    flex: 1,
    paddingHorizontal: 14,
    paddingVertical: 9,
    borderRadius: 14,
    borderWidth: 2,
    borderColor: 'rgba(79,140,255,0.45)',
    backgroundColor: 'rgba(79,140,255,0.18)',
  },
  groupBtnText: { color: '#fff', fontSize: 15, fontWeight: '800' },
  timeBtn: {
    paddingHorizontal: 12,
    paddingVertical: 9,
    borderRadius: 14,
    borderWidth: 2,
    borderColor: colors.border,
    backgroundColor: colors.panel,
  },
  timeBtnText: { color: colors.text, fontSize: 14, fontWeight: '800', textAlign: 'center' },

  ruler: { flexDirection: 'row', height: 28, borderBottomWidth: 1, borderBottomColor: colors.border },
  dayText: { color: colors.text, fontSize: 13, fontWeight: '800' },
  slotText: { position: 'absolute', top: 5, color: colors.muted, fontSize: 13, fontWeight: '700' },

  row: { flexDirection: 'row', alignItems: 'center' },
  chCell: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 6,
    marginRight: 4,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: 'transparent',
    backgroundColor: colors.panel,
  },
  chNum: { color: colors.muted, fontSize: 12, fontWeight: '800', minWidth: 22 },
  chLogo: { width: 46, height: 32 },
  chLogoSmall: { width: 58, height: 34 },
  chName: { color: colors.text, fontSize: 13, fontWeight: '700', flex: 1 },

  empty: {
    position: 'absolute',
    top: 3,
    bottom: 3,
    borderRadius: 10,
    backgroundColor: 'rgba(255,255,255,0.03)',
    justifyContent: 'center',
    paddingHorizontal: 12,
  },
  emptyText: { color: colors.muted, fontSize: 12 },
  prog: {
    position: 'absolute',
    top: 3,
    bottom: 3,
    paddingHorizontal: 8,
    justifyContent: 'center',
    borderRadius: 10,
    borderWidth: 2,
    borderColor: colors.border,
    backgroundColor: 'rgba(255,255,255,0.07)',
    overflow: 'hidden',
  },
  progLive: { backgroundColor: 'rgba(79,140,255,0.22)', borderColor: 'rgba(79,140,255,0.5)' },
  progPast: { backgroundColor: 'rgba(255,255,255,0.03)' },
  progTitle: { color: colors.text, fontSize: 13, fontWeight: '700' },
  progTime: { color: colors.muted, fontSize: 11, marginTop: 2 },

  nowLine: { position: 'absolute', top: 0, bottom: 0, width: 2, backgroundColor: colors.live },

  pickerWrap: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.55)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  picker: {
    width: '90%',
    maxWidth: 520,
    height: '85%',
    padding: 16,
    borderRadius: 20,
    backgroundColor: colors.panelSolid,
    borderWidth: 1,
    borderColor: colors.border,
  },
  pickerTitle: { color: colors.text, fontSize: 20, fontWeight: '900', marginBottom: 10 },
  pickRow: {
    paddingHorizontal: 14,
    paddingVertical: 12,
    marginBottom: 6,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: 'transparent',
    backgroundColor: colors.panel,
  },
  pickActive: { backgroundColor: 'rgba(79,140,255,0.2)', borderColor: 'rgba(79,140,255,0.5)' },
  pickText: { color: colors.text, fontSize: 15, fontWeight: '700' },
  closeBtn: {
    marginTop: 10,
    paddingVertical: 12,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: colors.border,
    backgroundColor: colors.panelAlt,
  },
});
