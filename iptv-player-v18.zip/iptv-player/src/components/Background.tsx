import React from 'react';
import { StyleSheet, View, ViewStyle } from 'react-native';
import { colors } from '../theme';

/**
 * Halo lumineux : des cercles empilés très transparents donnent un
 * dégradé radial sans librairie native.
 */
export function Orb({
  size,
  color,
  style,
  opacity = 0.03,
  rings = 8,
}: {
  size: number;
  color: string;
  style?: ViewStyle;
  opacity?: number;
  rings?: number;
}) {
  return (
    <View
      pointerEvents="none"
      style={[
        { position: 'absolute', width: size, height: size, alignItems: 'center', justifyContent: 'center' },
        style,
      ]}>
      {Array.from({ length: rings }).map((_, i) => {
        const s = size * (1 - i / rings);
        return (
          <View
            key={i}
            style={{
              position: 'absolute',
              width: s,
              height: s,
              borderRadius: s / 2,
              backgroundColor: color,
              opacity,
            }}
          />
        );
      })}
    </View>
  );
}

export default function Background() {
  return (
    <View pointerEvents="none" style={styles.bg}>
      <Orb size={1000} color={colors.accent} opacity={0.028} style={{ top: -520, left: -340 }} />
      <Orb size={900} color={colors.accent2} opacity={0.026} style={{ bottom: -480, right: -340 }} />
      <Orb size={520} color={colors.cyan} opacity={0.012} style={{ top: '30%', right: '25%' }} />
    </View>
  );
}

const styles = StyleSheet.create({
  bg: { ...StyleSheet.absoluteFillObject, backgroundColor: colors.bg, overflow: 'hidden' },
});
