import { Channel, Source, VodItem, XtreamSource } from './types';

export type RootStackParamList = {
  Sources: undefined;
  AddSource: undefined;
  Home: { source: XtreamSource };
  Channels: { source: Source; initialCategory?: string };
  Guide: { source: XtreamSource };
  Catchup: { source: XtreamSource; channel: Channel };
  Media: { source: XtreamSource; kind: 'movie' | 'series' };
  MovieDetail: { source: XtreamSource; item: VodItem };
  SeriesDetail: { source: XtreamSource; item: VodItem };
  Player: { index?: number; vod?: { url: string; title: string } };
};

/** Xtream : écran d'accueil (Direct / Films / Séries). M3U : directement les chaînes. */
export function openSource(navigation: any, source: Source, replace = false) {
  const screen = source.type === 'xtream' ? 'Home' : 'Channels';
  if (replace) {
    navigation.replace(screen, { source });
  } else {
    navigation.navigate(screen, { source });
  }
}
