# Lecteur IPTV : Android et Android TV (version 3)

Lecteur IPTV de type MyTVOnline. L'utilisateur entre **son propre abonnement**
(Xtream Codes ou lien M3U). L'app ne contient aucune chaîne.

## Fonctions
- Listes Xtream Codes (serveur, utilisateur, mot de passe) ou M3U (lien), plusieurs listes enregistrées
- Accueil Xtream : **TV en direct / Films / Séries**, avec la date d'expiration de l'abonnement
- **TV en direct** : catégories, recherche, favoris (appui long), zapping haut/bas
- **Guide horaire (EPG)** : « En ce moment » et « À suivre » avec une barre de progression,
  dans le panneau de droite sur la télé et par-dessus la vidéo dans le lecteur (Xtream)
- **Films** : affiches par catégorie, fiche (résumé, année, genre, durée, note, distribution), lecture
- **Séries** : saisons, épisodes, lecture
- Lecteur : en direct, les infos de la chaîne ; en film/série, les contrôles avance/recul/pause
- Interface adaptée à la télécommande (Android TV) et au toucher (téléphone)

À venir : guide XMLTV pour les listes M3U, portail MAC/Stalker, contrôle parental,
reprise de lecture, catch-up.

---

## Option A : obtenir l'APK sans rien installer (GitHub Actions)

GitHub compile l'APK pour toi gratuitement.

1. Crée un compte sur github.com (si ce n'est pas déjà fait).
2. Crée un nouveau dépôt (« New repository »), privé si tu veux.
3. Clique **« uploading an existing file »** et glisse **tout le contenu** de ce dossier
   (`App.tsx`, `src/`, `scripts/`, `assets/`, `.github/`, `README.md`).
   ⚠️ Le dossier `.github` est caché sur certains ordis : active l'affichage des
   fichiers cachés pour le voir et l'inclure.
4. Clique **« Commit changes »**. La compilation démarre toute seule (onglet **Actions**),
   et prend environ 10 à 15 minutes.
5. Quand c'est vert ✅, l'APK est dans l'onglet **Releases** (« Version 1 », « Version 2 »…)
   → `app-release.apk`. Ce lien se télécharge directement sur un téléphone ou un Fire Stick
   (avec l'app Downloader, si le dépôt est public).

Chaque fois que tu modifies un fichier sur GitHub, un nouvel APK est construit.
Si l'étape devient rouge ❌, ouvre-la, copie le message d'erreur et envoie-le-moi.

## Option B : compiler sur ton ordi

Prérequis : Node.js 20+, JDK 17, Android Studio.

```bash
npx @react-native-community/cli@latest init IptvPlayer --template @react-native-tvos/template-tv
cd IptvPlayer
npm install react-native-video@^6 @react-native-async-storage/async-storage@^2
```
Copie `App.tsx` et `src/` dans `IptvPlayer/`, puis applique les réglages Android
(http autorisé, Android TV, bannière) automatiquement :
```bash
node CHEMIN_VERS_CE_DOSSIER/scripts/patch-android.js .
```
Lancer sur un émulateur ou un appareil branché :
```bash
npx react-native run-android
```
Faire l'APK :
```bash
cd android && ./gradlew assembleRelease
```
→ `android/app/build/outputs/apk/release/app-release.apk`

## Installer sur un Fire Stick / boîtier Android TV
Active « Applications de sources inconnues », installe l'app **Downloader**,
entre le lien de l'APK. Ou, par câble réseau : `adb connect IP_DE_L_APPAREIL`
puis `adb install app-release.apk`.

> L'APK est signé avec une clé de test : parfait pour l'installer toi-même.
> Pour Google Play, il faudra une vraie clé de signature et un `.aab`. On fera ça à la fin.

---

## Structure
```
App.tsx                         Liste des écrans
src/nav/Navigator.tsx           Navigation entre écrans (JavaScript pur, sans librairie native)
src/types.ts                    Types
src/api/xtream.ts               API Xtream : direct, films, séries, guide
src/api/m3u.ts                  Lecture des listes M3U
src/api/epg.ts                  Guide horaire (cache 5 min)
src/utils/base64.ts             Décodage des titres du guide
src/storage.ts                  Listes et favoris enregistrés
src/components/Focusable.tsx    Bouton compatible télécommande
src/components/NowNext.tsx      Bloc « En ce moment / À suivre »
src/components/DetailHeader.tsx Fiche film/série
src/screens/…                   Écrans (Listes, Ajout, Accueil, Chaînes, Films/Séries, Fiches, Lecteur)
scripts/build.sh                Construction complète de l'APK (utilisée par GitHub)
scripts/patch-android.js        Réglages Android automatiques
assets/banner.png               Bannière du menu Android TV (320×180)
.github/workflows/build-apk.yml Compilation automatique de l'APK
```

## Notes
- Xtream : HLS (`.m3u8`) si le serveur l'autorise, sinon MPEG-TS (`.ts`).
- Les mots de passe sont enregistrés dans le stockage de l'app (AsyncStorage). Pour une
  version commerciale, on passera à un stockage chiffré (react-native-keychain).

## Mettre à jour l'app sur GitHub
Téléverse le nouveau zip (`iptv-player-v4.zip`, etc.) dans le dépôt. GitHub utilise
automatiquement le zip au numéro le plus élevé et reconstruit l'APK.
