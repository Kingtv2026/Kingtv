export interface XtreamSource {
  id: string;
  type: 'xtream';
  name: string;
  server: string;
  username: string;
  password: string;
}

export interface M3uSource {
  id: string;
  type: 'm3u';
  name: string;
  url: string;
}

export type Source = XtreamSource | M3uSource;

export interface Category {
  id: string;
  name: string;
}

export interface Channel {
  id: string;
  name: string;
  logo?: string;
  categoryId: string;
  streamUrl: string;
  epgId?: string;
  /** Nombre de jours de rattrapage (0 = pas de rattrapage) */
  archiveDays?: number;
}

export interface Playlist {
  categories: Category[];
  channels: Channel[];
}

/** Émission du guide horaire */
export interface Program {
  title: string;
  description: string;
  start: number; // ms
  end: number; // ms
  /** Heure de début telle qu'écrite par le serveur (« 2026-11-23 20:00:00 ») */
  startStr?: string;
  /** Émission disponible en rattrapage */
  hasArchive?: boolean;
}

/** Film ou série dans une grille */
export interface VodItem {
  id: string;
  name: string;
  poster?: string;
  rating?: string;
  /** Date d'ajout sur le serveur (secondes), pour le tri « Ajouts récents » */
  added?: number;
  /** Lien de lecture direct (films seulement) */
  url?: string;
}

export interface MovieInfo {
  plot?: string;
  genre?: string;
  duration?: string;
  year?: string;
  rating?: string;
  director?: string;
  cast?: string;
  poster?: string;
  backdrop?: string;
}

export interface Episode {
  id: string;
  num: number;
  title: string;
  plot?: string;
  duration?: string;
  image?: string;
  url: string;
}

export interface Season {
  number: number;
  episodes: Episode[];
}

export interface SeriesInfo {
  info: MovieInfo;
  seasons: Season[];
}

// Catégories spéciales ajoutées par l'app
export const CAT_ALL = '__all__';
export const CAT_FAVORITES = '__fav__';
