import { Channel, Source } from './types';

// Liste de chaînes en cours (pour zapper haut/bas dans le lecteur).
// Gardée hors de la navigation pour ne pas passer des milliers
// d'éléments dans les paramètres d'écran.
let queue: Channel[] = [];
let queueSource: Source | null = null;

export function setQueue(channels: Channel[], source: Source) {
  queue = channels;
  queueSource = source;
}

export function getQueue(): Channel[] {
  return queue;
}

export function getQueueSource(): Source | null {
  return queueSource;
}
