export const colors = {
  bg: '#070a12',
  panel: 'rgba(255,255,255,0.05)',
  panelAlt: 'rgba(255,255,255,0.11)',
  panelSolid: '#111726',
  border: 'rgba(255,255,255,0.08)',
  text: '#f4f6fb',
  muted: '#8b95ad',
  accent: '#4f8cff',
  accent2: '#a855f7',
  cyan: '#22d3ee',
  focus: '#7fb0ff',
  danger: '#ff5470',
  star: '#ffc93c',
  live: '#ff3b5c',
};

/** Nom affiché dans l'app : modifie ces deux mots pour changer le logo. */
export const BRAND = { first: 'KING', second: 'TV' };
