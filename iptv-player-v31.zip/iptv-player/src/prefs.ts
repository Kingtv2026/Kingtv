import AsyncStorage from '@react-native-async-storage/async-storage';

export type LiveEngine = 'vlc' | 'exo';
const KEY = 'iptv.liveEngine';
let engine: LiveEngine = 'vlc';

/** À appeler au démarrage : charge le choix du lecteur de la télé en direct. */
export async function loadPrefs() {
  try {
    const v = await AsyncStorage.getItem(KEY);
    if (v === 'vlc' || v === 'exo') {
      engine = v;
    }
  } catch {}
}

export function getLiveEngine(): LiveEngine {
  return engine;
}

export async function setLiveEngine(v: LiveEngine) {
  engine = v;
  await AsyncStorage.setItem(KEY, v).catch(() => {});
}
