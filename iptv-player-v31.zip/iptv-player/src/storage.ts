import AsyncStorage from '@react-native-async-storage/async-storage';
import { Source } from './types';

const SOURCES_KEY = 'iptv.sources';
const favKey = (sourceId: string) => `iptv.favorites.${sourceId}`;

export async function getSources(): Promise<Source[]> {
  const raw = await AsyncStorage.getItem(SOURCES_KEY);
  return raw ? JSON.parse(raw) : [];
}

export async function saveSource(source: Source): Promise<void> {
  const list = await getSources();
  const idx = list.findIndex(s => s.id === source.id);
  if (idx >= 0) {
    list[idx] = source;
  } else {
    list.push(source);
  }
  await AsyncStorage.setItem(SOURCES_KEY, JSON.stringify(list));
}

export async function removeSource(id: string): Promise<void> {
  const list = (await getSources()).filter(s => s.id !== id);
  await AsyncStorage.setItem(SOURCES_KEY, JSON.stringify(list));
  await AsyncStorage.removeItem(favKey(id));
}

export async function getFavorites(sourceId: string): Promise<string[]> {
  const raw = await AsyncStorage.getItem(favKey(sourceId));
  return raw ? JSON.parse(raw) : [];
}

export async function toggleFavorite(
  sourceId: string,
  channelId: string,
): Promise<string[]> {
  const favs = await getFavorites(sourceId);
  const next = favs.includes(channelId)
    ? favs.filter(f => f !== channelId)
    : [...favs, channelId];
  await AsyncStorage.setItem(favKey(sourceId), JSON.stringify(next));
  return next;
}
