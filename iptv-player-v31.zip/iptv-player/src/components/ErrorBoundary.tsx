import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import Focusable from './Focusable';
import { colors } from '../theme';

/**
 * Filet de sécurité : si une erreur survient dans un écran, on l'affiche
 * au lieu de faire planter l'app (et on peut envoyer une capture).
 */
export default class ErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { error: Error | null }
> {
  state = { error: null as Error | null };

  static getDerivedStateFromError(error: Error) {
    return { error };
  }

  render() {
    const { error } = this.state;
    if (!error) {
      return this.props.children;
    }
    return (
      <View style={styles.wrap}>
        <Text style={styles.title}>Oups, un problème est survenu</Text>
        <Text style={styles.sub}>Fais une capture de cet écran pour le support.</Text>
        <ScrollView style={styles.box}>
          <Text style={styles.msg}>{String(error?.message || error)}</Text>
          <Text style={styles.stack}>{String(error?.stack || '').slice(0, 1500)}</Text>
        </ScrollView>
        <Focusable hasTVPreferredFocus style={styles.btn} onPress={() => this.setState({ error: null })}>
          <Text style={styles.btnText}>Revenir à l’app</Text>
        </Focusable>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: colors.bg, padding: 28, paddingTop: 60 },
  title: { color: colors.text, fontSize: 22, fontWeight: '900' },
  sub: { color: colors.muted, fontSize: 14, marginTop: 6, marginBottom: 16 },
  box: {
    flex: 1,
    backgroundColor: colors.panel,
    borderRadius: 12,
    padding: 14,
    borderWidth: 1,
    borderColor: colors.border,
  },
  msg: { color: colors.danger, fontSize: 15, fontWeight: '700', marginBottom: 10 },
  stack: { color: colors.muted, fontSize: 11 },
  btn: {
    marginTop: 16,
    alignSelf: 'center',
    paddingHorizontal: 28,
    paddingVertical: 12,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: colors.accent,
    backgroundColor: colors.accent,
  },
  btnText: { color: '#fff', fontSize: 16, fontWeight: '800' },
});
