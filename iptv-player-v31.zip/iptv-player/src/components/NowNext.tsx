import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { formatTime, progressOf } from '../api/epg';
import { colors } from '../theme';
import { Program } from '../types';

/** Affiche « En ce moment » et « À suivre » avec une barre de progression. */
export default function NowNext({
  programs,
  showDescription = false,
}: {
  programs: Program[];
  showDescription?: boolean;
}) {
  if (programs.length === 0) {
    return <Text style={styles.none}>Pas de guide horaire pour cette chaîne</Text>;
  }
  const [now, next] = programs;
  return (
    <View>
      <Text style={styles.label}>
        EN CE MOMENT · {formatTime(now.start)} – {formatTime(now.end)}
      </Text>
      <Text style={styles.title} numberOfLines={2}>
        {now.title}
      </Text>
      <View style={styles.bar}>
        <View style={[styles.fill, { width: `${progressOf(now) * 100}%` }]} />
      </View>
      {showDescription && !!now.description && (
        <Text style={styles.desc} numberOfLines={4}>
          {now.description}
        </Text>
      )}
      {next && (
        <>
          <Text style={[styles.label, { marginTop: 12 }]}>
            À SUIVRE · {formatTime(next.start)}
          </Text>
          <Text style={styles.next} numberOfLines={1}>
            {next.title}
          </Text>
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  none: { color: colors.muted, fontSize: 14 },
  label: { color: colors.accent, fontSize: 12, fontWeight: '700', letterSpacing: 0.5 },
  title: { color: colors.text, fontSize: 17, fontWeight: '600', marginTop: 4 },
  bar: {
    height: 4,
    backgroundColor: colors.border,
    borderRadius: 2,
    marginTop: 8,
    overflow: 'hidden',
  },
  fill: { height: 4, backgroundColor: colors.accent },
  desc: { color: colors.muted, fontSize: 14, marginTop: 8, lineHeight: 19 },
  next: { color: colors.text, fontSize: 15, marginTop: 4 },
});
