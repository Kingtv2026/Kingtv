import React, { useEffect, useState } from 'react';
import { Text, View } from 'react-native';
import { colors } from '../theme';

const JOURS = ['dim.', 'lun.', 'mar.', 'mer.', 'jeu.', 'ven.', 'sam.'];
const MOIS = ['janv.', 'févr.', 'mars', 'avr.', 'mai', 'juin', 'juil.', 'août', 'sept.', 'oct.', 'nov.', 'déc.'];

export default function Clock({ compact = false }: { compact?: boolean }) {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 15000);
    return () => clearInterval(t);
  }, []);
  const hh = String(now.getHours()).padStart(2, '0');
  const mm = String(now.getMinutes()).padStart(2, '0');
  return (
    <View style={{ alignItems: 'flex-end' }}>
      <Text style={{ color: colors.text, fontSize: compact ? 18 : 24, fontWeight: '800' }}>
        {hh}:{mm}
      </Text>
      {!compact && (
        <Text style={{ color: colors.muted, fontSize: 13, marginTop: 1 }}>
          {JOURS[now.getDay()]} {now.getDate()} {MOIS[now.getMonth()]}
        </Text>
      )}
    </View>
  );
}
