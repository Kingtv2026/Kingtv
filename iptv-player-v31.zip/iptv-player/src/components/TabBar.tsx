import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import type { Nav } from '../nav/Navigator';
import Focusable from './Focusable';
import { colors } from '../theme';
import { CAT_FAVORITES, XtreamSource } from '../types';

export type TabKey = 'home' | 'live' | 'movies' | 'series' | 'favs';

const TABS: { key: TabKey; icon: string; label: string }[] = [
  { key: 'home', icon: '⌂', label: 'Accueil' },
  { key: 'live', icon: '📺', label: 'Direct' },
  { key: 'movies', icon: '🎬', label: 'Films' },
  { key: 'series', icon: '🍿', label: 'Séries' },
  { key: 'favs', icon: '★', label: 'Favoris' },
];

/** Barre d'onglets du bas, comme MyTVOnline. */
export default function TabBar({
  active,
  source,
  navigation,
}: {
  active: TabKey;
  source: XtreamSource;
  navigation: Nav;
}) {
  const go = (key: TabKey) => {
    if (key === active) {
      return;
    }
    if (key === 'home') {
      navigation.goBack();
      return;
    }
    // Depuis l'accueil on empile l'écran ; ailleurs on le remplace (retour = accueil)
    const open = active === 'home' ? navigation.navigate : navigation.replace;
    if (key === 'live') {
      open('Channels', { source });
    } else if (key === 'favs') {
      open('Channels', { source, initialCategory: CAT_FAVORITES });
    } else {
      open('Media', { source, kind: key === 'movies' ? 'movie' : 'series' });
    }
  };

  return (
    <View style={styles.bar}>
      {TABS.map(t => {
        const on = t.key === active;
        return (
          <Focusable key={t.key} style={styles.tab} onPress={() => go(t.key)}>
            <Text style={[styles.icon, !on && styles.dim, on && t.key === 'favs' && { color: colors.star }]}>
              {t.icon}
            </Text>
            <Text style={[styles.label, on && styles.labelOn]}>{t.label}</Text>
            {on && <View style={styles.dot} />}
          </Focusable>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  bar: {
    flexDirection: 'row',
    paddingHorizontal: 6,
    paddingTop: 6,
    paddingBottom: 8,
    backgroundColor: 'rgba(7,10,18,0.96)',
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  tab: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 4,
    borderRadius: 14,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  icon: { fontSize: 22, color: colors.text, lineHeight: 28 },
  dim: { opacity: 0.45 },
  label: { color: colors.muted, fontSize: 11, fontWeight: '700', marginTop: 1 },
  labelOn: { color: colors.text },
  dot: { width: 5, height: 5, borderRadius: 3, backgroundColor: colors.accent, marginTop: 3 },
});
