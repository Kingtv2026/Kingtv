import React from 'react';
import { Text, View } from 'react-native';
import { BRAND, colors } from '../theme';

export default function Logo({ size = 28 }: { size?: number }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
      <Text style={{ color: colors.text, fontSize: size, fontWeight: '900', letterSpacing: 2 }}>
        {BRAND.first}
      </Text>
      <View
        style={{
          marginLeft: size * 0.2,
          backgroundColor: colors.accent,
          borderRadius: size * 0.25,
          paddingHorizontal: size * 0.28,
          paddingVertical: size * 0.04,
        }}>
        <Text style={{ color: '#fff', fontSize: size * 0.8, fontWeight: '900', letterSpacing: 1 }}>
          {BRAND.second}
        </Text>
      </View>
    </View>
  );
}
