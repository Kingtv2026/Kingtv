/**
 * Rattrapage : émissions passées d'une chaîne, classées par jour.
 */
import React, { useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, FlatList, Image, StyleSheet, Text, View } from 'react-native';
import { ScreenProps } from '../nav/Navigator';
import Focusable from '../components/Focusable';
import { catchupUrl, getFullEpg } from '../api/xtream';
import { formatTime } from '../api/epg';
import { colors } from '../theme';
import { Program } from '../types';

type Props = ScreenProps<'Catchup'>;

const JOURS = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'];
const MOIS = ['janv.', 'févr.', 'mars', 'avr.', 'mai', 'juin', 'juil.', 'août', 'sept.', 'oct.', 'nov.', 'déc.'];

const dayKey = (ms: number) => {
  const d = new Date(ms);
  return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
};

function dayLabel(ms: number): string {
  const today = new Date();
  const yesterday = new Date(Date.now() - 86400000);
  const d = new Date(ms);
  if (dayKey(ms) === dayKey(today.getTime())) {
    return 'Aujourd’hui';
  }
  if (dayKey(ms) === dayKey(yesterday.getTime())) {
    return 'Hier';
  }
  return `${JOURS[d.getDay()]} ${d.getDate()} ${MOIS[d.getMonth()]}`;
}

export default function CatchupScreen({ route, navigation }: Props) {
  const { source, channel } = route.params;
  const [programs, setPrograms] = useState<Program[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [day, setDay] = useState<string | null>(null);

  useEffect(() => {
    navigation.setOptions({ title: `⏪  ${channel.name}` });
    getFullEpg(source, channel.id)
      .then(list => {
        const now = Date.now();
        const oldest = now - (channel.archiveDays || 1) * 86400000;
        // Émissions terminées, dans la période de rattrapage de la chaîne
        const past = list.filter(
          p => p.end <= now && p.start >= oldest && (p.hasArchive || p.hasArchive === undefined),
        );
        setPrograms(past);
        if (past.length) {
          setDay(dayKey(past[past.length - 1].start));
        }
      })
      .catch(e => setError(e?.message || 'Chargement impossible'));
  }, [source, channel, navigation]);

  const days = useMemo(() => {
    const seen = new Map<string, number>();
    for (const p of programs || []) {
      const k = dayKey(p.start);
      if (!seen.has(k)) {
        seen.set(k, p.start);
      }
    }
    // Le plus récent d'abord
    return Array.from(seen.entries())
      .map(([key, ms]) => ({ key, label: dayLabel(ms) }))
      .reverse();
  }, [programs]);

  const list = useMemo(
    () => (programs || []).filter(p => dayKey(p.start) === day).reverse(),
    [programs, day],
  );

  const play = (p: Program) => {
    const url = catchupUrl(source, channel.id, p);
    if (!url) {
      setError('Cette émission n’a pas d’heure de début valide.');
      return;
    }
    navigation.navigate('Player', {
      vod: {
        url,
        title: `${channel.name} · ${p.title} (${formatTime(p.start)})`,
        catchup: { source, streamId: channel.id, program: p },
      },
    });
  };

  if (error) {
    return (
      <View style={styles.center}>
        <Text style={styles.error}>{error}</Text>
      </View>
    );
  }
  if (!programs) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={colors.accent} />
        <Text style={styles.muted}>Chargement des émissions passées…</Text>
      </View>
    );
  }
  if (programs.length === 0) {
    return (
      <View style={styles.center}>
        <Text style={styles.muted}>
          Aucune émission passée disponible pour cette chaîne.{'\n'}Le serveur ne fournit peut-être pas de
          guide pour le rattrapage.
        </Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.head}>
        {channel.logo ? <Image source={{ uri: channel.logo }} style={styles.logo} resizeMode="contain" /> : null}
        <Text style={styles.headText}>
          Rattrapage disponible : {channel.archiveDays} jour{(channel.archiveDays || 0) > 1 ? 's' : ''}
        </Text>
      </View>

      <FlatList
        horizontal
        data={days}
        keyExtractor={d => d.key}
        showsHorizontalScrollIndicator={false}
        style={styles.days}
        contentContainerStyle={{ paddingHorizontal: 16 }}
        renderItem={({ item, index }) => (
          <Focusable
            hasTVPreferredFocus={index === 0}
            style={[styles.dayChip, item.key === day && styles.dayActive]}
            onFocus={() => setDay(item.key)}
            onPress={() => setDay(item.key)}>
            <Text style={[styles.dayText, item.key === day && { color: '#fff' }]}>{item.label}</Text>
          </Focusable>
        )}
      />

      <FlatList
        data={list}
        keyExtractor={p => `${p.start}`}
        contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 24 }}
        renderItem={({ item }) => (
          <Focusable style={styles.prog} scale={1.01} onPress={() => play(item)}>
            <View style={styles.timeBox}>
              <Text style={styles.time}>{formatTime(item.start)}</Text>
              <Text style={styles.timeEnd}>{formatTime(item.end)}</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.title} numberOfLines={1}>
                {item.title || 'Sans titre'}
              </Text>
              {!!item.description && (
                <Text style={styles.desc} numberOfLines={2}>
                  {item.description}
                </Text>
              )}
            </View>
            <Text style={styles.playIcon}>▶</Text>
          </Focusable>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24, gap: 12 },
  error: { color: colors.danger, fontSize: 16, textAlign: 'center' },
  muted: { color: colors.muted, fontSize: 15, textAlign: 'center', lineHeight: 22 },
  head: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 20, marginBottom: 8 },
  logo: { width: 56, height: 36 },
  headText: { color: colors.muted, fontSize: 14, fontWeight: '700' },
  days: { flexGrow: 0, marginBottom: 10 },
  dayChip: {
    paddingHorizontal: 16,
    paddingVertical: 9,
    marginRight: 8,
    borderRadius: 20,
    borderWidth: 2,
    borderColor: colors.border,
    backgroundColor: colors.panel,
  },
  dayActive: { backgroundColor: colors.accent2, borderColor: colors.accent2 },
  dayText: { color: colors.text, fontSize: 14, fontWeight: '800' },
  prog: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    padding: 12,
    marginBottom: 8,
    borderRadius: 14,
    borderWidth: 2,
    borderColor: 'transparent',
    backgroundColor: colors.panel,
  },
  timeBox: { width: 54, alignItems: 'center' },
  time: { color: colors.text, fontSize: 16, fontWeight: '900' },
  timeEnd: { color: colors.muted, fontSize: 12, marginTop: 2 },
  title: { color: colors.text, fontSize: 16, fontWeight: '800' },
  desc: { color: colors.muted, fontSize: 13, marginTop: 3 },
  playIcon: { color: colors.accent2, fontSize: 18 },
});
