/** Écran d'activation : demande le code du client au premier lancement. */
import React, { useEffect, useState } from 'react';
import { ActivityIndicator, StyleSheet, Text, TextInput, View } from 'react-native';
import { ScreenProps } from '../nav/Navigator';
import Focusable from '../components/Focusable';
import Logo from '../components/Logo';
import { colors } from '../theme';
import {
  activate,
  clearLicense,
  getDeviceId,
  getStoredLicense,
  LicenseError,
  PANEL_SOURCE_ID,
} from '../license';
import { openSource } from '../navigation';
import { getSources } from '../storage';
import { Source } from '../types';

type Props = ScreenProps<'Activation'>;

export default function ActivationScreen({ navigation }: Props) {
  const [checking, setChecking] = useState(true);
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [deviceId, setDeviceId] = useState('');

  // Liste fournie par le vendeur : on l'ouvre directement
  const enter = (source?: Source | null) => {
    navigation.replace('Sources');
    if (source) {
      openSource(navigation, source);
    }
  };

  // Au démarrage : vérifie la licence enregistrée
  useEffect(() => {
    getDeviceId().then(id => setDeviceId(id));
    (async () => {
      const stored = await getStoredLicense();
      if (!stored) {
        setChecking(false);
        return;
      }
      setCode(stored.code);
      try {
        const res = await activate(stored.code);
        enter(res.source);
      } catch (e: any) {
        if (e instanceof LicenseError && e.network) {
          // Hors ligne : on laisse passer quelques jours depuis la dernière vérification
          const ageDays = (Date.now() - stored.checkedAt) / 86400000;
          if (ageDays <= stored.graceDays) {
            const panelSrc = (await getSources()).find(x => x.id === PANEL_SOURCE_ID);
            enter(panelSrc);
            return;
          }
          setError('Connexion requise pour vérifier ton abonnement. ' + e.message);
        } else {
          await clearLicense();
          setError(e?.message || 'Licence refusée.');
        }
        setChecking(false);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Formate en KING-XXXX-XXXX pendant la saisie
  const onChange = (t: string) => {
    let raw = t.toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (raw.startsWith('KING')) {
      raw = raw.slice(4);
    }
    raw = raw.slice(0, 8);
    setCode('KING-' + raw.slice(0, 4) + (raw.length > 4 ? '-' + raw.slice(4) : ''));
  };

  const submit = async () => {
    setError(null);
    if (!/^KING-[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(code)) {
      setError('Le code doit ressembler à KING-XXXX-XXXX.');
      return;
    }
    setBusy(true);
    try {
      const res = await activate(code);
      enter(res.source);
    } catch (e: any) {
      setError(e?.message || 'Activation impossible.');
    } finally {
      setBusy(false);
    }
  };

  if (checking) {
    return (
      <View style={styles.center}>
        <Logo size={34} />
        <ActivityIndicator color={colors.accent} style={{ marginTop: 24 }} />
      </View>
    );
  }

  return (
    <View style={styles.center}>
      <View style={styles.box}>
        <Logo size={32} />
        <Text style={styles.title}>Activer Kingtv</Text>
        <Text style={styles.sub}>Entre le code d’activation fourni par ton vendeur.</Text>

        <TextInput
          value={code}
          onChangeText={onChange}
          placeholder="KING-XXXX-XXXX"
          placeholderTextColor={colors.muted}
          autoCapitalize="characters"
          autoCorrect={false}
          maxLength={14}
          style={styles.input}
          onSubmitEditing={submit}
          returnKeyType="done"
        />

        {!!error && <Text style={styles.error}>{error}</Text>}

        <Focusable hasTVPreferredFocus style={styles.btn} onPress={submit} disabled={busy}>
          {busy ? <ActivityIndicator color="#fff" /> : <Text style={styles.btnText}>Activer</Text>}
        </Focusable>

        <Text style={styles.device}>Appareil : {deviceId.slice(0, 4).toUpperCase()}-{deviceId.slice(4, 8).toUpperCase()}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24 },
  box: {
    width: '100%',
    maxWidth: 440,
    alignItems: 'center',
    padding: 26,
    borderRadius: 24,
    backgroundColor: colors.panel,
    borderWidth: 1,
    borderColor: colors.border,
  },
  title: { color: colors.text, fontSize: 24, fontWeight: '900', marginTop: 22 },
  sub: { color: colors.muted, fontSize: 14, textAlign: 'center', marginTop: 6 },
  input: {
    width: '100%',
    marginTop: 22,
    backgroundColor: colors.panelSolid,
    color: colors.star,
    borderRadius: 14,
    borderWidth: 2,
    borderColor: colors.focus,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 22,
    fontWeight: '900',
    letterSpacing: 2,
    textAlign: 'center',
  },
  error: { color: colors.danger, fontSize: 14, textAlign: 'center', marginTop: 12 },
  btn: {
    width: '100%',
    marginTop: 18,
    paddingVertical: 14,
    borderRadius: 14,
    borderWidth: 2,
    borderColor: colors.accent,
    backgroundColor: colors.accent,
    alignItems: 'center',
  },
  btnText: { color: '#fff', fontSize: 17, fontWeight: '900' },
  device: { color: colors.muted, fontSize: 11, marginTop: 16 },
});
