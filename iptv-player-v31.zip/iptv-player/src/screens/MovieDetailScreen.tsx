import React, { useEffect, useState } from 'react';
import { ActivityIndicator, ScrollView, StyleSheet, Text, View } from 'react-native';
import { ScreenProps } from '../nav/Navigator';
import DetailHeader from '../components/DetailHeader';
import Focusable from '../components/Focusable';
import { getMovieInfo } from '../api/xtream';
import { openInVlc } from '../utils/external';
import { colors } from '../theme';
import { MovieInfo } from '../types';

type Props = ScreenProps<'MovieDetail'>;

export default function MovieDetailScreen({ route, navigation }: Props) {
  const { source, item } = route.params;
  const [info, setInfo] = useState<MovieInfo | null>(null);

  useEffect(() => {
    navigation.setOptions({ title: item.name });
    getMovieInfo(source, item.id)
      .then(setInfo)
      .catch(() => setInfo({}));
  }, [item, navigation, source]);

  const play = () => {
    if (item.url) {
      navigation.navigate('Player', { vod: { url: item.url, title: item.name } });
    }
  };

  return (
    <ScrollView style={styles.container}>
      {info === null ? (
        <ActivityIndicator color={colors.accent} style={{ marginTop: 60 }} />
      ) : (
        <DetailHeader title={item.name} info={info} fallbackPoster={item.poster}>
          <View style={styles.buttons}>
            <Focusable hasTVPreferredFocus scale={1.06} style={styles.play} onPress={play}>
              <Text style={styles.playText}>▶   Regarder</Text>
            </Focusable>
            <Focusable
              scale={1.06}
              style={[styles.play, styles.vlc]}
              onPress={() => item.url && openInVlc(item.url)}>
              <Text style={styles.playText}>Ouvrir avec VLC</Text>
            </Focusable>
          </View>
        </DetailHeader>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  buttons: { flexDirection: 'row', flexWrap: 'wrap', gap: 14, marginTop: 24 },
  vlc: { backgroundColor: 'rgba(249,115,22,0.9)', borderColor: 'rgba(249,115,22,0.9)', paddingHorizontal: 24 },
  play: {
    backgroundColor: colors.accent,
    borderWidth: 2,
    borderColor: colors.accent,
    borderRadius: 14,
    paddingHorizontal: 36,
    paddingVertical: 14,
  },
  playText: { color: '#fff', fontSize: 18, fontWeight: '900', letterSpacing: 0.5 },
});
