import { Channel, Program, Source } from '../types';
import { getFullEpg, getShortEpg } from './xtream';

const TTL = 5 * 60 * 1000;
const cache = new Map<string, { at: number; data: Program[] }>();

/** Émission en cours + suivante pour une chaîne (vide si non disponible). */
export async function getNowNext(source: Source, channel: Channel): Promise<Program[]> {
  if (source.type !== 'xtream') {
    return []; // Guide XMLTV pour les listes M3U : version suivante
  }
  const key = `${source.id}:${channel.id}`;
  const hit = cache.get(key);
  const now = Date.now();
  if (hit && now - hit.at < TTL) {
    return hit.data.filter(p => p.end > now).slice(0, 2);
  }
  try {
    const data = await getShortEpg(source, channel.id, 4);
    cache.set(key, { at: now, data });
    return data.filter(p => p.end > now).slice(0, 2);
  } catch {
    return [];
  }
}

export function formatTime(ms: number): string {
  const d = new Date(ms);
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}

export function progressOf(p: Program): number {
  const now = Date.now();
  return Math.min(1, Math.max(0, (now - p.start) / (p.end - p.start)));
}

// ---------- Guide en grille : plusieurs heures par chaîne ----------
const fullCache = new Map<string, { at: number; data: Program[] }>();
const inflight = new Map<string, Promise<Program[]>>();

export function getPrograms(source: Source, channel: Channel): Promise<Program[]> {
  if (source.type !== 'xtream') {
    return Promise.resolve([]);
  }
  const key = `${source.id}:${channel.id}`;
  const hit = fullCache.get(key);
  if (hit && Date.now() - hit.at < 15 * 60 * 1000) {
    return Promise.resolve(hit.data);
  }
  const running = inflight.get(key);
  if (running) {
    return running;
  }
  // Guide complet (émissions passées incluses) ; version courte si le serveur ne le fournit pas
  const p = getFullEpg(source, channel.id)
    .then(list => {
      // on garde seulement d'hier à demain pour ménager la mémoire
      const from = Date.now() - 26 * 3600 * 1000;
      const to = Date.now() + 26 * 3600 * 1000;
      const kept = list.filter(x => x.end > from && x.start < to);
      return kept.length ? kept : getShortEpg(source, channel.id, 24);
    })
    .catch(() => getShortEpg(source, channel.id, 24))
    .catch(() => [] as Program[])
    .then(data => {
      fullCache.set(key, { at: Date.now(), data });
      inflight.delete(key);
      return data;
    });
  inflight.set(key, p);
  return p;
}

export function clearEpgCache() {
  cache.clear();
  fullCache.clear();
  inflight.clear();
}
