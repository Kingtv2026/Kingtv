import { Category, Channel, M3uSource, Playlist } from '../types';

const ATTR_RE = /([\w-]+)="([^"]*)"/g;

export function parseM3u(text: string): Playlist {
  const lines = text.split(/\r?\n/);
  const categories = new Map<string, Category>();
  const channels: Channel[] = [];

  let current: {
    name: string;
    logo?: string;
    epgId?: string;
    group: string;
  } | null = null;

  for (const raw of lines) {
    const line = raw.trim();
    if (!line) {
      continue;
    }

    if (line.startsWith('#EXTINF')) {
      const attrs: Record<string, string> = {};
      let m: RegExpExecArray | null;
      ATTR_RE.lastIndex = 0;
      while ((m = ATTR_RE.exec(line)) !== null) {
        attrs[m[1].toLowerCase()] = m[2];
      }
      // Le nom affiché est après la virgule, une fois les attributs retirés
      const stripped = line.replace(ATTR_RE, '');
      const comma = stripped.indexOf(',');
      const displayName = comma >= 0 ? stripped.slice(comma + 1).trim() : '';

      current = {
        name: displayName || attrs['tvg-name'] || 'Sans nom',
        logo: attrs['tvg-logo'] || undefined,
        epgId: attrs['tvg-id'] || undefined,
        group: attrs['group-title'] || 'Sans catégorie',
      };
    } else if (line.startsWith('#EXTGRP:')) {
      if (current) {
        current.group = line.slice(8).trim() || current.group;
      }
    } else if (line.startsWith('#')) {
      continue;
    } else if (current) {
      if (!categories.has(current.group)) {
        categories.set(current.group, { id: current.group, name: current.group });
      }
      channels.push({
        id: String(channels.length),
        name: current.name,
        logo: current.logo,
        epgId: current.epgId,
        categoryId: current.group,
        streamUrl: line,
      });
      current = null;
    }
  }

  return { categories: Array.from(categories.values()), channels };
}

export async function loadM3u(src: M3uSource): Promise<Playlist> {
  const res = await fetch(src.url.trim());
  if (!res.ok) {
    throw new Error(`Impossible de télécharger la liste (${res.status})`);
  }
  const text = await res.text();
  if (!text.includes('#EXTINF')) {
    throw new Error("Ce lien ne contient pas une liste M3U valide");
  }
  return parseM3u(text);
}
