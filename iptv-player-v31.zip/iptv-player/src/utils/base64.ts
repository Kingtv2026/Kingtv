const CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';

/** Décodage UTF-8 strict : lance une erreur si les octets ne sont pas du texte valide. */
function utf8Decode(bytes: number[]): string {
  const need = (start: number, n: number) => {
    for (let k = 0; k < n; k++) {
      const c = bytes[start + k];
      if (c === undefined || (c & 0xc0) !== 0x80) {
        throw new Error('UTF-8 invalide');
      }
    }
  };
  let out = '';
  let i = 0;
  while (i < bytes.length) {
    const b = bytes[i];
    if (b >= 0x80 && b < 0xc2) {
      throw new Error('UTF-8 invalide');
    } else if (b >= 0xf5) {
      throw new Error('UTF-8 invalide');
    }
    need(i + 1, b < 0x80 ? 0 : b < 0xe0 ? 1 : b < 0xf0 ? 2 : 3);
    i++;
    if (b < 0x80) {
      out += String.fromCharCode(b);
    } else if (b >= 0xc0 && b < 0xe0) {
      out += String.fromCharCode(((b & 0x1f) << 6) | (bytes[i++] & 0x3f));
    } else if (b >= 0xe0 && b < 0xf0) {
      out += String.fromCharCode(
        ((b & 0x0f) << 12) | ((bytes[i++] & 0x3f) << 6) | (bytes[i++] & 0x3f),
      );
    } else if (b >= 0xf0) {
      const cp =
        ((b & 0x07) << 18) |
        ((bytes[i++] & 0x3f) << 12) |
        ((bytes[i++] & 0x3f) << 6) |
        (bytes[i++] & 0x3f);
      out += String.fromCodePoint(cp);
    }
  }
  return out;
}

/**
 * Les titres du guide Xtream arrivent encodés en base64.
 * Si le texte n'a pas l'air d'être du base64, on le renvoie tel quel.
 */
export function decodeMaybeBase64(input: string): string {
  const s = input.trim();
  if (!s || s.length % 4 !== 0 || !/^[A-Za-z0-9+/]+={0,2}$/.test(s)) {
    return input;
  }
  try {
    const bytes: number[] = [];
    let buffer = 0;
    let bits = 0;
    for (const ch of s.replace(/=+$/, '')) {
      buffer = ((buffer << 6) | CHARS.indexOf(ch)) & 0xffffff;
      bits += 6;
      if (bits >= 8) {
        bits -= 8;
        bytes.push((buffer >> bits) & 0xff);
      }
    }
    const out = utf8Decode(bytes);
    // Si le résultat contient des caractères de contrôle, ce n'était pas du base64
    // eslint-disable-next-line no-control-regex
    if (/[\u0000-\u0008\u000E-\u001F\u007F-\u009F�]/.test(out)) {
      return input;
    }
    return out;
  } catch {
    return input;
  }
}
