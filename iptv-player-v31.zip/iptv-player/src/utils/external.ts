import { Alert, Linking } from 'react-native';

/** Ouvre un film/une série dans VLC (lit presque tous les formats : MKV, AC3, HEVC…). */
export async function openInVlc(url: string) {
  try {
    await Linking.openURL(`vlc://${url}`);
  } catch {
    Alert.alert(
      'VLC n’est pas installé',
      'Installe « VLC for Android » depuis le Play Store, puis réessaie.',
      [
        { text: 'Annuler', style: 'cancel' },
        {
          text: 'Ouvrir le Play Store',
          onPress: () =>
            Linking.openURL('market://details?id=org.videolan.vlc').catch(() =>
              Linking.openURL('https://play.google.com/store/apps/details?id=org.videolan.vlc'),
            ),
        },
      ],
    );
  }
}

/** Résumé lisible de l'erreur du lecteur (pour le diagnostic). */
export function describeVideoError(e: any): string {
  const err = e?.error ?? e ?? {};
  const parts = [
    err.errorCode && `Code ${err.errorCode}`,
    err.errorString,
    err.errorException,
  ].filter(Boolean);
  const text = parts.join(' · ') || JSON.stringify(err).slice(0, 300);
  return text.length > 300 ? text.slice(0, 300) + '…' : text;
}
