import { Linking, NativeEventEmitter, NativeModules } from 'react-native';
import { BUILD, UPDATE_REPO } from './buildInfo';

export interface UpdateInfo {
  build: number;
  url: string;
}

/** Vérifie s'il existe une version plus récente sur GitHub. */
export async function checkForUpdate(): Promise<UpdateInfo | null> {
  const res = await fetch(`https://api.github.com/repos/${UPDATE_REPO}/releases/latest`, {
    headers: { Accept: 'application/vnd.github+json' },
  });
  if (!res.ok) {
    throw new Error(`GitHub ${res.status}`);
  }
  const rel = await res.json();
  const build = Number(String(rel?.tag_name || '').replace(/\D/g, '')) || 0;
  const asset = (rel?.assets || []).find((a: any) => String(a.name).endsWith('.apk'));
  if (!asset || build <= BUILD) {
    return null;
  }
  return { build, url: asset.browser_download_url };
}

const native = NativeModules.KingUpdate;

/** Télécharge l'APK dans l'app puis ouvre l'installation Android. */
export async function downloadAndInstall(url: string, onProgress: (pct: number) => void) {
  if (!native) {
    // Module natif absent : on passe par le navigateur
    await Linking.openURL(url);
    return;
  }
  const emitter = new NativeEventEmitter(native);
  const sub = emitter.addListener('KingUpdateProgress', (pct: number) => onProgress(pct));
  try {
    await native.downloadAndInstall(url);
  } finally {
    sub.remove();
  }
}
