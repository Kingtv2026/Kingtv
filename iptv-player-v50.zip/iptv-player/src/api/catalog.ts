/**
 * Catalogue complet des films ou des séries, chargé catégorie par catégorie
 * (6 à la fois) pour ne pas saturer la mémoire du téléphone.
 * Gardé en mémoire ET sur l'appareil : chargé une seule fois, puis mis à jour
 * discrètement en arrière-plan une fois par jour.
 */
import AsyncStorage from '@react-native-async-storage/async-storage';
import { VodItem, XtreamSource } from '../types';
import { getSeries, getSeriesCategories, getVodCategories, getVodStreams } from './xtream';
import { isAdultName } from '../parental';

type Kind = 'movie' | 'series';
const cache = new Map<string, VodItem[]>();
const inflight = new Map<string, Promise<VodItem[]>>();
type Progress = (done: number, total: number, partial: VodItem[]) => void;
const listeners = new Map<string, Set<Progress>>();

// ---------- Copie sur l'appareil (morceaux de 600, limite Android ~2 Mo par entrée) ----------
const CHUNK = 600;
const REFRESH_MS = 20 * 3600 * 1000;
const diskKey = (src: XtreamSource, kind: Kind) => `iptv.cat.${src.id}.${kind}`;

type Row = [string, string, string, string, number, string, number, string];
const pack = (v: VodItem): Row => [
  v.id,
  v.name,
  v.poster || '',
  v.rating || '',
  v.added || 0,
  v.categoryId || '',
  v.adult ? 1 : 0,
  v.url || '',
];
const unpack = (r: Row): VodItem => ({
  id: r[0],
  name: r[1],
  poster: r[2] || undefined,
  rating: r[3] || undefined,
  added: r[4] || undefined,
  categoryId: r[5] || undefined,
  adult: r[6] ? true : undefined,
  url: r[7] || undefined,
});

async function readDisk(src: XtreamSource, kind: Kind): Promise<{ at: number; items: VodItem[] } | null> {
  try {
    const metaRaw = await AsyncStorage.getItem(diskKey(src, kind));
    if (!metaRaw) return null;
    const meta = JSON.parse(metaRaw) as { at: number; chunks: number };
    const keys = Array.from({ length: meta.chunks }, (_, i) => `${diskKey(src, kind)}.${i}`);
    const pairs = await AsyncStorage.multiGet(keys);
    const items: VodItem[] = [];
    for (const [, v] of pairs) {
      if (!v) return null; // copie incomplète
      for (const row of JSON.parse(v) as Row[]) items.push(unpack(row));
    }
    return { at: meta.at, items };
  } catch {
    return null;
  }
}

async function writeDisk(src: XtreamSource, kind: Kind, items: VodItem[]) {
  try {
    await removeDisk(src.id, kind);
    const pairs: [string, string][] = [];
    for (let i = 0; i * CHUNK < items.length; i++) {
      pairs.push([`${diskKey(src, kind)}.${i}`, JSON.stringify(items.slice(i * CHUNK, (i + 1) * CHUNK).map(pack))]);
    }
    if (pairs.length) await AsyncStorage.multiSet(pairs);
    await AsyncStorage.setItem(diskKey(src, kind), JSON.stringify({ at: Date.now(), chunks: pairs.length }));
  } catch {
    // stockage plein : on garde au moins la version en mémoire
  }
}

async function removeDisk(sourceId: string, kind?: Kind) {
  try {
    const all = await AsyncStorage.getAllKeys();
    const prefix = kind ? `iptv.cat.${sourceId}.${kind}` : `iptv.cat.${sourceId}.`;
    const mine = all.filter(k => k === prefix || k.startsWith(prefix + (kind ? '.' : '')));
    if (mine.length) await AsyncStorage.multiRemove(mine);
  } catch {}
}

/** Vrai si films ET séries sont déjà sur l'appareil (pas besoin de l'écran de chargement). */
export async function catalogReady(src: XtreamSource): Promise<boolean> {
  if (cache.has(`${src.id}:movie`) && cache.has(`${src.id}:series`)) return true;
  try {
    const [m, s] = await AsyncStorage.multiGet([diskKey(src, 'movie'), diskKey(src, 'series')]);
    return !!m[1] && !!s[1];
  } catch {
    return false;
  }
}

export function loadCatalog(
  src: XtreamSource,
  kind: Kind,
  onProgress?: Progress,
): Promise<VodItem[]> {
  const key = `${src.id}:${kind}`;
  const hit = cache.get(key);
  if (hit) {
    return Promise.resolve(hit);
  }
  const running0 = inflight.get(key);
  if (!running0) {
    // Copie sur l'appareil d'abord : instantané
    const fromDisk = readDisk(src, kind).then(d => {
      if (!d || !d.items.length) return null;
      cache.set(key, d.items);
      if (Date.now() - d.at > REFRESH_MS) {
        // trop vieille : mise à jour discrète, sans compteur
        fetchCatalog(src, kind, key, true).catch(() => {});
      }
      return d.items;
    });
    return fromDisk.then(items => items || fetchFromNetwork(src, kind, onProgress));
  }
  return fetchFromNetwork(src, kind, onProgress);
}

function fetchFromNetwork(src: XtreamSource, kind: Kind, onProgress?: Progress): Promise<VodItem[]> {
  const key = `${src.id}:${kind}`;
  const hit = cache.get(key);
  if (hit) {
    return Promise.resolve(hit);
  }
  if (onProgress) {
    if (!listeners.has(key)) {
      listeners.set(key, new Set());
    }
    listeners.get(key)!.add(onProgress);
  }
  const running = inflight.get(key);
  if (running) {
    return running;
  }
  return fetchCatalog(src, kind, key, false);
}

function fetchCatalog(src: XtreamSource, kind: Kind, key: string, silent: boolean): Promise<VodItem[]> {
  const running = inflight.get(key);
  if (running) {
    return running;
  }
  const p = (async () => {
    const cats = kind === 'movie' ? await getVodCategories(src) : await getSeriesCategories(src);
    const queue = [...cats];
    const found = new Map<string, VodItem>();
    let done = 0;
    const worker = async () => {
      while (queue.length) {
        const c = queue.shift()!;
        try {
          const list = kind === 'movie' ? await getVodStreams(src, c.id) : await getSeries(src, c.id);
          const adult = isAdultName(c.name);
          for (const it of list) {
            if (!found.has(it.id)) {
              found.set(it.id, adult ? { ...it, adult: true } : it);
            }
          }
        } catch {
          // une catégorie en erreur ne bloque pas les autres
        }
        done++;
        const fns = silent ? undefined : listeners.get(key);
        if (fns && fns.size) {
          // résultats partiels toutes les 5 catégories (affichage au fur et à mesure)
          const partial = done % 5 === 0 ? Array.from(found.values()) : [];
          fns.forEach(fn => fn(done, cats.length, partial));
        }
      }
    };
    await Promise.all(Array.from({ length: 6 }, () => worker()));
    const all = Array.from(found.values());
    if (all.length || !cache.has(key)) cache.set(key, all);
    if (all.length) await writeDisk(src, kind, all);
    return all;
  })().finally(() => {
    inflight.delete(key);
    listeners.delete(key);
  });

  inflight.set(key, p);
  return p;
}

/** Les plus récemment ajoutés en premier. */
export function newest(items: VodItem[], n: number): VodItem[] {
  return [...items].sort((a, b) => (b.added || 0) - (a.added || 0)).slice(0, n);
}

/** Oublie le catalogue (et sa copie sur l'appareil si une liste est donnée). */
export function clearCatalog(sourceId?: string) {
  if (sourceId) {
    cache.delete(`${sourceId}:movie`);
    cache.delete(`${sourceId}:series`);
    removeDisk(sourceId);
  } else {
    cache.clear();
  }
}
