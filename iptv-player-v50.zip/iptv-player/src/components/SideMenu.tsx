import React, { useRef, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import Icon, { IconName } from './Icon';
import Focusable from './Focusable';
import Logo from './Logo';
import type { Nav } from '../nav/Navigator';
import { goTab, TabKey } from './TabBar';
import { colors } from '../theme';
import { XtreamSource } from '../types';
import { recordingSupported } from '../record';

/** Largeur de la colonne d'icônes (fermée) et du menu ouvert. */
export const SIDE_W = 76;
const OPEN_W = 250;

type Item = { key: string; icon: IconName; label: string; tab?: TabKey; run?: () => void };

/**
 * Menu de gauche pour la télé, comme MyTVOnline 4 : une colonne d'icônes
 * toujours visible, qui s'ouvre avec les noms dès qu'on y met le focus.
 */
export default function SideMenu({
  active,
  source,
  navigation,
}: {
  active: TabKey;
  source: XtreamSource;
  navigation: Nav;
}) {
  const [open, setOpen] = useState(false);
  const closeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const main: Item[] = [
    { key: 'home', icon: 'home', label: 'Accueil', tab: 'home' },
    { key: 'live', icon: 'tv', label: 'En direct', tab: 'live' },
    { key: 'movies', icon: 'film', label: 'Films', tab: 'movies' },
    { key: 'series', icon: 'series', label: 'Séries', tab: 'series' },
    { key: 'favs', icon: 'star', label: 'Favoris', tab: 'favs' },
    { key: 'guide', icon: 'guide', label: 'Guide TV', run: () => navigation.navigate('Guide', { source }) },
    ...(recordingSupported
      ? [{ key: 'rec', icon: 'record' as IconName, label: 'Enregistrements', run: () => navigation.navigate('Recordings') }]
      : []),
    { key: 'search', icon: 'search', label: 'Recherche', run: () => navigation.navigate('Search', { source }) },
  ];
  const bottom: Item[] = [
    { key: 'lists', icon: 'list', label: 'Mes listes', run: () => navigation.popToTop() },
    { key: 'settings', icon: 'settings', label: 'Paramètres', run: () => navigation.navigate('Settings', { source }) },
  ];

  const onFocus = () => {
    if (closeTimer.current) clearTimeout(closeTimer.current);
    setOpen(true);
  };
  const onBlur = () => {
    if (closeTimer.current) clearTimeout(closeTimer.current);
    closeTimer.current = setTimeout(() => setOpen(false), 120);
  };

  const render = (it: Item) => (
    <MenuItem
      key={it.key}
      it={it}
      on={it.tab === active}
      open={open}
      onFocus={onFocus}
      onBlur={onBlur}
      onPress={() => {
        setOpen(false);
        if (it.tab) goTab(it.tab, active, source, navigation);
        else it.run?.();
      }}
    />
  );

  return (
    <View style={[styles.wrap, { width: open ? OPEN_W : SIDE_W }, open && styles.wrapOpen]}>
      <View style={styles.logo}>{open ? <Logo size={22} /> : null}</View>
      <View style={styles.group}>{main.map(render)}</View>
      <View style={{ flex: 1 }} />
      <View style={styles.group}>{bottom.map(render)}</View>
    </View>
  );
}

function MenuItem({
  it,
  on,
  open,
  onFocus,
  onBlur,
  onPress,
}: {
  it: Item;
  on: boolean;
  open: boolean;
  onFocus: () => void;
  onBlur: () => void;
  onPress: () => void;
}) {
  const [focused, setFocused] = useState(false);
  const color = focused ? '#0b0f18' : on ? (it.key === 'favs' ? colors.star : '#fff') : open ? colors.text : colors.muted;
  return (
    <Focusable
      style={[styles.item, open && styles.itemOpen, on && styles.itemOn]}
      focusedStyle={styles.itemFocused}
      onFocus={() => {
        setFocused(true);
        onFocus();
      }}
      onBlur={() => {
        setFocused(false);
        onBlur();
      }}
      onPress={onPress}>
      <Icon name={on && it.key === 'favs' ? 'star-fill' : it.icon} size={22} color={color} />
      {open && (
        <Text style={[styles.label, { color }]} numberOfLines={1}>
          {it.label}
        </Text>
      )}
      {on && !open && <View style={styles.activeBar} />}
    </Focusable>
  );
}

const styles = StyleSheet.create({
  wrap: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    zIndex: 40,
    paddingVertical: 16,
    paddingHorizontal: 10,
    backgroundColor: 'rgba(7,10,18,0.72)',
    borderRightWidth: 1,
    borderRightColor: colors.border,
  },
  wrapOpen: {
    backgroundColor: 'rgba(10,15,34,0.97)',
    shadowColor: '#000',
    shadowOpacity: 0.6,
    shadowRadius: 30,
    elevation: 24,
  },
  logo: { height: 44, justifyContent: 'center', paddingLeft: 12, marginBottom: 8 },
  group: { gap: 4 },
  item: {
    height: 46,
    borderRadius: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: 'transparent',
  },
  itemOpen: { justifyContent: 'flex-start', paddingHorizontal: 14, gap: 14 },
  itemOn: { backgroundColor: 'rgba(79,140,255,0.2)' },
  itemFocused: { backgroundColor: '#e8ebf1', borderColor: '#e8ebf1' },
  label: { color: colors.text, fontSize: 16, fontWeight: '700', flex: 1 },
  labelOn: { color: '#fff' },
  activeBar: { position: 'absolute', left: -10, top: 10, bottom: 10, width: 4, borderRadius: 2, backgroundColor: colors.accent },
});
