import { Channel, Program, Source } from '../types';
import { getShortEpg } from './xtream';

const TTL = 5 * 60 * 1000;
const cache = new Map<string, { at: number; data: Program[] }>();

/** Émission en cours + suivante pour une chaîne (vide si non disponible). */
export async function getNowNext(source: Source, channel: Channel): Promise<Program[]> {
  if (source.type !== 'xtream') {
    return []; // Guide XMLTV pour les listes M3U : version suivante
  }
  const key = `${source.id}:${channel.id}`;
  const hit = cache.get(key);
  const now = Date.now();
  if (hit && now - hit.at < TTL) {
    return hit.data.filter(p => p.end > now).slice(0, 2);
  }
  try {
    const data = await getShortEpg(source, channel.id, 4);
    cache.set(key, { at: now, data });
    return data.filter(p => p.end > now).slice(0, 2);
  } catch {
    return [];
  }
}

export function formatTime(ms: number): string {
  const d = new Date(ms);
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}

export function progressOf(p: Program): number {
  const now = Date.now();
  return Math.min(1, Math.max(0, (now - p.start) / (p.end - p.start)));
}
