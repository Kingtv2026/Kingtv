import { Playlist, Source } from '../types';
import { loadM3u } from './m3u';
import { loadXtream } from './xtream';

export function loadPlaylist(source: Source): Promise<Playlist> {
  return source.type === 'xtream' ? loadXtream(source) : loadM3u(source);
}
