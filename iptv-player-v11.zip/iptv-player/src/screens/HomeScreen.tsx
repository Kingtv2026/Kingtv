import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, useWindowDimensions, View, ViewStyle } from 'react-native';
import { ScreenProps } from '../nav/Navigator';
import Focusable from '../components/Focusable';
import Logo from '../components/Logo';
import Clock from '../components/Clock';
import { Orb } from '../components/Background';
import { xtreamLogin } from '../api/xtream';
import { colors } from '../theme';
import { CAT_FAVORITES } from '../types';

type Props = ScreenProps<'Home'>;

function HomeTile({
  icon,
  title,
  subtitle,
  tint,
  onPress,
  preferred,
  big,
  style,
}: {
  icon: string;
  title: string;
  subtitle?: string;
  tint: string;
  onPress: () => void;
  preferred?: boolean;
  big?: boolean;
  style?: ViewStyle;
}) {
  return (
    <Focusable
      hasTVPreferredFocus={preferred}
      scale={1.04}
      style={[styles.tile, style]}
      onPress={onPress}>
      <View style={[StyleSheet.absoluteFill, { backgroundColor: tint, opacity: 0.13 }]} />
      <Orb
        size={big ? 420 : 240}
        color={tint}
        opacity={0.06}
        style={{ right: big ? -140 : -90, top: big ? -140 : -90 }}
      />
      <Text style={[styles.tileIcon, big && { fontSize: 68 }]}>{icon}</Text>
      <View style={{ flex: 1 }} />
      <Text style={[styles.tileTitle, big && { fontSize: 34 }]}>{title}</Text>
      {!!subtitle && <Text style={styles.tileSub}>{subtitle}</Text>}
    </Focusable>
  );
}

export default function HomeScreen({ route, navigation }: Props) {
  const { source } = route.params;
  const { width } = useWindowDimensions();
  const wide = width >= 700;
  const [expiry, setExpiry] = useState<string | null>(null);
  const [maxConn, setMaxConn] = useState<string | null>(null);

  useEffect(() => {
    xtreamLogin(source)
      .then(data => {
        const u = data?.user_info || {};
        const exp = Number(u.exp_date);
        if (exp > 0) {
          const d = new Date(exp * 1000);
          setExpiry(
            `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`,
          );
        }
        if (u.max_connections) {
          setMaxConn(String(u.max_connections));
        }
      })
      .catch(() => {});
  }, [source]);

  const go = {
    live: () => navigation.navigate('Channels', { source }),
    movies: () => navigation.navigate('Media', { source, kind: 'movie' }),
    series: () => navigation.navigate('Media', { source, kind: 'series' }),
    favs: () => navigation.navigate('Channels', { source, initialCategory: CAT_FAVORITES }),
    lists: () => navigation.goBack(),
  };

  return (
    <View style={styles.container}>
      <View style={styles.top}>
        <Logo size={wide ? 32 : 26} />
        <Clock />
      </View>

      <View style={[styles.grid, wide && { flexDirection: 'row' }]}>
        <HomeTile
          big
          preferred
          icon="📺"
          title="TV en direct"
          subtitle="Chaînes en direct et guide horaire"
          tint={colors.live}
          onPress={go.live}
          style={wide ? { flex: 1.25 } : { height: 170, flex: 0 }}
        />
        <View style={[styles.col, wide ? { flex: 1 } : null]}>
          <View style={styles.rowTiles}>
            <HomeTile icon="🎬" title="Films" subtitle="Vidéo sur demande" tint={colors.accent} onPress={go.movies} />
            <HomeTile icon="🍿" title="Séries" subtitle="Saisons et épisodes" tint={colors.accent2} onPress={go.series} />
          </View>
          <View style={styles.rowTiles}>
            <HomeTile icon="⭐" title="Favoris" subtitle="Tes chaînes préférées" tint={colors.star} onPress={go.favs} />
            <HomeTile icon="📋" title="Mes listes" subtitle="Changer d’abonnement" tint={colors.cyan} onPress={go.lists} />
          </View>
        </View>
      </View>

      <View style={styles.footer}>
        <View style={styles.dot} />
        <Text style={styles.footText} numberOfLines={1}>
          {source.name}
        </Text>
        {expiry && <Text style={styles.footText}>·  Expire le {expiry}</Text>}
        {maxConn && (
          <Text style={styles.footText}>
            ·  {maxConn} connexion{Number(maxConn) > 1 ? 's' : ''}
          </Text>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 28 },
  top: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 },
  grid: { flex: 1, gap: 18 },
  col: { gap: 18, flex: 1 },
  rowTiles: { flex: 1, flexDirection: 'row', gap: 18 },
  tile: {
    flex: 1,
    borderRadius: 22,
    borderWidth: 2,
    borderColor: colors.border,
    backgroundColor: colors.panel,
    padding: 22,
    overflow: 'hidden',
    minHeight: 120,
  },
  tileIcon: { fontSize: 38 },
  tileTitle: { color: colors.text, fontSize: 22, fontWeight: '900' },
  tileSub: { color: 'rgba(244,246,251,0.7)', fontSize: 13, marginTop: 4 },
  footer: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 20, flexWrap: 'wrap' },
  dot: { width: 8, height: 8, borderRadius: 4, backgroundColor: '#34d399' },
  footText: { color: colors.muted, fontSize: 14 },
});
