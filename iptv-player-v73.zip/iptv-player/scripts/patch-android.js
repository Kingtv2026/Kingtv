/**
 * Applique les réglages Android nécessaires au projet généré :
 *  - flux http:// autorisés (aussi en version release)
 *  - Android TV (leanback, pas d'écran tactile requis, bannière)
 *
 * Usage : node scripts/patch-android.js <dossier-du-projet>
 */
const fs = require('fs');
const path = require('path');

const root = path.resolve(process.argv[2] || '.');
const here = path.resolve(__dirname, '..');

// ---------- AndroidManifest.xml ----------
const manifestPath = path.join(root, 'android/app/src/main/AndroidManifest.xml');
let m = fs.readFileSync(manifestPath, 'utf8');

if (/android:usesCleartextTraffic="[^"]*"/.test(m)) {
  m = m.replace(/android:usesCleartextTraffic="[^"]*"/, 'android:usesCleartextTraffic="true"');
} else {
  m = m.replace('<application', '<application\n      android:usesCleartextTraffic="true"');
}

for (const feature of ['android.software.leanback', 'android.hardware.touchscreen']) {
  if (!m.includes(feature)) {
    m = m.replace(
      '<application',
      `<uses-feature android:name="${feature}" android:required="false" />\n    <application`,
    );
  }
}

if (!m.includes('LEANBACK_LAUNCHER')) {
  m = m.replace(
    '<category android:name="android.intent.category.LAUNCHER" />',
    '<category android:name="android.intent.category.LAUNCHER" />\n        <category android:name="android.intent.category.LEANBACK_LAUNCHER" />',
  );
}

const banner = path.join(here, 'assets/banner.png');
if (fs.existsSync(banner)) {
  const resDir = path.join(root, 'android/app/src/main/res');
  const drawable = path.join(resDir, 'drawable');
  fs.mkdirSync(drawable, { recursive: true });
  fs.copyFileSync(banner, path.join(drawable, 'kingtv_banner.png'));
  // Le modèle Android TV a déjà sa propre bannière (image grise par défaut) : on la remplace partout
  const refs = [...m.matchAll(/android:banner="@(drawable|mipmap)\/([\w.]+)"/g)];
  for (const [, kind, name] of refs) {
    for (const d of fs.readdirSync(resDir)) {
      if (!d.startsWith(kind)) continue;
      for (const ext of ['.png', '.xml', '.webp', '.jpg']) {
        const f = path.join(resDir, d, name + ext);
        if (fs.existsSync(f)) {
          fs.rmSync(f);
          console.log('Ancienne bannière retirée :', path.relative(root, f));
        }
      }
    }
  }
  m = m.replace(/\s*android:banner="[^"]*"/g, '');
  m = m.replace('<application', '<application\n      android:banner="@drawable/kingtv_banner"');
  console.log('Bannière Android TV : kingtv_banner');
}

fs.writeFileSync(manifestPath, m);
console.log('AndroidManifest.xml modifié');

// ---------- Nom de l'app ----------
const APP_NAME = 'Ktv';
const stringsPath = path.join(root, 'android/app/src/main/res/values/strings.xml');
if (fs.existsSync(stringsPath)) {
  let x = fs.readFileSync(stringsPath, 'utf8');
  x = x.replace(/<string name="app_name">[^<]*<\/string>/, `<string name="app_name">${APP_NAME}</string>`);
  fs.writeFileSync(stringsPath, x);
  console.log(`Nom de l'app : ${APP_NAME}`);
}

// ---------- Icône ----------
const res = path.join(root, 'android/app/src/main/res');
const iconDir = path.join(here, 'assets/icon');
if (fs.existsSync(iconDir)) {
  for (const d of ['mdpi', 'hdpi', 'xhdpi', 'xxhdpi', 'xxxhdpi']) {
    const dest = path.join(res, `mipmap-${d}`);
    fs.mkdirSync(dest, { recursive: true });
    fs.copyFileSync(path.join(iconDir, `ic_launcher-${d}.png`), path.join(dest, 'ic_launcher.png'));
    fs.copyFileSync(path.join(iconDir, `ic_launcher_round-${d}.png`), path.join(dest, 'ic_launcher_round.png'));
  }
  // Une icône « adaptative » du gabarit passerait par-dessus la nôtre
  fs.rmSync(path.join(res, 'mipmap-anydpi-v26'), { recursive: true, force: true });
  fs.rmSync(path.join(res, 'mipmap-anydpi'), { recursive: true, force: true });
  console.log('Icône remplacée');
}

// ---------- Moteur VLC : processeurs ARM seulement + bibliothèque C++ en double ----------
const gradleProps = path.join(root, 'android/gradle.properties');
if (fs.existsSync(gradleProps)) {
  let g = fs.readFileSync(gradleProps, 'utf8');
  // Téléphones, Fire Stick et boîtiers Android TV sont tous ARM : APK beaucoup plus léger
  if (/^reactNativeArchitectures=.*$/m.test(g)) {
    g = g.replace(/^reactNativeArchitectures=.*$/m, 'reactNativeArchitectures=armeabi-v7a,arm64-v8a');
  } else {
    g += '\nreactNativeArchitectures=armeabi-v7a,arm64-v8a\n';
  }
  // Mémoire de l'app (AsyncStorage) : 6 Mo par défaut, trop petit pour un gros catalogue
  if (/^AsyncStorage_db_size_in_MB=.*$/m.test(g)) {
    g = g.replace(/^AsyncStorage_db_size_in_MB=.*$/m, 'AsyncStorage_db_size_in_MB=100');
  } else {
    g += '\nAsyncStorage_db_size_in_MB=100\n';
  }
  fs.writeFileSync(gradleProps, g);
  console.log('Architectures : armeabi-v7a, arm64-v8a');
}

const appGradle = path.join(root, 'android/app/build.gradle');
if (fs.existsSync(appGradle)) {
  let b = fs.readFileSync(appGradle, 'utf8');
  if (!b.includes('libc++_shared.so')) {
    b = b.replace(
      /\nandroid\s*\{/,
      "\nandroid {\n    packagingOptions {\n        pickFirst '**/libc++_shared.so'\n    }\n",
    );
    fs.writeFileSync(appGradle, b);
    console.log('packagingOptions ajouté');
  }
}

// ---------- Android minimum 8.0 (API 26), exigé par le moteur VLC ----------
const rootGradle = path.join(root, 'android/build.gradle');
if (fs.existsSync(rootGradle)) {
  let r = fs.readFileSync(rootGradle, 'utf8');
  if (/minSdkVersion\s*=\s*\d+/.test(r)) {
    r = r.replace(/minSdkVersion\s*=\s*\d+/, 'minSdkVersion = 26');
    fs.writeFileSync(rootGradle, r);
    console.log('minSdkVersion = 26');
  } else {
    console.warn('minSdkVersion introuvable dans android/build.gradle');
  }
}

function find(dir, name) {
  if (!fs.existsSync(dir)) return null;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      const r = find(p, name);
      if (r) return r;
    } else if (entry.name === name) {
      return p;
    }
  }
  return null;
}

// ---------- Plein écran : masque la barre de navigation et la barre d'état ----------
// (elles réapparaissent un moment en glissant depuis le bord de l'écran)
const mainActivity = find(path.join(root, 'android/app/src/main/java'), 'MainActivity.kt');
if (mainActivity) {
  let a = fs.readFileSync(mainActivity, 'utf8');
  if (!a.includes('hideSystemBars')) {
    a = a.replace(
      /^(package .*)$/m,
      '$1\n\nimport android.os.Build\nimport android.os.Bundle\nimport android.os.Handler\nimport android.os.Looper\nimport android.view.View\nimport android.view.WindowInsets\nimport android.view.WindowInsetsController',
    );
    const end = a.lastIndexOf('}');
    a =
      a.slice(0, end) +
      `
  private val barsHandler = Handler(Looper.getMainLooper())

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    // Si une barre revient (clavier, lecteur…), on la cache de nouveau après 2,5 s
    @Suppress("DEPRECATION")
    window.decorView.setOnSystemUiVisibilityChangeListener { vis ->
      if (vis and View.SYSTEM_UI_FLAG_HIDE_NAVIGATION == 0) {
        barsHandler.removeCallbacksAndMessages(null)
        barsHandler.postDelayed({ hideSystemBars() }, 2500)
      }
    }
    hideSystemBars()
  }

  override fun onResume() {
    super.onResume()
    hideSystemBars()
  }

  override fun onWindowFocusChanged(hasFocus: Boolean) {
    super.onWindowFocusChanged(hasFocus)
    if (hasFocus) hideSystemBars()
  }

  @Suppress("DEPRECATION")
  private fun hideSystemBars() {
    if (Build.VERSION.SDK_INT >= 30) {
      window.insetsController?.let {
        it.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
        it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
      }
    }
    window.decorView.systemUiVisibility =
      View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
      View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
      View.SYSTEM_UI_FLAG_FULLSCREEN
  }
` +
      a.slice(end);
    fs.writeFileSync(mainActivity, a);
    console.log('Plein écran activé (MainActivity)');
  }
}

// ---------- Mise à jour dans l'app (téléchargement + installation) ----------
{
  const manifestFile = path.join(root, 'android/app/src/main/AndroidManifest.xml');
  let mf = fs.readFileSync(manifestFile, 'utf8');
  if (!mf.includes('REQUEST_INSTALL_PACKAGES')) {
    mf = mf.replace(
      /(<manifest[^>]*>)/,
      '$1\n    <uses-permission android:name="android.permission.REQUEST_INSTALL_PACKAGES" />',
    );
  }
  if (!mf.includes('.kingupdate')) {
    mf = mf.replace(
      '</application>',
      `  <provider
        android:name="androidx.core.content.FileProvider"
        android:authorities="\${applicationId}.kingupdate"
        android:exported="false"
        android:grantUriPermissions="true">
        <meta-data
          android:name="android.support.FILE_PROVIDER_PATHS"
          android:resource="@xml/king_update_paths" />
      </provider>
    </application>`,
    );
  }
  fs.writeFileSync(manifestFile, mf);

  const xmlDir = path.join(root, 'android/app/src/main/res/xml');
  fs.mkdirSync(xmlDir, { recursive: true });
  fs.copyFileSync(path.join(here, 'native/king_update_paths.xml'), path.join(xmlDir, 'king_update_paths.xml'));

  const act = find(path.join(root, 'android/app/src/main/java'), 'MainActivity.kt');
  if (act) {
    const pkg = /^package\s+([\w.]+)/m.exec(fs.readFileSync(act, 'utf8'))[1];
    const dir = path.dirname(act);
    for (const f of ['KingUpdateModule.java', 'KingUpdatePackage.java']) {
      const src = fs.readFileSync(path.join(here, 'native', f), 'utf8').replace('__PKG__', pkg);
      fs.writeFileSync(path.join(dir, f), src);
    }
    const appFile = find(path.join(root, 'android/app/src/main/java'), 'MainApplication.kt');
    if (appFile) {
      let app = fs.readFileSync(appFile, 'utf8');
      if (!app.includes('KingUpdatePackage')) {
        if (app.includes('// add(MyReactNativePackage())')) {
          app = app.replace('// add(MyReactNativePackage())', 'add(KingUpdatePackage())');
        } else {
          app = app.replace(/PackageList\(this\)\.packages(\.apply\s*\{)?/, m =>
            m.includes('apply') ? `${m}\n              add(KingUpdatePackage())` : `${m}.apply { add(KingUpdatePackage()) }`,
          );
        }
        fs.writeFileSync(appFile, app);
      }
      console.log('Module de mise à jour ajouté :', app.includes('add(KingUpdatePackage())'));
    }
  }
}

// ---------- Enregistrements (appareil ou clé USB) ----------
{
  const manifestFile = path.join(root, 'android/app/src/main/AndroidManifest.xml');
  const act = find(path.join(root, 'android/app/src/main/java'), 'MainActivity.kt');
  if (act) {
    const pkg = /^package\s+([\w.]+)/m.exec(fs.readFileSync(act, 'utf8'))[1];
    const dir = path.dirname(act);
    for (const f of ['RecStore.java', 'KingRecordService.java', 'KingRecordReceiver.java', 'KingRecordModule.java']) {
      const src = fs.readFileSync(path.join(here, 'native/record', f), 'utf8').replace('__PKG__', pkg);
      fs.writeFileSync(path.join(dir, f), src);
    }
    const drawable = path.join(root, 'android/app/src/main/res/drawable');
    fs.mkdirSync(drawable, { recursive: true });
    fs.copyFileSync(path.join(here, 'native/record/king_rec.png'), path.join(drawable, 'king_rec.png'));

    let mf = fs.readFileSync(manifestFile, 'utf8');
    const perms = [
      'android.permission.FOREGROUND_SERVICE',
      'android.permission.FOREGROUND_SERVICE_DATA_SYNC',
      'android.permission.POST_NOTIFICATIONS',
      'android.permission.WAKE_LOCK',
      'android.permission.RECEIVE_BOOT_COMPLETED',
      'android.permission.USE_EXACT_ALARM',
    ];
    for (const p of perms) {
      if (!mf.includes(`"${p}"`)) {
        mf = mf.replace(/(<manifest[^>]*>)/, `$1\n    <uses-permission android:name="${p}" />`);
      }
    }
    if (!mf.includes('"android.permission.SCHEDULE_EXACT_ALARM"')) {
      mf = mf.replace(
        /(<manifest[^>]*>)/,
        '$1\n    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" android:maxSdkVersion="32" />',
      );
    }
    if (!mf.includes('KingRecordService')) {
      mf = mf.replace(
        '</application>',
        `  <service
        android:name="${pkg}.KingRecordService"
        android:exported="false"
        android:foregroundServiceType="dataSync" />
      <receiver
        android:name="${pkg}.KingRecordReceiver"
        android:exported="true">
        <intent-filter>
          <action android:name="android.intent.action.BOOT_COMPLETED" />
          <action android:name="android.intent.action.QUICKBOOT_POWERON" />
        </intent-filter>
      </receiver>
    </application>`,
      );
    }
    fs.writeFileSync(manifestFile, mf);
    console.log('Enregistrements : service et permissions ajoutés');
  } else {
    console.warn('MainActivity introuvable : enregistrements non ajoutés');
  }
}

// ---------- Touches spéciales de la télécommande (Guide, chiffres, enregistrer…) ----------
{
  const act = find(path.join(root, 'android/app/src/main/java'), 'MainActivity.kt');
  if (act) {
    let a = fs.readFileSync(act, 'utf8');
    if (!a.includes('KingUpdateModule.emitKey')) {
      const end = a.lastIndexOf('}');
      a =
        a.slice(0, end) +
        `
  // Touches que React Native ne transmet pas : on les envoie à l'app
  override fun dispatchKeyEvent(event: android.view.KeyEvent): Boolean {
    if (event.action == android.view.KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
      val code = event.keyCode
      // code brut de toute touche (sauf flèches, OK, retour) : permet d'associer
      // les boutons d'une manette non standard (ex. Guide des Formuler)
      val name: String? = when (code) {
        android.view.KeyEvent.KEYCODE_GUIDE -> "guide"
        android.view.KeyEvent.KEYCODE_DVR -> "dvr"
        android.view.KeyEvent.KEYCODE_MEDIA_RECORD -> "record"
        android.view.KeyEvent.KEYCODE_LAST_CHANNEL -> "last"
        android.view.KeyEvent.KEYCODE_INFO -> "info"
        android.view.KeyEvent.KEYCODE_TV -> "tv"
        android.view.KeyEvent.KEYCODE_BOOKMARK -> "fav"
        android.view.KeyEvent.KEYCODE_PROG_RED -> "red"
        android.view.KeyEvent.KEYCODE_PROG_GREEN -> "green"
        android.view.KeyEvent.KEYCODE_PROG_YELLOW -> "yellow"
        android.view.KeyEvent.KEYCODE_PROG_BLUE -> "blue"
        in android.view.KeyEvent.KEYCODE_0..android.view.KeyEvent.KEYCODE_9 -> "d" + (code - android.view.KeyEvent.KEYCODE_0)
        in android.view.KeyEvent.KEYCODE_NUMPAD_0..android.view.KeyEvent.KEYCODE_NUMPAD_9 -> "d" + (code - android.view.KeyEvent.KEYCODE_NUMPAD_0)
        else -> null
      }
      if (name == null && code !in intArrayOf(19, 20, 21, 22, 23, 66, 4, 3, 24, 25, 164)) {
        KingUpdateModule.emitKey("c" + code)
      }
      if (name != null) {
        val sent = KingUpdateModule.emitKey(name)
        // les chiffres et INFO continuent aussi leur chemin normal (champs de texte, etc.)
        if (sent && !name.startsWith("d") && name != "info") return true
      }
    }
    return super.dispatchKeyEvent(event)
  }
` +
        a.slice(end);
      fs.writeFileSync(act, a);
      console.log('Touches de télécommande branchées (MainActivity)');
    }
  }
}

