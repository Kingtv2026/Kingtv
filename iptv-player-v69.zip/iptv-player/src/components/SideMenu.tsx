import React, { useRef, useState } from 'react';
import FocusTrap from './FocusTrap';
import { StyleSheet, Text, View } from 'react-native';
import Icon, { IconName } from './Icon';
import Focusable from './Focusable';
import Logo from './Logo';
import type { Nav } from '../nav/Navigator';
import { goTab, TabKey } from './TabBar';
import { colors } from '../theme';
import { XtreamSource } from '../types';
import { recordingSupported } from '../record';

/** Largeur de la colonne d'icônes (fermée) et du menu ouvert. */
export const SIDE_W = 58;
const OPEN_W = 220;

type Item = { key: string; icon: IconName; label: string; tab?: TabKey; run?: () => void };

/**
 * Menu de gauche pour la télé, comme MyTVOnline 4 : une colonne d'icônes
 * toujours visible, qui s'ouvre avec les noms dès qu'on y met le focus.
 */
export default function SideMenu({
  active,
  source,
  navigation,
}: {
  active: TabKey;
  source: XtreamSource;
  navigation: Nav;
}) {
  const [open, setOpen] = useState(false);
  const closeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const main: Item[] = [
    { key: 'home', icon: 'home', label: 'Accueil', tab: 'home' },
    { key: 'live', icon: 'tv', label: 'En direct', tab: 'live' },
    { key: 'movies', icon: 'film', label: 'Films', tab: 'movies' },
    { key: 'series', icon: 'series', label: 'Séries', tab: 'series' },
    { key: 'favs', icon: 'star', label: 'Favoris', tab: 'favs' },
    { key: 'guide', icon: 'guide', label: 'Guide TV', run: () => navigation.navigate('Guide', { source }) },
    ...(recordingSupported
      ? [{ key: 'rec', icon: 'record' as IconName, label: 'Enregistrements', run: () => navigation.navigate('Recordings') }]
      : []),
    { key: 'search', icon: 'search', label: 'Recherche', run: () => navigation.navigate('Search', { source }) },
  ];
  const bottom: Item[] = [
    { key: 'lists', icon: 'list', label: 'Mes listes', run: () => navigation.popToTop() },
    { key: 'settings', icon: 'settings', label: 'Paramètres', run: () => navigation.navigate('Settings', { source }) },
  ];

  const onFocus = () => {
    if (closeTimer.current) clearTimeout(closeTimer.current);
    setOpen(true);
  };
  const onBlur = () => {
    if (closeTimer.current) clearTimeout(closeTimer.current);
    closeTimer.current = setTimeout(() => setOpen(false), 120);
  };

  const render = (it: Item) => (
    <MenuItem
      key={it.key}
      it={it}
      on={it.tab === active}
      open={open}
      onFocus={onFocus}
      onBlur={onBlur}
      onPress={() => {
        setOpen(false);
        if (it.tab) goTab(it.tab, active, source, navigation);
        else it.run?.();
      }}
    />
  );

  return (
    <View style={[styles.wrap, { width: open ? OPEN_W : SIDE_W }, open && styles.wrapOpen]}>
      <View style={styles.logo}>{open ? <Logo size={18} /> : null}</View>
      <FocusTrap style={{ flex: 1 }}>
        <View style={styles.group}>{main.map(render)}</View>
        <View style={{ flex: 1 }} />
        <View style={styles.group}>{bottom.map(render)}</View>
      </FocusTrap>
    </View>
  );
}

function MenuItem({
  it,
  on,
  open,
  onFocus,
  onBlur,
  onPress,
}: {
  it: Item;
  on: boolean;
  open: boolean;
  onFocus: () => void;
  onBlur: () => void;
  onPress: () => void;
}) {
  const [focused, setFocused] = useState(false);
  const color = focused ? '#fff' : on ? (it.key === 'favs' ? colors.star : '#fff') : open ? colors.text : colors.muted;
  return (
    <Focusable
      style={[styles.item, open && styles.itemOpen, on && styles.itemOn]}
      focusedStyle={styles.itemFocused}
      onFocus={() => {
        setFocused(true);
        onFocus();
      }}
      onBlur={() => {
        setFocused(false);
        onBlur();
      }}
      onPress={onPress}>
      <Icon name={on && it.key === 'favs' ? 'star-fill' : it.icon} size={19} color={color} />
      {open && (
        <Text style={[styles.label, { color }]} numberOfLines={1}>
          {it.label}
        </Text>
      )}
      {on && !open && <View style={styles.activeBar} />}
    </Focusable>
  );
}

const styles = StyleSheet.create({
  wrap: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    zIndex: 40,
    paddingVertical: 10,
    paddingHorizontal: 6,
    backgroundColor: 'rgba(7,10,18,0.72)',
    borderRightWidth: 1,
    borderRightColor: colors.border,
  },
  wrapOpen: {
    backgroundColor: 'rgba(10,15,34,0.97)',
    shadowColor: '#000',
    shadowOpacity: 0.6,
    shadowRadius: 30,
    elevation: 24,
  },
  logo: { height: 30, justifyContent: 'center', paddingLeft: 10, marginBottom: 4 },
  group: { gap: 2 },
  item: {
    height: 40,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: 'transparent',
  },
  itemOpen: { justifyContent: 'flex-start', paddingHorizontal: 12, gap: 12 },
  itemOn: { backgroundColor: 'rgba(79,140,255,0.2)' },
  itemFocused: { backgroundColor: 'rgba(127,176,255,0.30)', borderColor: '#ffffff' },
  label: { color: colors.text, fontSize: 14, fontWeight: '700', flex: 1 },
  labelOn: { color: '#fff' },
  activeBar: { position: 'absolute', left: -6, top: 9, bottom: 9, width: 3, borderRadius: 2, backgroundColor: colors.accent },
});
