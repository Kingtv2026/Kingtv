import {
  Category,
  Channel,
  Episode,
  MovieInfo,
  Playlist,
  Program,
  Season,
  SeriesInfo,
  VodItem,
  XtreamSource,
} from '../types';
import { decodeMaybeBase64 } from '../utils/base64';

export function normalizeServer(server: string): string {
  let s = server.trim().replace(/\/+$/, '');
  if (!/^https?:\/\//i.test(s)) {
    s = 'http://' + s;
  }
  return s;
}

function parts(src: XtreamSource) {
  return {
    base: normalizeServer(src.server),
    u: encodeURIComponent(src.username),
    p: encodeURIComponent(src.password),
  };
}

export async function xtreamApi(
  src: XtreamSource,
  action?: string,
  params: Record<string, string | number> = {},
): Promise<any> {
  const { base, u, p } = parts(src);
  let url = `${base}/player_api.php?username=${u}&password=${p}`;
  if (action) {
    url += `&action=${action}`;
  }
  for (const [k, v] of Object.entries(params)) {
    url += `&${k}=${encodeURIComponent(String(v))}`;
  }
  const res = await fetch(url);
  if (!res.ok) {
    throw new Error(`Erreur du serveur (${res.status})`);
  }
  return res.json();
}

/** Vérifie les identifiants. Lance une erreur s'ils sont refusés. */
export async function xtreamLogin(src: XtreamSource): Promise<any> {
  const data = await xtreamApi(src);
  if (!data || !data.user_info || Number(data.user_info.auth) === 0) {
    throw new Error('Identifiants refusés par le serveur');
  }
  if (data.user_info.status && data.user_info.status !== 'Active') {
    throw new Error(`Compte ${data.user_info.status}`);
  }
  return data;
}

const asArray = (x: any): any[] => (Array.isArray(x) ? x : []);
const str = (x: any): string | undefined =>
  x === null || x === undefined || x === '' ? undefined : String(x);

function mapCategories(cats: any): Category[] {
  return asArray(cats).map(c => ({
    id: String(c.category_id),
    name: String(c.category_name),
  }));
}

// ---------- TV en direct ----------

export async function loadXtream(src: XtreamSource): Promise<Playlist> {
  const info = await xtreamLogin(src);
  const [cats, streams] = await Promise.all([
    xtreamApi(src, 'get_live_categories'),
    xtreamApi(src, 'get_live_streams'),
  ]);

  // MPEG-TS (flux continu) en priorité : avec HLS, les liens temporaires du
  // serveur expirent après ~30 s et la lecture coupe. HLS seulement si TS interdit.
  const formats: string[] = info.user_info.allowed_output_formats || [];
  const ext = formats.length === 0 || formats.includes('ts') ? 'ts' : 'm3u8';
  const { base, u, p } = parts(src);

  const channels: Channel[] = asArray(streams).map(s => ({
    id: String(s.stream_id),
    name: String(s.name),
    logo: str(s.stream_icon),
    categoryId: String(s.category_id),
    epgId: str(s.epg_channel_id),
    archiveDays: Number(s.tv_archive) === 1 ? Number(s.tv_archive_duration) || 1 : 0,
    streamUrl: `${base}/live/${u}/${p}/${s.stream_id}.${ext}`,
  }));

  return { categories: mapCategories(cats), channels };
}

export async function getShortEpg(
  src: XtreamSource,
  streamId: string,
  limit = 4,
): Promise<Program[]> {
  const data = await xtreamApi(src, 'get_short_epg', {
    stream_id: streamId,
    limit,
  });
  return asArray(data?.epg_listings)
    .map(e => ({
      title: decodeMaybeBase64(String(e.title || '')),
      description: decodeMaybeBase64(String(e.description || '')),
      start: Number(e.start_timestamp) * 1000,
      end: Number(e.stop_timestamp) * 1000,
      startStr: str(e.start),
    }))
    .filter(e => e.start > 0 && e.end > e.start)
    .sort((a, b) => a.start - b.start);
}

// ---------- Films ----------

export async function getVodCategories(src: XtreamSource): Promise<Category[]> {
  return mapCategories(await xtreamApi(src, 'get_vod_categories'));
}

/** categoryId null = tout le catalogue */
export async function getVodStreams(
  src: XtreamSource,
  categoryId: string | null,
): Promise<VodItem[]> {
  const data = await xtreamApi(
    src,
    'get_vod_streams',
    categoryId ? { category_id: categoryId } : {},
  );
  const { base, u, p } = parts(src);
  return asArray(data).map(m => ({
    id: String(m.stream_id),
    name: String(m.name),
    poster: str(m.stream_icon),
    rating: str(m.rating),
    added: Number(m.added) || 0,
    categoryId: str(m.category_id),
    url: `${base}/movie/${u}/${p}/${m.stream_id}.${m.container_extension || 'mp4'}`,
  }));
}

function mapInfo(i: any): MovieInfo {
  if (!i) {
    return {};
  }
  const backdrop = Array.isArray(i.backdrop_path) ? i.backdrop_path[0] : i.backdrop_path;
  const date = str(i.releasedate || i.releaseDate || i.release_date);
  return {
    plot: str(i.plot || i.description),
    genre: str(i.genre),
    duration: str(i.duration),
    year: date ? date.slice(0, 4) : str(i.year),
    rating: str(i.rating),
    director: str(i.director),
    cast: str(i.cast || i.actors),
    poster: str(i.movie_image || i.cover || i.cover_big),
    backdrop: str(backdrop),
  };
}

export async function getMovieInfo(src: XtreamSource, id: string): Promise<MovieInfo> {
  const data = await xtreamApi(src, 'get_vod_info', { vod_id: id });
  return mapInfo(data?.info);
}

// ---------- Séries ----------

export async function getSeriesCategories(src: XtreamSource): Promise<Category[]> {
  return mapCategories(await xtreamApi(src, 'get_series_categories'));
}

/** categoryId null = tout le catalogue */
export async function getSeries(
  src: XtreamSource,
  categoryId: string | null,
): Promise<VodItem[]> {
  const data = await xtreamApi(src, 'get_series', categoryId ? { category_id: categoryId } : {});
  return asArray(data).map(s => ({
    id: String(s.series_id),
    name: String(s.name),
    poster: str(s.cover),
    rating: str(s.rating),
    added: Number(s.last_modified) || 0,
    categoryId: str(s.category_id),
  }));
}

export async function getSeriesInfo(src: XtreamSource, id: string): Promise<SeriesInfo> {
  const data = await xtreamApi(src, 'get_series_info', { series_id: id });
  const { base, u, p } = parts(src);

  // Le serveur renvoie soit { "1": [...], "2": [...] }, soit [[...], [...]]
  const raw = data?.episodes || {};
  const all: { season: number; ep: any }[] = [];
  const entries: [string, any][] = Array.isArray(raw)
    ? raw.map((list, i) => [String(i + 1), list])
    : Object.entries(raw);
  for (const [key, list] of entries) {
    for (const ep of asArray(list)) {
      all.push({ season: Number(ep.season ?? key) || 1, ep });
    }
  }

  const bySeason = new Map<number, Episode[]>();
  for (const { season, ep } of all) {
    const episode: Episode = {
      id: String(ep.id),
      num: Number(ep.episode_num) || 0,
      title: String(ep.title || `Épisode ${ep.episode_num}`),
      plot: str(ep.info?.plot),
      duration: str(ep.info?.duration),
      image: str(ep.info?.movie_image),
      url: `${base}/series/${u}/${p}/${ep.id}.${ep.container_extension || 'mp4'}`,
    };
    if (!bySeason.has(season)) {
      bySeason.set(season, []);
    }
    bySeason.get(season)!.push(episode);
  }

  const seasons: Season[] = Array.from(bySeason.entries())
    .sort((a, b) => a[0] - b[0])
    .map(([number, episodes]) => ({
      number,
      episodes: episodes.sort((a, b) => a.num - b.num),
    }));

  return { info: mapInfo(data?.info), seasons };
}

// ---------- Rattrapage (TV Archive) ----------

function mapListing(e: any): Program {
  return {
    title: decodeMaybeBase64(String(e.title || '')),
    description: decodeMaybeBase64(String(e.description || '')),
    start: Number(e.start_timestamp) * 1000,
    end: Number(e.stop_timestamp) * 1000,
    startStr: str(e.start),
    hasArchive: Number(e.has_archive) === 1,
  };
}

/** Toutes les émissions connues d'une chaîne (passées et à venir). */
export async function getFullEpg(src: XtreamSource, streamId: string): Promise<Program[]> {
  const data = await xtreamApi(src, 'get_simple_data_table', { stream_id: streamId });
  // On trie d'abord sur l'heure (rapide), puis on décode seulement ce qui sert :
  // décoder des jours de titres/descriptions bloquait les boîtiers lents.
  const from = Date.now() / 1000 - 26 * 3600;
  const to = Date.now() / 1000 + 26 * 3600;
  return asArray(data?.epg_listings)
    .filter(e => Number(e.stop_timestamp) > from && Number(e.start_timestamp) < to)
    .map(mapListing)
    .filter(e => e.start > 0 && e.end > e.start)
    .sort((a, b) => a.start - b.start);
}

/** Lien de lecture d'une émission passée, à partir de `offsetMin` minutes du début. */
export function catchupUrl(
  src: XtreamSource,
  streamId: string,
  p: Program,
  offsetMin = 0,
): string | null {
  // « 2026-11-23 20:00:00 » (heure du serveur) → « 2026-11-23:20-00 »
  const m = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})/.exec(p.startStr || '');
  if (!m) {
    return null;
  }
  // Calcul en UTC « fictif » pour ajouter des minutes sans toucher au fuseau du serveur
  const t = new Date(
    Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3]), Number(m[4]), Number(m[5])) + offsetMin * 60000,
  );
  const pad = (n: number) => String(n).padStart(2, '0');
  const start = `${t.getUTCFullYear()}-${pad(t.getUTCMonth() + 1)}-${pad(t.getUTCDate())}:${pad(
    t.getUTCHours(),
  )}-${pad(t.getUTCMinutes())}`;
  const total = Math.max(1, Math.ceil((p.end - p.start) / 60000));
  const minutes = Math.max(1, total - offsetMin);
  const { base, u, p: pw } = parts(src);
  return `${base}/timeshift/${u}/${pw}/${minutes}/${start}/${streamId}.ts`;
}
