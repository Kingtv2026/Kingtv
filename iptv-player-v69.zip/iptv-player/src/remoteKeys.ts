import { useEffect, useRef } from 'react';
import { DeviceEventEmitter } from 'react-native';

/**
 * Touches spéciales de la télécommande envoyées par Android :
 * guide, dvr, record, last, info, tv, fav, red/green/yellow/blue, d0…d9.
 * Le dernier écran inscrit (celui du dessus) passe en premier ; s'il ne
 * gère pas la touche (retourne false), elle passe au suivant.
 */
type Handler = (key: string) => boolean;
const handlers: Handler[] = [];

DeviceEventEmitter.addListener('kingKey', (key: string) => {
  for (let i = handlers.length - 1; i >= 0; i--) {
    try {
      if (handlers[i](key)) return;
    } catch {}
  }
});

/** Inscrit un gestionnaire tant que `active` est vrai (écran visible). */
export function useRemoteKeys(handler: Handler, active = true) {
  const ref = useRef(handler);
  ref.current = handler;
  useEffect(() => {
    if (!active) return;
    const h: Handler = k => ref.current(k);
    handlers.push(h);
    return () => {
      const i = handlers.indexOf(h);
      if (i >= 0) handlers.splice(i, 1);
    };
  }, [active]);
}
