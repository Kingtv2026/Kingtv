package __PKG__;

import android.content.Intent;
import android.net.Uri;
import androidx.core.content.FileProvider;
import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.modules.core.DeviceEventManagerModule;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** Télécharge la nouvelle version de l'app puis ouvre l'installation Android. */
public class KingUpdateModule extends ReactContextBaseJavaModule {
  private final ReactApplicationContext ctx;

  private static ReactApplicationContext sCtx;

  public KingUpdateModule(ReactApplicationContext context) {
    super(context);
    ctx = context;
    sCtx = context;
  }

  /** Envoie une touche de la télécommande (guide, chiffres…) à l'app. Vrai si l'app l'a reçue. */
  public static boolean emitKey(String name) {
    ReactApplicationContext c = sCtx;
    if (c == null) return false;
    try {
      c.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class).emit("kingKey", name);
      return true;
    } catch (Exception e) {
      return false;
    }
  }

  @Override
  public String getName() {
    return "KingUpdate";
  }

  @ReactMethod
  public void downloadAndInstall(final String url, final Promise promise) {
    new Thread(() -> {
      try {
        File file = new File(ctx.getCacheDir(), "update.apk");
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setInstanceFollowRedirects(true);
        conn.setConnectTimeout(20000);
        conn.setReadTimeout(60000);
        long total = conn.getContentLengthLong();
        try (InputStream in = conn.getInputStream(); OutputStream out = new FileOutputStream(file)) {
          byte[] buf = new byte[65536];
          int n;
          long done = 0;
          int last = -1;
          while ((n = in.read(buf)) != -1) {
            out.write(buf, 0, n);
            done += n;
            if (total > 0) {
              int pct = (int) (done * 100 / total);
              if (pct != last) {
                last = pct;
                emit(pct);
              }
            }
          }
        }
        Uri uri = FileProvider.getUriForFile(ctx, ctx.getPackageName() + ".kingupdate", file);
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(uri, "application/vnd.android.package-archive");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        ctx.startActivity(intent);
        promise.resolve(true);
      } catch (Exception e) {
        promise.reject("UPDATE", e.getMessage(), e);
      }
    }).start();
  }

  private void emit(int pct) {
    ctx.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class).emit("KingUpdateProgress", pct);
  }

  @ReactMethod
  public void addListener(String eventName) {}

  @ReactMethod
  public void removeListeners(double count) {}
}
