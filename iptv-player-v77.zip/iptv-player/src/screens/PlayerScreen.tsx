import React, { useCallback, useEffect, useRef, useState } from 'react';
import { isTVLike } from '../device';
import {
  ActivityIndicator,
  Image,
  Platform,
  Pressable,
  StatusBar,
  StyleSheet,
  Text,
  useTVEventHandler,
  useWindowDimensions,
  View,
} from 'react-native';
import Video from 'react-native-video';
// @ts-ignore : la librairie n'a pas de types TypeScript
import { VLCPlayer } from 'react-native-vlc-media-player';
import { getLiveEngine } from '../prefs';
import { ScreenProps } from '../nav/Navigator';
import { getNowNext } from '../api/epg';
import { catchupUrl } from '../api/xtream';
import NowNext from '../components/NowNext';
import Logo from '../components/Logo';
import Clock from '../components/Clock';
import { getQueue, getQueueName, getQueueSource, setLastPlayed, setQueue } from '../playerQueue';
import LiveOverlay from '../components/LiveOverlay';
import VodPlayer from './VodPlayer';
import Focusable from '../components/Focusable';
import RecordSheet from '../components/RecordSheet';
import Icon from '../components/Icon';
import { listRecordings, recordingSupported } from '../record';
import { useRemoteKeys } from '../remoteKeys';
import { describeVideoError, openInVlc } from '../utils/external';
import { colors } from '../theme';
import { Program, XtreamSource } from '../types';

type Props = ScreenProps<'Player'>;

/** Films/séries → moteur VLC intégré ; télé en direct → lecteur Android. */
export default function PlayerScreen(props: Props) {
  const vod = props.route.params.vod;
  if (vod) {
    const liveIndex = vod.catchup?.liveIndex;
    return (
      <VodPlayer
        url={vod.url}
        title={vod.title}
        catchup={vod.catchup}
        onLive={liveIndex !== undefined ? () => props.navigation.replace('Player', { index: liveIndex }) : undefined}
      />
    );
  }
  return <LivePlayer {...props} />;
}

function LivePlayer({ route, navigation }: Props) {
  const vod = route.params.vod;
  const isLive = !vod;

  const queue = getQueue();
  const source = getQueueSource();
  const [index, setIndex] = useState(route.params.index ?? 0);
  const [buffering, setBuffering] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [errorDetail, setErrorDetail] = useState<string | null>(null);
  const [slow, setSlow] = useState(false);
  const [attempt, setAttempt] = useState(0);
  // Reconnexions automatiques du direct avant d'afficher une erreur
  const autoRetry = useRef(0);
  const engine = getLiveEngine();
  // la surveillance ne s'active qu'une fois que la vidéo a vraiment avancé
  const gotProgress = useRef(false);
  const onStreamError = (e: any) => {
    if (autoRetry.current < 3) {
      // coupure du flux : on se reconnecte sans rien afficher
      autoRetry.current++;
      setBuffering(true);
      setTimeout(() => setAttempt(a => a + 1), 1000);
      return;
    }
    setBuffering(false);
    setError('Cette chaîne ne joue pas en ce moment.');
    setErrorDetail(e ? describeVideoError(e) : null);
  };
  // Surveillance : si l'image n'avance plus, on se reconnecte
  const lastProgress = useRef(Date.now());
  const errorRef = useRef<string | null>(null);
  errorRef.current = error;
  const reconnect = useCallback(() => {
    lastProgress.current = Date.now();
    setBuffering(true);
    setAttempt(a => a + 1);
  }, []);
  useEffect(() => {
    if (!isLive) {
      return;
    }
    const t = setInterval(() => {
      if (!pausedLiveRef.current && !errorRef.current && gotProgress.current && Date.now() - lastProgress.current > 20000) {
        reconnect();
      }
    }, 2000);
    return () => clearInterval(t);
  }, [isLive, reconnect]);
  // Pause du direct
  const [pausedAt, setPausedAt] = useState<number | null>(null);
  const pausedLiveRef = useRef(false);
  pausedLiveRef.current = pausedAt !== null;
  const [pauseTick, setPauseTick] = useState(0);
  useEffect(() => {
    if (pausedAt === null) return;
    const t = setInterval(() => setPauseTick(x => x + 1), 1000);
    return () => clearInterval(t);
  }, [pausedAt]);
  const [overlay, setOverlay] = useState(true);
  // Télé : OK = liste des chaînes par-dessus le direct (style MyTVOnline 4)
  const tv = isTVLike();
  const [listOpen, setListOpen] = useState(false);
  const listOpenRef = useRef(false);
  listOpenRef.current = listOpen;
  const listClosedAt = useRef(0);
  const { width: winW } = useWindowDimensions();
  const boxW = Math.round(winW * 0.4);
  const videoBox = { width: boxW, height: Math.round((boxW * 9) / 16), right: 24, top: 34 };
  const closeList = useCallback(() => {
    listClosedAt.current = Date.now();
    setListOpen(false);
  }, []);
  const [epg, setEpg] = useState<Program[]>([]);
  // Enregistrement
  const [recOpen, setRecOpen] = useState(false);
  const recOpenRef = useRef(false);
  recOpenRef.current = recOpen;
  const [toast, setToast] = useState<string | null>(null);
  const [recChannels, setRecChannels] = useState<string[]>([]);
  const hideTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const channel = isLive ? queue[index] : undefined;
  const url = vod ? vod.url : channel?.streamUrl;
  const title = vod ? vod.title : channel?.name;

  const togglePause = () => {
    if (!isLive) return;
    if (pausedAt === null) {
      setPausedAt(Date.now());
      return;
    }
    const since = Date.now() - pausedAt;
    const at = pausedAt;
    setPausedAt(null);
    lastProgress.current = Date.now();
    if (since < 60000) {
      return; // courte pause : l'image reprend où elle était
    }
    // Longue pause : on reprend en différé grâce au rattrapage du serveur
    const nowP = epg.find(p => p.start <= at && p.end > at);
    if (source && source.type === 'xtream' && channel && (channel.archiveDays || 0) > 0 && nowP?.startStr) {
      const offsetMin = Math.max(0, Math.floor((at - nowP.start) / 60000));
      const program = { ...nowP, title: channel.name, end: Date.now() + 4 * 3600 * 1000 };
      const url = catchupUrl(source as XtreamSource, channel.id, program, offsetMin);
      if (url) {
        navigation.replace('Player', {
          vod: {
            url,
            title: channel.name,
            catchup: { source: source as XtreamSource, streamId: channel.id, program, startOffsetMin: offsetMin, liveIndex: index },
          },
        });
        return;
      }
    }
    setToast('Pas de rattrapage sur cette chaîne : retour au direct');
    reconnect();
  };

  const showOverlay = useCallback(() => {
    setOverlay(true);
    if (hideTimer.current) {
      clearTimeout(hideTimer.current);
    }
    hideTimer.current = setTimeout(() => setOverlay(false), 5000);
  }, []);

  const zap = useCallback(
    (delta: number) => {
      if (!isLive || queue.length === 0) {
        return;
      }
      setIndex(i => (i + delta + queue.length) % queue.length);
      setError(null);
      setErrorDetail(null);
      setBuffering(true);
      autoRetry.current = 0;
      gotProgress.current = false;
      lastProgress.current = Date.now();
      showOverlay();
    },
    [isLive, queue.length, showOverlay],
  );

  useEffect(() => {
    showOverlay();
    return () => {
      if (hideTimer.current) {
        clearTimeout(hideTimer.current);
      }
    };
  }, [showOverlay]);

  // Mémorise la dernière chaîne regardée (aperçu du guide)
  useEffect(() => {
    if (channel) setLastPlayed(channel);
  }, [channel]);

  // Chaînes en train d'être enregistrées (pastille REC)
  useEffect(() => {
    if (!isLive || !recordingSupported) {
      return;
    }
    let alive = true;
    const load = () =>
      listRecordings().then(r => {
        if (alive) setRecChannels(r.jobs.filter(j => j.status !== 'scheduled').map(j => j.channel));
      });
    load();
    const t = setInterval(load, 8000);
    return () => {
      alive = false;
      clearInterval(t);
    };
  }, [isLive, recOpen]);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 4500);
    return () => clearTimeout(t);
  }, [toast]);

  // Guide horaire de la chaîne en cours
  useEffect(() => {
    if (!channel || !source) {
      return;
    }
    let cancelled = false;
    setEpg([]);
    getNowNext(source, channel).then(data => {
      if (!cancelled) {
        setEpg(data);
      }
    });
    return () => {
      cancelled = true;
    };
  }, [channel, source]);

  // Touches spéciales : chiffres (numéro de chaîne), chaîne précédente, enregistrer, info
  const [numBuf, setNumBuf] = useState('');
  const numTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const prevIndex = useRef<number | null>(null);
  const curIndex = useRef(index);
  useEffect(() => {
    if (curIndex.current !== index) prevIndex.current = curIndex.current;
    curIndex.current = index;
  }, [index]);
  const goTo = useCallback(
    (target: number) => {
      if (target >= 0 && target < queue.length && target !== curIndex.current) zap(target - curIndex.current);
    },
    [queue.length, zap],
  );
  useRemoteKeys(key => {
    if (!isLive || recOpenRef.current) return false;
    if (key.startsWith('d')) {
      const next = (numBuf + key.slice(1)).slice(-4);
      setNumBuf(next);
      if (numTimer.current) clearTimeout(numTimer.current);
      numTimer.current = setTimeout(() => {
        goTo(Number(next) - 1);
        setNumBuf('');
      }, 1500);
      return true;
    }
    if (key === 'last') {
      if (prevIndex.current !== null) goTo(prevIndex.current);
      return true;
    }
    if (key === 'record' && recordingSupported) {
      setRecOpen(true);
      return true;
    }
    if (key === 'info') {
      showOverlay();
      return true;
    }
    if (key === 'playpause') {
      togglePause();
      return true;
    }
    return false;
  });

  // Télécommande (direct seulement) : haut/bas = changer de chaîne, OK = infos.
  // En film/série, les contrôles natifs du lecteur gèrent la télécommande.
  useTVEventHandler(evt => {
    if (!evt || !isLive || recOpenRef.current) {
      return;
    }
    if (evt.eventType === 'playPause' || evt.eventType === 'play' || evt.eventType === 'pause') {
      togglePause();
      return;
    }
    if (evt.eventType === 'longSelect' && recordingSupported) {
      setRecOpen(true);
      return;
    }
    if (listOpenRef.current) return; // la liste des chaînes gère la télécommande
    if (evt.eventType === 'up' || evt.eventType === 'channelUp') {
      zap(-1);
    } else if (evt.eventType === 'down' || evt.eventType === 'channelDown') {
      zap(1);
    } else if (evt.eventType === 'select') {
      if (tv && channel && Date.now() - listClosedAt.current > 600) {
        setOverlay(false);
        setListOpen(true);
      } else showOverlay();
    }
  });

  // Film/série qui charge depuis plus de 20 s : on propose VLC
  useEffect(() => {
    setSlow(false);
    if (!buffering || error) {
      return;
    }
    const t = setTimeout(() => setSlow(true), 20000);
    return () => clearTimeout(t);
  }, [buffering, error, url, attempt]);

  const retry = () => {
    setError(null);
    setErrorDetail(null);
    setBuffering(true);
    setAttempt(a => a + 1);
  };

  if (!url) {
    return (
      <View style={styles.container}>
        <Text style={styles.errorText}>Rien à lire.</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <StatusBar hidden />
      {engine === 'vlc' ? (
        <VLCPlayer
          key={`${url}#${attempt}`}
          paused={pausedAt !== null}
          style={listOpen ? [styles.box, videoBox] : StyleSheet.absoluteFill}
          source={{
            uri: url,
            initType: 2,
            initOptions: ['--network-caching=3000', '--live-caching=3000', '--http-reconnect'],
          }}
          autoplay
          resizeMode="contain"
          onPlaying={() => {
            setBuffering(false);
            autoRetry.current = 0;
            lastProgress.current = Date.now();
          }}
          onBuffering={() => setBuffering(true)}
          onProgress={() => {
            gotProgress.current = true;
            lastProgress.current = Date.now();
            setBuffering(false);
          }}
          onEnd={() => reconnect()}
          onError={() => onStreamError(null)}
        />
      ) : (
      <Video
          key={`${url}#${attempt}`}
          paused={pausedAt !== null}
          source={{ uri: url }}
          style={listOpen ? [styles.box, videoBox] : StyleSheet.absoluteFill}
          resizeMode="contain"
          controls={!isLive}
          onLoad={() => {
            setBuffering(false);
            autoRetry.current = 0;
          }}
          onBuffer={({ isBuffering }) => setBuffering(isBuffering)}
          progressUpdateInterval={1000}
          onProgress={() => {
            gotProgress.current = true;
            lastProgress.current = Date.now();
          }}
          onEnd={() => {
            // le serveur a fermé le flux : en direct, on se reconnecte
            if (isLive) {
              reconnect();
            }
          }}
          onError={(e: any) => onStreamError(e)}
          bufferConfig={{
            minBufferMs: 5000,
            maxBufferMs: 30000,
            bufferForPlaybackMs: 1500,
            bufferForPlaybackAfterRebufferMs: 3000,
          }}
        />
      )}

      {/* Zone tactile (téléphone, direct) pour afficher les infos */}
      {isLive && (
        <Pressable
          style={StyleSheet.absoluteFill}
          onPress={showOverlay}
          focusable={false}
        />
      )}

      {buffering && !error && (
        <ActivityIndicator size="large" color={colors.accent} style={styles.spinner} />
      )}

      {(error || (slow && !isLive)) && (
        <View style={styles.errorBox}>
          <Text style={styles.errorText}>
            {error || 'Le chargement est long… ce format n’est peut-être pas pris en charge.'}
          </Text>
          {!!errorDetail && <Text style={styles.errorDetail}>{errorDetail}</Text>}
          <View style={styles.errorButtons}>
            <Focusable hasTVPreferredFocus style={styles.errBtn} onPress={retry}>
              <Text style={styles.errBtnText}>↻  Réessayer</Text>
            </Focusable>
            {!isLive && (
              <Focusable style={[styles.errBtn, styles.vlcBtn]} onPress={() => openInVlc(url)}>
                <Text style={styles.errBtnText}>Ouvrir avec VLC</Text>
              </Focusable>
            )}
          </View>
        </View>
      )}

      {listOpen && channel && source && (
        <LiveOverlay
          source={source}
          queue={queue}
          queueName={getQueueName() || 'Chaînes'}
          playing={channel}
          videoBox={videoBox}
          onClose={closeList}
          onPlay={(list, i, name) => {
            setQueue(list, source, name);
            setIndex(i);
            setError(null);
            setErrorDetail(null);
            setBuffering(true);
            autoRetry.current = 0;
            gotProgress.current = false;
            lastProgress.current = Date.now();
          }}
        />
      )}

      {overlay && isLive && !listOpen && (
        <>
          <View style={styles.topBar} pointerEvents="none">
            <Logo size={22} />
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
              {!!title && recChannels.includes(title) && (
                <View style={styles.recPill}>
                  <View style={styles.recDot} />
                  <Text style={styles.recText}>REC</Text>
                </View>
              )}
              <Clock />
            </View>
          </View>
          <View style={styles.overlay} pointerEvents="box-none">
            <View style={styles.info}>
              <View style={styles.infoHead}>
                <View style={styles.logoBox}>
                  {channel?.logo ? (
                    <Image source={{ uri: channel.logo }} style={styles.logo} resizeMode="contain" />
                  ) : (
                    <Text style={styles.logoLetter}>{(title || '?').charAt(0)}</Text>
                  )}
                </View>
                <Text style={styles.number}>{index + 1}</Text>
                <View style={{ flex: 1 }}>
                  <Text style={styles.name} numberOfLines={1}>
                    {title}
                  </Text>
                  <View style={styles.livePill}>
                    <View style={styles.liveDot} />
                    <Text style={styles.liveText}>EN DIRECT</Text>
                  </View>
                </View>
              </View>
              {epg.length > 0 && <NowNext programs={epg} />}
              {recordingSupported && isTVLike() && (
                <Text style={styles.recHint}>Maintiens OK pour enregistrer</Text>
              )}
            </View>
            {!isTVLike() && (
              <View style={styles.zapButtons}>
                <Pressable style={styles.zapBtn} onPress={togglePause}>
                  <Text style={styles.zapText}>{pausedAt !== null ? '▶' : '❚❚'}</Text>
                </Pressable>
                {recordingSupported && (
                  <Pressable style={[styles.zapBtn, styles.recBtn]} onPress={() => setRecOpen(true)}>
                    <Icon name="record" size={24} color="#fff" />
                  </Pressable>
                )}
                <Pressable style={styles.zapBtn} onPress={() => zap(-1)}>
                  <Text style={styles.zapText}>▲</Text>
                </Pressable>
                <Pressable style={styles.zapBtn} onPress={() => zap(1)}>
                  <Text style={styles.zapText}>▼</Text>
                </Pressable>
              </View>
            )}
          </View>
        </>
      )}

      {pausedAt !== null && (
        <View style={styles.pauseBox} pointerEvents="none">
          <Text style={styles.pauseIcon}>❚❚</Text>
          <Text style={styles.pauseTitle}>En pause</Text>
          <Text style={styles.pauseSince}>
            depuis {Math.floor((Date.now() - pausedAt) / 60000)}:{String(Math.floor(((Date.now() - pausedAt) / 1000) % 60)).padStart(2, '0')}
            {pauseTick < 0 ? '' : ''}
          </Text>
          <Text style={styles.pauseHint}>
            {isTVLike() ? 'Lecture/Pause pour reprendre' : 'Touche ▶ pour reprendre'}
            {channel && (channel.archiveDays || 0) > 0 ? ' · reprise là où tu étais' : ''}
          </Text>
        </View>
      )}

      {!!numBuf && (
        <View style={styles.numBox} pointerEvents="none">
          <Text style={styles.numText}>{numBuf}</Text>
          <Text style={styles.numName} numberOfLines={1}>
            {queue[Number(numBuf) - 1]?.name || 'Aucune chaîne'}
          </Text>
        </View>
      )}

      {!!toast && (
        <View style={styles.toast} pointerEvents="none">
          <Icon name="record" size={18} color={colors.live} />
          <Text style={styles.toastText}>{toast}</Text>
        </View>
      )}

      {recOpen && channel && url && (
        <RecordSheet
          url={url}
          channel={channel.name}
          program={epg.find(p => p.start <= Date.now() && p.end > Date.now()) || null}
          onClose={() => setRecOpen(false)}
          onDone={msg => {
            setRecOpen(false);
            setToast(msg);
          }}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  box: { position: 'absolute', backgroundColor: '#000', borderRadius: 10, overflow: 'hidden' },
  container: { flex: 1, backgroundColor: '#000', justifyContent: 'center' },
  spinner: { position: 'absolute', alignSelf: 'center' },
  errorBox: {
    position: 'absolute',
    alignSelf: 'center',
    backgroundColor: 'rgba(7,10,18,0.85)',
    padding: 18,
    borderRadius: 14,
  },
  errorText: { color: colors.text, fontSize: 17, fontWeight: '700', textAlign: 'center' },
  errorDetail: { color: colors.muted, fontSize: 12, textAlign: 'center', marginTop: 8, maxWidth: 520 },
  errorButtons: { flexDirection: 'row', gap: 12, justifyContent: 'center', marginTop: 16 },
  errBtn: {
    paddingHorizontal: 20,
    paddingVertical: 11,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: colors.border,
    backgroundColor: colors.panelAlt,
  },
  vlcBtn: { backgroundColor: '#f97316', borderColor: '#f97316' },
  errBtnText: { color: '#fff', fontSize: 15, fontWeight: '800' },
  topBar: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    paddingHorizontal: 28,
    paddingVertical: 18,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'rgba(7,10,18,0.55)',
  },
  overlay: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    padding: 24,
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
  },
  info: {
    flex: 1,
    maxWidth: 760,
    backgroundColor: 'rgba(7,10,18,0.82)',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
    paddingHorizontal: 22,
    paddingVertical: 18,
  },
  infoHead: { flexDirection: 'row', alignItems: 'center', marginBottom: 14 },
  logoBox: {
    width: 72,
    height: 50,
    borderRadius: 10,
    backgroundColor: 'rgba(255,255,255,0.08)',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 14,
    overflow: 'hidden',
  },
  logo: { width: '86%', height: '86%' },
  logoLetter: { color: colors.muted, fontSize: 22, fontWeight: '900' },
  number: { color: colors.accent, fontSize: 28, fontWeight: '900', marginRight: 14 },
  name: { color: '#fff', fontSize: 22, fontWeight: '800' },
  livePill: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 4 },
  liveDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: colors.live },
  liveText: { color: colors.live, fontSize: 11, fontWeight: '900', letterSpacing: 1 },
  zapButtons: { gap: 12, marginLeft: 14 },
  zapBtn: {
    backgroundColor: 'rgba(7,10,18,0.82)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
    width: 56,
    height: 56,
    borderRadius: 28,
    alignItems: 'center',
    justifyContent: 'center',
  },
  zapText: { color: '#fff', fontSize: 20 },
  recBtn: { backgroundColor: 'rgba(255,59,92,0.85)', borderColor: colors.live },
  recPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(255,59,92,0.2)',
    borderColor: colors.live,
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  recDot: { width: 9, height: 9, borderRadius: 5, backgroundColor: colors.live },
  recText: { color: '#fff', fontSize: 12, fontWeight: '900', letterSpacing: 1 },
  recHint: { color: colors.muted, fontSize: 12, marginTop: 10 },
  toast: {
    position: 'absolute',
    top: 70,
    alignSelf: 'center',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: 'rgba(7,10,18,0.92)',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
    paddingHorizontal: 16,
    paddingVertical: 10,
    maxWidth: '90%',
  },
  toastText: { color: '#fff', fontSize: 14, fontWeight: '700' },
  pauseBox: {
    position: 'absolute',
    alignSelf: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(7,10,18,0.85)',
    borderRadius: 20,
    paddingHorizontal: 34,
    paddingVertical: 20,
  },
  pauseIcon: { color: '#fff', fontSize: 40, fontWeight: '900' },
  pauseTitle: { color: '#fff', fontSize: 20, fontWeight: '900', marginTop: 4 },
  pauseSince: { color: colors.muted, fontSize: 14, marginTop: 4 },
  pauseHint: { color: colors.muted, fontSize: 12, marginTop: 8 },
  numBox: {
    position: 'absolute',
    top: 70,
    right: 30,
    minWidth: 150,
    alignItems: 'flex-end',
    backgroundColor: 'rgba(7,10,18,0.88)',
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
    paddingHorizontal: 20,
    paddingVertical: 12,
  },
  numText: { color: '#fff', fontSize: 44, fontWeight: '900', letterSpacing: 2 },
  numName: { color: colors.muted, fontSize: 14, fontWeight: '700', maxWidth: 260 },
});
