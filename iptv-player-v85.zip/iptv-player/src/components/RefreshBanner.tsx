/**
 * Petit bandeau en haut de l'écran, comme MyTVOnline 4 :
 * « Actualisation des contenus… » pendant la vérification,
 * puis « Nouveautés : 3 films, 1 série » quand il y en a.
 */
import React, { useEffect, useRef, useState } from 'react';
import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';
import { onCatalogStatus } from '../api/catalog';
import { colors } from '../theme';

let mutedCount = 0;
const muteListeners = new Set<() => void>();
/** Caché pendant la lecture d'une chaîne ou d'un film. */
export function setBannerMuted(v: boolean) {
  mutedCount = Math.max(0, mutedCount + (v ? 1 : -1));
  muteListeners.forEach(fn => fn());
}

export default function RefreshBanner() {
  const [running, setRunning] = useState(0);
  const [done, setDone] = useState<string | null>(null);
  const [, force] = useState(0);
  const added = useRef({ movie: 0, series: 0 });
  const hideTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    const m = () => force(x => x + 1);
    muteListeners.add(m);
    const off = onCatalogStatus(s => {
      if (s.running) {
        if (hideTimer.current) clearTimeout(hideTimer.current);
        setDone(null);
        setRunning(r => r + 1);
        return;
      }
      added.current[s.kind] += s.added || 0;
      setRunning(r => {
        const left = Math.max(0, r - 1);
        if (left === 0) {
          const { movie, series } = added.current;
          added.current = { movie: 0, series: 0 };
          const parts = [
            movie ? `${movie} film${movie > 1 ? 's' : ''}` : '',
            series ? `${series} série${series > 1 ? 's' : ''}` : '',
          ].filter(Boolean);
          setDone(parts.length ? `✓ Nouveautés : ${parts.join(', ')}` : '✓ Contenus à jour');
          if (hideTimer.current) clearTimeout(hideTimer.current);
          hideTimer.current = setTimeout(() => setDone(null), parts.length ? 6000 : 2500);
        }
        return left;
      });
    });
    return () => {
      off();
      muteListeners.delete(m);
      if (hideTimer.current) clearTimeout(hideTimer.current);
    };
  }, []);

  if (mutedCount > 0 || (!running && !done)) return null;
  return (
    <View style={styles.wrap} pointerEvents="none">
      <View style={styles.pill}>
        {running > 0 ? (
          <>
            <ActivityIndicator size="small" color={colors.accent} />
            <Text style={styles.text}>Actualisation des contenus…</Text>
          </>
        ) : (
          <Text style={[styles.text, done?.startsWith('✓ Nouveautés') && { color: '#7fffb0' }]}>{done}</Text>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { position: 'absolute', top: 10, left: 0, right: 0, alignItems: 'center', zIndex: 999 },
  pill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: 'rgba(12,18,52,0.94)',
    borderColor: 'rgba(127,176,255,0.55)',
    borderWidth: 1,
    borderRadius: 18,
    paddingHorizontal: 18,
    paddingVertical: 8,
  },
  text: { color: '#fff', fontSize: 14, fontWeight: '800' },
});
