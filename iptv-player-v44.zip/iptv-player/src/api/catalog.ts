/**
 * Catalogue complet des films ou des séries, chargé catégorie par catégorie
 * (6 à la fois) pour ne pas saturer la mémoire du téléphone. Gardé en mémoire.
 */
import { VodItem, XtreamSource } from '../types';
import { getSeries, getSeriesCategories, getVodCategories, getVodStreams } from './xtream';
import { isAdultName } from '../parental';

type Kind = 'movie' | 'series';
const cache = new Map<string, VodItem[]>();
const inflight = new Map<string, Promise<VodItem[]>>();
type Progress = (done: number, total: number, partial: VodItem[]) => void;
const listeners = new Map<string, Set<Progress>>();

export function loadCatalog(
  src: XtreamSource,
  kind: Kind,
  onProgress?: Progress,
): Promise<VodItem[]> {
  const key = `${src.id}:${kind}`;
  const hit = cache.get(key);
  if (hit) {
    return Promise.resolve(hit);
  }
  if (onProgress) {
    if (!listeners.has(key)) {
      listeners.set(key, new Set());
    }
    listeners.get(key)!.add(onProgress);
  }
  const running = inflight.get(key);
  if (running) {
    return running;
  }

  const p = (async () => {
    const cats = kind === 'movie' ? await getVodCategories(src) : await getSeriesCategories(src);
    const queue = [...cats];
    const found = new Map<string, VodItem>();
    let done = 0;
    const worker = async () => {
      while (queue.length) {
        const c = queue.shift()!;
        try {
          const list = kind === 'movie' ? await getVodStreams(src, c.id) : await getSeries(src, c.id);
          const adult = isAdultName(c.name);
          for (const it of list) {
            if (!found.has(it.id)) {
              found.set(it.id, adult ? { ...it, adult: true } : it);
            }
          }
        } catch {
          // une catégorie en erreur ne bloque pas les autres
        }
        done++;
        const fns = listeners.get(key);
        if (fns && fns.size) {
          // résultats partiels toutes les 5 catégories (affichage au fur et à mesure)
          const partial = done % 5 === 0 ? Array.from(found.values()) : [];
          fns.forEach(fn => fn(done, cats.length, partial));
        }
      }
    };
    await Promise.all(Array.from({ length: 6 }, () => worker()));
    const all = Array.from(found.values());
    cache.set(key, all);
    return all;
  })().finally(() => {
    inflight.delete(key);
    listeners.delete(key);
  });

  inflight.set(key, p);
  return p;
}

/** Les plus récemment ajoutés en premier. */
export function newest(items: VodItem[], n: number): VodItem[] {
  return [...items].sort((a, b) => (b.added || 0) - (a.added || 0)).slice(0, n);
}

export function clearCatalog() {
  cache.clear();
}
