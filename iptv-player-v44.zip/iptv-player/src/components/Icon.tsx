import React from 'react';
import { Image, ImageStyle, StyleProp } from 'react-native';
import { colors } from '../theme';

/** Jeu d'icônes Kingtv (traits fins, recolorables). */
const ICONS = {
  'download': require('../assets/icons/download.png'),
  'record': require('../assets/icons/record.png'),
  'stop': require('../assets/icons/stop.png'),
  'clock': require('../assets/icons/clock.png'),
  'usb': require('../assets/icons/usb.png'),
  'edit': require('../assets/icons/edit.png'),
  'file': require('../assets/icons/file.png'),
  'film': require('../assets/icons/film.png'),
  'folder': require('../assets/icons/folder.png'),
  'guide': require('../assets/icons/guide.png'),
  'home': require('../assets/icons/home.png'),
  'info': require('../assets/icons/info.png'),
  'key': require('../assets/icons/key.png'),
  'list': require('../assets/icons/list.png'),
  'lock': require('../assets/icons/lock.png'),
  'play': require('../assets/icons/play.png'),
  'play-circle': require('../assets/icons/play-circle.png'),
  'plus': require('../assets/icons/plus.png'),
  'refresh': require('../assets/icons/refresh.png'),
  'satellite': require('../assets/icons/satellite.png'),
  'search': require('../assets/icons/search.png'),
  'series': require('../assets/icons/series.png'),
  'settings': require('../assets/icons/settings.png'),
  'shield': require('../assets/icons/shield.png'),
  'star': require('../assets/icons/star.png'),
  'star-fill': require('../assets/icons/star-fill.png'),
  'trash': require('../assets/icons/trash.png'),
  'tv': require('../assets/icons/tv.png'),
};

export type IconName = keyof typeof ICONS;

export default function Icon({
  name,
  size = 22,
  color = colors.text,
  style,
}: {
  name: IconName;
  size?: number;
  color?: string;
  style?: StyleProp<ImageStyle>;
}) {
  return (
    <Image
      source={ICONS[name]}
      fadeDuration={0}
      style={[{ width: size, height: size, tintColor: color }, style]}
    />
  );
}
