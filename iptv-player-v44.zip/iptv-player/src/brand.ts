import AsyncStorage from '@react-native-async-storage/async-storage';
import { useEffect, useState } from 'react';

/** Logo du vendeur (revendeur) envoyé par le panneau. Vide = logo Kingtv. */
export interface Brand {
  logo?: string;
  w?: number;
  h?: number;
}

const K_BRAND = 'iptv.brand';
let current: Brand = {};
const listeners = new Set<(b: Brand) => void>();

export async function loadBrand() {
  try {
    const raw = await AsyncStorage.getItem(K_BRAND);
    if (raw) {
      current = JSON.parse(raw) || {};
      listeners.forEach(l => l(current));
    }
  } catch {}
}

export async function setBrand(b: any) {
  const next: Brand =
    b && typeof b.logo === 'string' && /^https?:\/\//.test(b.logo)
      ? { logo: b.logo, w: Number(b.w) || undefined, h: Number(b.h) || undefined }
      : {};
  if (JSON.stringify(next) === JSON.stringify(current)) return;
  current = next;
  listeners.forEach(l => l(current));
  try {
    await AsyncStorage.setItem(K_BRAND, JSON.stringify(next));
  } catch {}
}

export function useBrand(): Brand {
  const [b, setB] = useState<Brand>(current);
  useEffect(() => {
    listeners.add(setB);
    setB(current);
    return () => {
      listeners.delete(setB);
    };
  }, []);
  return b;
}
