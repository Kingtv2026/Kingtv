import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, Alert, BackHandler, ScrollView, StyleSheet, Text, View } from 'react-native';
import Icon from '../components/Icon';
import { ScreenProps, useFocusEffect } from '../nav/Navigator';
import Focusable from '../components/Focusable';
import Logo from '../components/Logo';
import Clock from '../components/Clock';
import { getSources, removeSource } from '../storage';
import { colors } from '../theme';
import { Source } from '../types';
import { openSource } from '../navigation';
import { clearCaches, loadPlaylist } from '../api';
import { PANEL_SOURCE_ID } from '../license';

type Props = ScreenProps<'Sources'>;

const host = (s: string) => s.replace(/^https?:\/\//i, '').split('/')[0];

export default function SourcesScreen({ navigation }: Props) {
  const [sources, setSources] = useState<Source[]>([]);
  const [menu, setMenu] = useState<Source | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  // Retour : ferme le menu
  useEffect(() => {
    if (!menu) {
      return;
    }
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      setMenu(null);
      return true;
    });
    return () => sub.remove();
  }, [menu]);

  useEffect(() => {
    if (!toast) {
      return;
    }
    const t = setTimeout(() => setToast(null), 3000);
    return () => clearTimeout(t);
  }, [toast]);

  const refresh = async (s: Source) => {
    setMenu(null);
    setBusy(true);
    clearCaches(s.id);
    try {
      const pl = await loadPlaylist(s);
      setToast(`« ${s.name} » actualisée : ${pl.channels.length} chaînes`);
    } catch (e: any) {
      setToast(`Échec de l’actualisation : ${e?.message || 'serveur injoignable'}`);
    } finally {
      setBusy(false);
    }
  };

  useFocusEffect(
    useCallback(() => {
      getSources().then(setSources);
    }, []),
  );

  const confirmDelete = (s: Source) => {
    setMenu(null);
    Alert.alert('Supprimer', `Supprimer « ${s.name} » ?`, [
      { text: 'Annuler', style: 'cancel' },
      {
        text: 'Supprimer',
        style: 'destructive',
        onPress: async () => {
          await removeSource(s.id);
          setSources(await getSources());
        },
      },
    ]);
  };

  return (
    <View style={{ flex: 1 }}>
    <ScrollView contentContainerStyle={styles.content}>
      <View style={styles.top}>
        <Logo size={34} />
        <Clock />
      </View>

      <View style={styles.inner}>
        <Text style={styles.h1}>Bienvenue</Text>
        <Text style={styles.sub}>Choisis la liste à ouvrir</Text>

        {sources.map((s, i) => (
          <View key={s.id} style={styles.cardRow}>
          <Focusable
            hasTVPreferredFocus={i === 0}
            scale={1.02}
            style={[styles.card, { flex: 1, marginBottom: 0 }]}
            onPress={() => openSource(navigation, s)}
            onLongPress={() => setMenu(s)}>
            <View style={[styles.iconBox, { backgroundColor: 'rgba(79,140,255,0.16)' }]}>
              <Icon name={s.type === 'xtream' ? 'satellite' : 'file'} size={26} color={colors.accent} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.name} numberOfLines={1}>
                {s.name}
              </Text>
              <Text style={styles.meta} numberOfLines={1}>
                {s.type === 'xtream' ? `Xtream Codes · ${host(s.server)}` : 'Liste M3U'}
              </Text>
            </View>
            <Text style={styles.chevron}>›</Text>
          </Focusable>
          <Focusable style={styles.moreBtn} onPress={() => setMenu(s)}>
            <Text style={styles.moreText}>⋮</Text>
          </Focusable>
          </View>
        ))}

        <Focusable
          hasTVPreferredFocus={sources.length === 0}
          scale={1.02}
          style={[styles.card, styles.addCard]}
          onPress={() => navigation.navigate('AddSource')}>
          <View style={[styles.iconBox, { backgroundColor: colors.accent }]}>
            <Icon name="plus" size={26} color="#fff" />
          </View>
          <Text style={styles.addText}>Ajouter ma propre liste</Text>
        </Focusable>

        {sources.length > 0 && (
          <Text style={styles.hint}>⋮ = modifier, actualiser ou supprimer une liste</Text>
        )}
      </View>
    </ScrollView>

    {busy && (
      <View style={styles.overlay}>
        <ActivityIndicator size="large" color={colors.accent} />
        <Text style={styles.overlayText}>Actualisation du contenu…</Text>
      </View>
    )}

    {menu && (
      <View style={styles.overlay}>
        <View style={styles.sheet}>
          <Text style={styles.sheetTitle} numberOfLines={1}>
            {menu.name}
          </Text>
          {menu.id === PANEL_SOURCE_ID && (
            <View style={[styles.sheetLine, { marginBottom: 10, marginLeft: 4 }]}>
              <Icon name="lock" size={16} color={colors.muted} />
              <Text style={[styles.managed, { marginBottom: 0, marginLeft: 0 }]}>Liste envoyée par ton fournisseur</Text>
            </View>
          )}
          <Focusable
            hasTVPreferredFocus
            style={styles.sheetRow}
            onPress={() => {
              const s = menu;
              setMenu(null);
              navigation.navigate('AddSource', { edit: s });
            }}>
            <View style={styles.sheetLine}><Icon name="edit" size={20} /><Text style={styles.sheetText}>Modifier la liste</Text></View>
          </Focusable>
          <Focusable
            style={styles.sheetRow}
            onPress={() => refresh(menu)}>
            <View style={styles.sheetLine}><Icon name="refresh" size={20} /><Text style={styles.sheetText}>Actualiser le contenu</Text></View>
          </Focusable>
          {menu.id !== PANEL_SOURCE_ID && (
            <Focusable style={styles.sheetRow} onPress={() => confirmDelete(menu)}>
              <View style={styles.sheetLine}><Icon name="trash" size={20} color={colors.danger} /><Text style={[styles.sheetText, { color: colors.danger }]}>Supprimer</Text></View>
            </Focusable>
          )}
          <Focusable style={[styles.sheetRow, styles.sheetCancel]} onPress={() => setMenu(null)}>
            <Text style={[styles.sheetText, { textAlign: 'center' }]}>Annuler</Text>
          </Focusable>
        </View>
      </View>
    )}

    {toast && (
      <View style={styles.toast} pointerEvents="none">
        <Text style={styles.toastText}>{toast}</Text>
      </View>
    )}
    </View>
  );
}

const styles = StyleSheet.create({
  content: { padding: 28, flexGrow: 1 },
  top: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  inner: { width: '100%', maxWidth: 640, alignSelf: 'center', marginTop: 36 },
  h1: { color: colors.text, fontSize: 34, fontWeight: '900' },
  sub: { color: colors.muted, fontSize: 16, marginTop: 4, marginBottom: 24 },
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    padding: 16,
    marginBottom: 12,
    borderRadius: 18,
    borderWidth: 2,
    borderColor: colors.border,
    backgroundColor: colors.panel,
  },
  addCard: { borderStyle: 'dashed', borderColor: 'rgba(79,140,255,0.45)' },
  iconBox: { width: 52, height: 52, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  icon: { fontSize: 26 },
  name: { color: colors.text, fontSize: 19, fontWeight: '700' },
  meta: { color: colors.muted, fontSize: 14, marginTop: 3 },
  chevron: { color: colors.muted, fontSize: 30 },
  addText: { color: colors.text, fontSize: 18, fontWeight: '700' },
  cardRow: { flexDirection: 'row', gap: 10, marginBottom: 12 },
  moreBtn: {
    width: 56,
    borderRadius: 18,
    borderWidth: 2,
    borderColor: colors.border,
    backgroundColor: colors.panel,
    alignItems: 'center',
    justifyContent: 'center',
  },
  moreText: { color: colors.text, fontSize: 26, fontWeight: '900' },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.6)',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  overlayText: { color: colors.text, fontSize: 15, marginTop: 12 },
  sheet: {
    width: '100%',
    maxWidth: 440,
    padding: 18,
    borderRadius: 22,
    backgroundColor: colors.panelSolid,
    borderWidth: 1,
    borderColor: colors.border,
  },
  sheetTitle: { color: colors.text, fontSize: 20, fontWeight: '900', marginBottom: 12, marginLeft: 4 },
  sheetRow: {
    paddingHorizontal: 16,
    paddingVertical: 14,
    marginBottom: 8,
    borderRadius: 14,
    borderWidth: 2,
    borderColor: 'transparent',
    backgroundColor: colors.panel,
  },
  sheetCancel: { marginTop: 4, marginBottom: 0, backgroundColor: colors.panelAlt },
  sheetText: { color: colors.text, fontSize: 16, fontWeight: '700' },
  sheetLine: { flexDirection: 'row', alignItems: 'center', gap: 14 },
  managed: { color: colors.muted, fontSize: 14, marginBottom: 10, marginLeft: 4 },
  toast: {
    position: 'absolute',
    left: 24,
    right: 24,
    bottom: 40,
    padding: 14,
    borderRadius: 14,
    backgroundColor: 'rgba(17,23,38,0.97)',
    borderWidth: 1,
    borderColor: colors.border,
  },
  toastText: { color: colors.text, fontSize: 14, textAlign: 'center', fontWeight: '600' },
  hint: { color: colors.muted, fontSize: 12, textAlign: 'center', marginTop: 10 },
});
