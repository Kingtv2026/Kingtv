import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  BackHandler,
  FlatList,
  Image,
  StyleSheet,
  Text,
  TextInput,
  useWindowDimensions,
  View,
} from 'react-native';
import Icon from '../components/Icon';
import { ScreenProps, useIsFocused } from '../nav/Navigator';
import Focusable from '../components/Focusable';
import {
  getSeries,
  getSeriesCategories,
  getVodCategories,
  getVodStreams,
} from '../api/xtream';
import { colors } from '../theme';
import { useParentalGate } from '../components/PinPrompt';
import { isAdultName, isUnlocked, lock } from '../parental';
import { Category, VodItem } from '../types';

type Props = ScreenProps<'Media'>;
type Sort = 'default' | 'recent' | 'name';

const ALL = '__all__';
const SORTS: { id: Sort; label: string }[] = [
  { id: 'default', label: 'Par défaut' },
  { id: 'recent', label: 'Ajouts récents' },
  { id: 'name', label: 'Nom A-Z' },
];

export default function MediaScreen({ route, navigation }: Props) {
  const { source, kind } = route.params;
  const { width } = useWindowDimensions();
  const wide = width >= 700;
  const isMovie = kind === 'movie';
  const isFocused = useIsFocused();
  // Téléphone : d'abord la liste des catégories, puis la grille
  const [showGroups, setShowGroups] = useState(true);
  useEffect(() => {
    if (!isFocused || wide || showGroups) {
      return;
    }
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      setShowGroups(true);
      return true;
    });
    return () => sub.remove();
  }, [isFocused, wide, showGroups]);

  const [categories, setCategories] = useState<Category[] | null>(null);
  const [categoryId, setCategoryId] = useState<string | null>(null);
  const categoryRef = useRef<string | null>(null);
  categoryRef.current = categoryId;
  const [items, setItems] = useState<VodItem[] | null>(null);
  const [allItems, setAllItems] = useState<VodItem[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [sort, setSort] = useState<Sort>('default');
  const cache = useRef(new Map<string, VodItem[]>());
  // Contrôle parental : catégories de films pour adultes protégées par le code
  const { ask, prompt } = useParentalGate();
  const isAdultCat = (id: string) => isMovie && isAdultName(categories?.find(c => c.id === id)?.name);
  // Dès qu'on quitte la section adultes, on reverrouille
  useEffect(() => {
    if (!categoryId || !isAdultCat(categoryId) || (!wide && showGroups)) {
      lock();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [categoryId, categories, showGroups, wide]);
  useEffect(() => () => lock(), []);

  const openCategory = (id: string, after?: () => void) => {
    const go = () => {
      // annule un changement de groupe en attente (télécommande)
      if (catTimer.current) {
        clearTimeout(catTimer.current);
      }
      setCategoryId(id);
      after?.();
    };
    if (isAdultCat(id)) {
      ask(go);
    } else {
      go();
    }
  };
  const catTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const [allProgress, setAllProgress] = useState<{ done: number; total: number } | null>(null);
  const loadingAll = useRef<Promise<VodItem[]> | null>(null);

  const fetchCategory = async (id: string): Promise<VodItem[]> => {
    const hit = cache.current.get(id);
    if (hit) {
      return hit;
    }
    const list = isMovie ? await getVodStreams(source, id) : await getSeries(source, id);
    cache.current.set(id, list);
    return list;
  };

  /**
   * Tout le catalogue, chargé catégorie par catégorie (3 à la fois).
   * Une seule énorme requête ferait déborder la mémoire du téléphone.
   */
  const loadAll = (cats: Category[]): Promise<VodItem[]> => {
    const hit = cache.current.get(ALL);
    if (hit) {
      return Promise.resolve(hit);
    }
    if (loadingAll.current) {
      return loadingAll.current;
    }
    const real = cats.filter(c => c.id !== ALL);
    const queue = [...real];
    const found = new Map<string, VodItem>();
    let done = 0;
    setAllProgress({ done: 0, total: real.length });
    const publish = () => {
      const partial = Array.from(found.values());
      setAllItems(partial);
      if (categoryRef.current === ALL) {
        setItems(partial);
      }
    };
    const worker = async () => {
      while (queue.length) {
        const c = queue.shift()!;
        try {
          for (const it of await fetchCategory(c.id)) {
            if (!found.has(it.id)) {
              found.set(it.id, it);
            }
          }
        } catch {
          // une catégorie en erreur ne bloque pas les autres
        }
        done++;
        setAllProgress({ done, total: real.length });
        if (done % 4 === 0) {
          publish();
        }
      }
    };
    loadingAll.current = Promise.all([worker(), worker(), worker()]).then(() => {
      const all = Array.from(found.values());
      cache.current.set(ALL, all);
      publish();
      setAllProgress(null);
      return all;
    });
    return loadingAll.current;
  };

  useEffect(() => {
    navigation.setOptions({ title: isMovie ? 'Films' : 'Séries' });
    (isMovie ? getVodCategories(source) : getSeriesCategories(source))
      .then(cats => {
        setCategories([{ id: ALL, name: isMovie ? 'Tous les films' : 'Toutes les séries' }, ...cats]);
        // première catégorie qui n'est pas pour adultes
        const first = cats.find(c => !(isMovie && isAdultName(c.name)));
        setCategoryId(first ? first.id : ALL);
      })
      .catch(e => setError(e?.message || 'Chargement impossible'));
  }, [isMovie, navigation, source]);

  // Charge la catégorie choisie (petit délai pour ne pas tout charger en défilant)
  useEffect(() => {
    if (!categoryId || !categories) {
      return;
    }
    if (cache.current.has(categoryId)) {
      setItems(cache.current.get(categoryId)!);
      return;
    }
    if (categoryId === ALL) {
      setItems(allItems && allItems.length ? allItems : null);
      loadAll(categories);
      return;
    }
    setItems(null);
    let cancelled = false;
    const t = setTimeout(async () => {
      try {
        const list = await fetchCategory(categoryId);
        if (!cancelled) {
          setItems(list);
        }
      } catch (e: any) {
        if (!cancelled) {
          setError(e?.message || 'Chargement impossible');
        }
      }
    }, 350);
    return () => {
      cancelled = true;
      clearTimeout(t);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [categoryId, categories]);

  // La recherche porte sur tout le catalogue
  useEffect(() => {
    if (!search.trim() || !categories || cache.current.has(ALL)) {
      return;
    }
    loadAll(categories);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search, categories]);

  const q = search.trim().toLowerCase();
  const searching = q.length > 0;

  const shown = useMemo(() => {
    const base = searching ? allItems : items;
    if (!base) {
      return null;
    }
    let list = searching ? base.filter(i => i.name.toLowerCase().includes(q)) : base;
    if (sort === 'recent') {
      list = [...list].sort((a, b) => (b.added || 0) - (a.added || 0));
    } else if (sort === 'name') {
      list = [...list].sort((a, b) => a.name.localeCompare(b.name, 'fr', { sensitivity: 'base' }));
    }
    return list;
  }, [searching, allItems, items, q, sort]);

  // Grille : 3 colonnes sur téléphone, plus sur télé ; cartes à la bonne largeur
  // Télé : petites affiches (5 à 7 par rangée) ; téléphone : 3 colonnes
  const paneWidth = wide ? width - 246 : width - 16;
  const cols = wide ? Math.max(5, Math.floor(paneWidth / 128)) : 3;
  const cardW = Math.floor(paneWidth / cols) - 10;

  const open = (item: VodItem) => {
    if (isMovie) {
      navigation.navigate('MovieDetail', { source, item });
    } else {
      navigation.navigate('SeriesDetail', { source, item });
    }
  };

  const catName = categories?.find(c => c.id === categoryId)?.name ?? '';

  if (error) {
    return (
      <View style={styles.center}>
        <Text style={styles.error}>{error}</Text>
      </View>
    );
  }

  if (!categories) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={colors.accent} />
      </View>
    );
  }

  // ---- Téléphone : écran des catégories ----
  if (!wide && showGroups) {
    return (
      <View style={{ flex: 1 }}>
      <FlatList
        data={categories}
        keyExtractor={c => c.id}
        contentContainerStyle={{ padding: 16, paddingBottom: 30 }}
        ListHeaderComponent={
          <View style={styles.groupsHead}>
            <Text style={styles.groupsTitle}>Catégories</Text>
            <Focusable
              style={styles.iconBtn}
              onPress={() => {
                setSearchOpen(true);
                setShowGroups(false);
              }}>
              <Icon name="search" size={22} />
            </Focusable>
          </View>
        }
        renderItem={({ item, index }) => (
          <Focusable
            hasTVPreferredFocus={index === 1}
            style={styles.groupRow}
            onPress={() =>
              openCategory(item.id, () => {
                setSearch('');
                setSearchOpen(false);
                setShowGroups(false);
              })
            }>
            <Icon
              name={item.id === ALL ? (isMovie ? 'film' : 'series') : isAdultCat(item.id) ? 'lock' : 'folder'}
              size={24}
              color={isAdultCat(item.id) ? colors.danger : colors.accent}
            />
            <Text style={styles.groupName} numberOfLines={1}>
              {item.name}
            </Text>
            <Text style={styles.chev}>›</Text>
          </Focusable>
        )}
      />
      {prompt}
      </View>
    );
  }

  return (
    <View style={[styles.container, wide && { flexDirection: 'row' }]}>
      {wide && (
      <FlatList
        data={categories}
        horizontal={!wide}
        keyExtractor={c => c.id}
        style={wide ? styles.catColumn : styles.catBar}
        contentContainerStyle={!wide ? { paddingHorizontal: 12 } : undefined}
        showsHorizontalScrollIndicator={false}
        renderItem={({ item, index }) => {
          const active = item.id === categoryId && !searching;
          return (
            <Focusable
              hasTVPreferredFocus={index === (categories.length > 1 ? 1 : 0)}
              style={[wide ? styles.catRow : styles.catChip, active && styles.catActive]}
              onFocus={() => {
                if (!wide) {
                  return;
                }
                if (catTimer.current) {
                  clearTimeout(catTimer.current);
                }
                if (isAdultCat(item.id) && !isUnlocked()) {
                  return; // il faut appuyer sur OK et entrer le code
                }
                catTimer.current = setTimeout(() => setCategoryId(item.id), 350);
              }}
              onPress={() =>
                openCategory(item.id, () => {
                  setSearch('');
                  setSearchOpen(false);
                })
              }>
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                {isAdultCat(item.id) && !isUnlocked() && (
                  <Icon name="lock" size={16} color={colors.danger} style={{ marginRight: 8 }} />
                )}
                <Text
                  style={[styles.catText, active && { color: '#fff', fontWeight: '800' }, { flexShrink: 1 }]}
                  numberOfLines={1}>
                  {item.name}
                </Text>
              </View>
            </Focusable>
          );
        }}
      />
      )}

      <View style={styles.gridPane}>
        {/* Barre : titre ou recherche + loupe */}
        <View style={styles.toolbar}>
          {!wide && (
            <Focusable style={styles.backGroups} onPress={() => setShowGroups(true)}>
              <Text style={styles.backGroupsText}>‹</Text>
            </Focusable>
          )}
          {searchOpen ? (
            <TextInput
              autoFocus
              value={search}
              onChangeText={setSearch}
              placeholder={isMovie ? 'Chercher un film…' : 'Chercher une série…'}
              placeholderTextColor={colors.muted}
              style={styles.search}
              autoCorrect={false}
              returnKeyType="search"
            />
          ) : (
            <Text style={styles.paneTitle} numberOfLines={1}>
              {catName}
            </Text>
          )}
          <Focusable
            style={styles.iconBtn}
            onPress={() => {
              if (searchOpen) {
                setSearch('');
                setSearchOpen(false);
              } else {
                setSearchOpen(true);
              }
            }}>
            {searchOpen ? <Text style={styles.iconText}>✕</Text> : <Icon name="search" size={22} />}
          </Focusable>
        </View>

        {/* Tri */}
        <View style={styles.sortRow}>
          {SORTS.map(s => (
            <Focusable
              key={s.id}
              style={[styles.sortChip, sort === s.id && styles.sortActive]}
              onPress={() => setSort(s.id)}>
              <Text style={[styles.sortText, sort === s.id && { color: '#fff' }]}>{s.label}</Text>
            </Focusable>
          ))}
          {shown && (
            <Text style={styles.count}>
              {searching ? `${shown.length} résultat${shown.length > 1 ? 's' : ''}` : shown.length}
            </Text>
          )}
        </View>

        {allProgress && (searching || categoryId === ALL) && (
          <Text style={styles.progress}>
            Chargement du catalogue… {allProgress.done}/{allProgress.total} catégories
          </Text>
        )}

        {shown === null ? (
          <ActivityIndicator color={colors.accent} style={{ marginTop: 40 }} />
        ) : (
          <FlatList
            key={cols}
            data={shown}
            numColumns={cols}
            keyExtractor={i => i.id}
            initialNumToRender={cols * 3}
            maxToRenderPerBatch={cols * 2}
            windowSize={5}
            removeClippedSubviews
            contentContainerStyle={{ paddingBottom: 20 }}
            ListEmptyComponent={
              <Text style={styles.muted}>{searching ? 'Aucun résultat.' : 'Rien ici.'}</Text>
            }
            renderItem={({ item }) => (
              <Focusable style={[styles.card, { width: cardW }]} scale={1.08} onPress={() => open(item)}>
                {item.poster ? (
                  <Image
                    source={{ uri: item.poster }}
                    style={[styles.poster, { width: cardW - 8, height: (cardW - 8) * 1.5 }]}
                    resizeMode="cover"
                    resizeMethod="resize"
                    fadeDuration={0}
                  />
                ) : (
                  <View
                    style={[
                      styles.poster,
                      styles.posterEmpty,
                      { width: cardW - 8, height: (cardW - 8) * 1.5 },
                    ]}>
                    <Text style={styles.posterLetter}>{item.name.charAt(0)}</Text>
                  </View>
                )}
                {Number(item.rating) > 0 && (
                  <View style={styles.rating}>
                    <Text style={styles.ratingText}>★ {Number(item.rating).toFixed(1)}</Text>
                  </View>
                )}
                <Text style={styles.cardName} numberOfLines={2}>
                  {item.name}
                </Text>
              </Focusable>
            )}
          />
        )}
      </View>
      {prompt}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  error: { color: colors.danger, fontSize: 16, padding: 24, textAlign: 'center' },
  muted: { color: colors.muted, fontSize: 15, padding: 12 },
  catColumn: { width: 230, flexGrow: 0, paddingLeft: 12 },
  catBar: { flexGrow: 0, paddingVertical: 6 },
  catRow: {
    paddingHorizontal: 14,
    paddingVertical: 11,
    marginBottom: 4,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  catChip: {
    paddingHorizontal: 14,
    paddingVertical: 7,
    marginRight: 8,
    borderRadius: 20,
    borderWidth: 2,
    borderColor: colors.border,
    backgroundColor: colors.panel,
  },
  catActive: { backgroundColor: 'rgba(79,140,255,0.18)', borderColor: 'rgba(79,140,255,0.45)' },
  catText: { color: colors.text, fontSize: 15 },
  gridPane: { flex: 1, paddingHorizontal: 8 },
  groupsHead: { flexDirection: 'row', alignItems: 'center', marginBottom: 12, marginLeft: 4 },
  groupsTitle: { color: colors.text, fontSize: 22, fontWeight: '900', flex: 1 },
  groupRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: 14,
    paddingVertical: 14,
    marginBottom: 8,
    borderRadius: 14,
    borderWidth: 2,
    borderColor: colors.border,
    backgroundColor: colors.panel,
  },
  groupIcon: { fontSize: 20 },
  groupName: { color: colors.text, fontSize: 17, fontWeight: '700', flex: 1 },
  chev: { color: colors.muted, fontSize: 24, marginLeft: 4 },
  backGroups: {
    width: 46,
    height: 46,
    borderRadius: 23,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: 'rgba(79,140,255,0.45)',
    backgroundColor: 'rgba(79,140,255,0.18)',
  },
  backGroupsText: { color: '#fff', fontSize: 26, fontWeight: '800', marginTop: -3 },
  toolbar: { flexDirection: 'row', alignItems: 'center', gap: 10, marginHorizontal: 4, marginTop: 4 },
  paneTitle: { flex: 1, color: colors.text, fontSize: 20, fontWeight: '900' },
  search: {
    flex: 1,
    backgroundColor: colors.panel,
    color: colors.text,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: colors.focus,
    paddingHorizontal: 16,
    paddingVertical: 9,
    fontSize: 16,
  },
  iconBtn: {
    width: 46,
    height: 46,
    borderRadius: 23,
    borderWidth: 2,
    borderColor: colors.border,
    backgroundColor: colors.panel,
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconText: { fontSize: 19, color: colors.text },
  sortRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 8,
    marginHorizontal: 4,
    marginTop: 10,
    marginBottom: 6,
  },
  sortChip: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    borderWidth: 2,
    borderColor: colors.border,
    backgroundColor: colors.panel,
  },
  sortActive: { backgroundColor: colors.accent, borderColor: colors.accent },
  sortText: { color: colors.text, fontSize: 13, fontWeight: '700' },
  count: { color: colors.muted, fontSize: 12, marginLeft: 'auto' },
  progress: { color: colors.accent, fontSize: 12, marginHorizontal: 6, marginBottom: 4 },
  card: {
    margin: 5,
    padding: 2,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  poster: { borderRadius: 10 },
  posterEmpty: { backgroundColor: colors.panelAlt, alignItems: 'center', justifyContent: 'center' },
  posterLetter: { color: colors.muted, fontSize: 34, fontWeight: '900' },
  rating: {
    position: 'absolute',
    top: 8,
    right: 8,
    backgroundColor: 'rgba(0,0,0,0.72)',
    borderRadius: 8,
    paddingHorizontal: 5,
    paddingVertical: 2,
  },
  ratingText: { color: colors.star, fontSize: 11, fontWeight: '800' },
  cardName: { color: colors.text, fontSize: 12, fontWeight: '600', marginTop: 6, marginHorizontal: 2 },
});
