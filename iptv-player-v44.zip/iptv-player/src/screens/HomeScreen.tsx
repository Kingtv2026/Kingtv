/**
 * Accueil style MyTVOnline : bannière des nouveautés, Top 10, séries récentes,
 * chaînes favorites. Les onglets du bas sont ajoutés par la navigation.
 */
import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  Image,
  ScrollView,
  StyleSheet,
  Text,
  useWindowDimensions,
  View,
} from 'react-native';
import Icon from '../components/Icon';
import { recordingSupported } from '../record';
import { ScreenProps, useFocusEffect, useIsFocused } from '../nav/Navigator';
import Focusable from '../components/Focusable';
import Logo from '../components/Logo';
import { getMovieInfo, normalizeServer, xtreamLogin } from '../api/xtream';
import { loadCatalog, newest } from '../api/catalog';
import { loadPlaylist } from '../api';
import { setQueue } from '../playerQueue';
import { getFavorites } from '../storage';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { colors } from '../theme';
import { Channel, MovieInfo, VodItem } from '../types';

type Props = ScreenProps<'Home'>;

interface Hero {
  item: VodItem;
  info: MovieInfo;
}

export default function HomeScreen({ route, navigation }: Props) {
  const { source } = route.params;
  const { width } = useWindowDimensions();
  const wide = width >= 700;
  const isFocused = useIsFocused();

  const [heroes, setHeroes] = useState<Hero[] | null>(null);
  const [topMovies, setTopMovies] = useState<VodItem[] | null>(null);
  const [newSeries, setNewSeries] = useState<VodItem[] | null>(null);
  const [favChannels, setFavChannels] = useState<Channel[]>([]);
  const [progress, setProgress] = useState<string | null>(null);
  // Abonnement refusé ou serveur injoignable : message clair au lieu d'un accueil vide
  const [loginError, setLoginError] = useState<string | null>(null);
  const [loginTry, setLoginTry] = useState(0);
  useEffect(() => {
    let alive = true;
    setLoginError(null);
    const timeout = new Promise<never>((_, rej) => setTimeout(() => rej(new Error('timeout')), 15000));
    Promise.race([xtreamLogin(source), timeout])
      .then(() => {})
      .catch((e: any) => {
        if (!alive) return;
        const m = String(e?.message || '');
        setLoginError(
          /refus/i.test(m)
            ? 'Le serveur refuse le nom d’utilisateur ou le mot de passe.'
            : /^Compte/.test(m)
            ? `${m} chez le fournisseur.`
            : m === 'timeout' || /network|failed|fetch/i.test(m) || /Erreur du serveur/.test(m)
            ? 'Le serveur ne répond pas. L’adresse du serveur est peut-être incorrecte (il manque souvent le port, ex. :8080).'
            : 'Connexion impossible à l’abonnement.',
        );
      });
    return () => {
      alive = false;
    };
  }, [source, loginTry]);
  const [heroIndex, setHeroIndex] = useState(0);
  const heroList = useRef<FlatList<Hero>>(null);

  // Films et séries récents :
  // 1) instantané depuis la dernière visite, 2) mise à jour au fur et à mesure du chargement
  useEffect(() => {
    let cancelled = false;
    const key = `iptv.home.${source.id}`;
    let hadSnapshot = false;

    AsyncStorage.getItem(key)
      .then(raw => {
        if (cancelled || !raw) {
          return;
        }
        const snap = JSON.parse(raw);
        hadSnapshot = true;
        setHeroes(h => h ?? snap.heroes ?? null);
        setTopMovies(t => t ?? snap.top ?? null);
        setNewSeries(n => n ?? snap.series ?? null);
      })
      .catch(() => {});

    let seriesDone: VodItem[] | null = null;
    let finalMovies: { top: VodItem[]; heroes: Hero[] } | null = null;
    const save = () => {
      if (finalMovies && seriesDone) {
        AsyncStorage.setItem(
          key,
          JSON.stringify({ at: Date.now(), heroes: finalMovies.heroes, top: finalMovies.top, series: seriesDone }),
        ).catch(() => {});
      }
    };

    loadCatalog(source, 'movie', (d, t, partial) => {
      if (cancelled) {
        return;
      }
      setProgress(`${d}/${t}`);
      // Pas d'instantané : on montre déjà ce qui est chargé
      if (!hadSnapshot && partial.length) {
        const top = newest(partial, 10);
        setTopMovies(top);
        setHeroes(top.slice(0, 5).map(item => ({ item, info: {} })));
      }
    })
      .then(async movies => {
        if (cancelled) {
          return;
        }
        setProgress(null);
        const top = newest(movies, 10);
        setTopMovies(top);
        const five = top.slice(0, 5);
        const infos = await Promise.all(five.map(m => getMovieInfo(source, m.id).catch(() => ({}))));
        if (cancelled) {
          return;
        }
        const hs = five.map((item, i) => ({ item, info: infos[i] as MovieInfo }));
        setHeroes(hs);
        finalMovies = { top, heroes: hs };
        save();
      })
      .catch(() => {
        if (!cancelled) {
          setTopMovies(t => t ?? []);
          setHeroes(h => h ?? []);
        }
      });

    loadCatalog(source, 'series', (_d, _t, partial) => {
      if (!cancelled && !hadSnapshot && partial.length) {
        setNewSeries(newest(partial, 12));
      }
    })
      .then(series => {
        if (cancelled) {
          return;
        }
        seriesDone = newest(series, 12);
        setNewSeries(seriesDone);
        save();
      })
      .catch(() => !cancelled && setNewSeries(n => n ?? []));
    return () => {
      cancelled = true;
    };
  }, [source]);

  // Chaînes favorites (rechargées au retour sur l'accueil)
  useFocusEffect(
    useCallback(() => {
      Promise.all([loadPlaylist(source), getFavorites(source.id)])
        .then(([pl, favs]) => setFavChannels(pl.channels.filter(c => favs.includes(c.id))))
        .catch(() => {});
    }, [source]),
  );

  // Bannière qui défile toute seule
  const heroW = width - 32;
  useEffect(() => {
    if (!isFocused || !heroes || heroes.length < 2) {
      return;
    }
    const t = setInterval(() => {
      setHeroIndex(i => {
        const next = (i + 1) % heroes.length;
        heroList.current?.scrollToOffset({ offset: next * heroW, animated: true });
        return next;
      });
    }, 7000);
    return () => clearInterval(t);
  }, [isFocused, heroes, heroW]);

  const openMovie = (item: VodItem) => navigation.navigate('MovieDetail', { source, item });
  const openSeries = (item: VodItem) => navigation.navigate('SeriesDetail', { source, item });
  const playMovie = (item: VodItem) =>
    item.url && navigation.navigate('Player', { vod: { url: item.url, title: item.name } });
  const playFav = (index: number) => {
    setQueue(favChannels, source);
    navigation.navigate('Player', { index });
  };

  const heroH = wide ? 340 : Math.round(heroW * 0.62);
  const posterW = wide ? 150 : 118;

  return (
    <View style={{ flex: 1 }}>
      {/* En-tête */}
      <View style={styles.header}>
        <Logo size={wide ? 30 : 26} />
        <View style={{ flex: 1 }} />
        {progress && heroes && heroes.length > 0 && (
          <Text style={styles.updating}>↻ {progress}</Text>
        )}
        <Focusable style={styles.iconBtn} onPress={() => navigation.popToTop()}>
          <Icon name="list" size={24} />
        </Focusable>
        {recordingSupported && (
          <Focusable style={styles.iconBtn} onPress={() => navigation.navigate('Recordings')}>
            <Icon name="record" size={24} />
          </Focusable>
        )}
        <Focusable style={styles.iconBtn} onPress={() => navigation.navigate('Search', { source })}>
          <Icon name="search" size={24} />
        </Focusable>
        <Focusable style={styles.iconBtn} onPress={() => navigation.navigate('Settings', { source })}>
          <Icon name="settings" size={24} />
        </Focusable>
      </View>

      <ScrollView contentContainerStyle={{ paddingBottom: 24 }}>
        {!!loginError && (
          <View style={styles.loginErr}>
            <Text style={styles.loginErrTitle}>Impossible de se connecter à « {source.name} »</Text>
            <Text style={styles.loginErrText}>{loginError}</Text>
            <Text style={styles.loginErrServer}>Serveur : {normalizeServer(source.server)} · Utilisateur : {source.username}</Text>
            <View style={{ flexDirection: 'row', gap: 10, marginTop: 12 }}>
              <Focusable hasTVPreferredFocus style={styles.loginErrBtn} onPress={() => setLoginTry(t => t + 1)}>
                <Text style={styles.loginErrBtnText}>Réessayer</Text>
              </Focusable>
              <Focusable
                style={styles.loginErrBtn}
                onPress={() => navigation.navigate('AddSource', { edit: source, reopen: true })}>
                <Text style={styles.loginErrBtnText}>Modifier les informations</Text>
              </Focusable>
              <Focusable style={styles.loginErrBtn} onPress={() => navigation.popToTop()}>
                <Text style={styles.loginErrBtnText}>Mes listes</Text>
              </Focusable>
            </View>
          </View>
        )}
        {/* Bannière */}
        {heroes === null ? (
          <View style={[styles.heroSkeleton, { height: heroH }]}>
            <ActivityIndicator color={colors.accent} />
            <Text style={styles.muted}>
              Chargement des nouveautés{progress ? ` · ${progress} catégories` : '…'}
            </Text>
          </View>
        ) : heroes.length > 0 ? (
          <View>
            <FlatList
              ref={heroList}
              data={heroes}
              horizontal
              pagingEnabled
              snapToInterval={heroW}
              decelerationRate="fast"
              showsHorizontalScrollIndicator={false}
              keyExtractor={h => h.item.id}
              contentContainerStyle={{ paddingHorizontal: 16 }}
              onMomentumScrollEnd={e => setHeroIndex(Math.round(e.nativeEvent.contentOffset.x / heroW))}
              renderItem={({ item: h, index }) => {
                const img = h.info.backdrop || h.info.poster || h.item.poster;
                const rating = Number(h.info.rating || h.item.rating);
                return (
                  <Focusable
                    hasTVPreferredFocus={index === 0}
                    style={[styles.hero, { width: heroW - 8, height: heroH, marginRight: 8 }]}
                    onFocus={() => setHeroIndex(index)}
                    onPress={() => openMovie(h.item)}>
                    {img ? (
                      <Image source={{ uri: img }} style={StyleSheet.absoluteFill} resizeMode="cover" />
                    ) : null}
                    <View style={styles.heroFade} pointerEvents="none">
                      {[0, 0.25, 0.5, 0.72, 0.88].map((o, i) => (
                        <View key={i} style={{ flex: 1, backgroundColor: '#070a12', opacity: o }} />
                      ))}
                    </View>
                    <View style={styles.heroBadge}>
                      <Text style={styles.heroBadgeText}>NOUVEAU</Text>
                    </View>
                    <View style={styles.heroText}>
                      <Text style={[styles.heroTitle, wide && { fontSize: 32 }]} numberOfLines={2}>
                        {h.item.name}
                      </Text>
                      <Text style={styles.heroMeta} numberOfLines={1}>
                        {[rating > 0 ? `★ ${rating.toFixed(1)}` : null, h.info.year, h.info.genre]
                          .filter(Boolean)
                          .join('   ·   ')}
                      </Text>
                      <View style={styles.heroButtons}>
                        <Focusable style={styles.playBtn} onPress={() => playMovie(h.item)}>
                          <View style={styles.btnRow}>
                            <Icon name="play" size={14} color="#fff" />
                            <Text style={styles.playText}>Regarder</Text>
                          </View>
                        </Focusable>
                        <Focusable style={styles.infoBtn} onPress={() => openMovie(h.item)}>
                          <View style={styles.btnRow}>
                            <Icon name="info" size={16} color="#fff" />
                            <Text style={styles.playText}>Infos</Text>
                          </View>
                        </Focusable>
                      </View>
                    </View>
                  </Focusable>
                );
              }}
            />
            <View style={styles.dots}>
              {heroes.map((_, i) => (
                <View key={i} style={[styles.dotSmall, i === heroIndex && styles.dotOn]} />
              ))}
            </View>
          </View>
        ) : null}

        {/* Top 10 */}
        <SectionTitle
          title="Top 10 des nouveaux films"
          onMore={() => navigation.navigate('Media', { source, kind: 'movie' })}
        />
        {topMovies === null ? (
          <ActivityIndicator color={colors.accent} style={{ marginVertical: 30 }} />
        ) : (
          <FlatList
            horizontal
            data={topMovies}
            keyExtractor={m => m.id}
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ paddingHorizontal: 16 }}
            renderItem={({ item, index }) => (
              <View style={styles.rankItem}>
                <Text style={[styles.rankNum, wide && { fontSize: 110, lineHeight: 120 }]}>{index + 1}</Text>
                <Focusable scale={1.06} style={[styles.posterCard, { width: posterW }]} onPress={() => openMovie(item)}>
                  <PosterImage uri={item.poster} name={item.name} w={posterW - 6} />
                  <Text style={styles.cardTitle} numberOfLines={1}>
                    {item.name}
                  </Text>
                  {Number(item.rating) > 0 && (
                    <Text style={styles.cardSub}>★ {Number(item.rating).toFixed(1)}</Text>
                  )}
                </Focusable>
              </View>
            )}
          />
        )}

        {/* Séries récentes */}
        <SectionTitle
          title="Nouvelles séries"
          onMore={() => navigation.navigate('Media', { source, kind: 'series' })}
        />
        {newSeries === null ? (
          <ActivityIndicator color={colors.accent} style={{ marginVertical: 30 }} />
        ) : (
          <FlatList
            horizontal
            data={newSeries}
            keyExtractor={m => m.id}
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ paddingHorizontal: 16 }}
            renderItem={({ item }) => (
              <Focusable scale={1.06} style={[styles.posterCard, { width: posterW, marginRight: 10 }]} onPress={() => openSeries(item)}>
                <PosterImage uri={item.poster} name={item.name} w={posterW - 6} />
                <Text style={styles.cardTitle} numberOfLines={1}>
                  {item.name}
                </Text>
              </Focusable>
            )}
          />
        )}

        {/* Favoris */}
        <SectionTitle
          title="Tes chaînes favorites"
          onMore={() => navigation.navigate('Guide', { source })}
          moreLabel="Guide TV ›"
        />
        {favChannels.length === 0 ? (
          <Text style={[styles.muted, { marginHorizontal: 20 }]}>
            Aucun favori pour l’instant. Dans Direct, fais un appui long sur une chaîne pour l’ajouter.
          </Text>
        ) : (
          <FlatList
            horizontal
            data={favChannels}
            keyExtractor={c => c.id}
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ paddingHorizontal: 16 }}
            renderItem={({ item, index }) => (
              <Focusable scale={1.06} style={styles.favCard} onPress={() => playFav(index)}>
                <View style={styles.favLogoBox}>
                  {item.logo ? (
                    <Image source={{ uri: item.logo }} style={styles.favLogo} resizeMode="contain" />
                  ) : (
                    <Text style={styles.favLetter}>{item.name.charAt(0)}</Text>
                  )}
                </View>
                <Text style={styles.favName} numberOfLines={1}>
                  {item.name}
                </Text>
              </Focusable>
            )}
          />
        )}
      </ScrollView>
    </View>
  );
}

function SectionTitle({
  title,
  onMore,
  moreLabel = 'Voir tout ›',
}: {
  title: string;
  onMore?: () => void;
  moreLabel?: string;
}) {
  return (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>{title}</Text>
      {onMore && (
        <Focusable style={styles.moreBtn} onPress={onMore}>
          <Text style={styles.moreText}>{moreLabel}</Text>
        </Focusable>
      )}
    </View>
  );
}

function PosterImage({ uri, name, w }: { uri?: string; name: string; w: number }) {
  const h = Math.round(w * 1.5);
  return uri ? (
    <Image source={{ uri }} style={[styles.poster, { width: w, height: h }]} resizeMode="cover" />
  ) : (
    <View style={[styles.poster, styles.posterEmpty, { width: w, height: h }]}>
      <Text style={styles.posterLetter}>{name.charAt(0)}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  loginErr: {
    margin: 16,
    padding: 18,
    borderRadius: 18,
    backgroundColor: 'rgba(255,84,112,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(255,84,112,0.5)',
  },
  loginErrTitle: { color: '#fff', fontSize: 18, fontWeight: '900' },
  loginErrText: { color: colors.text, fontSize: 15, marginTop: 6, lineHeight: 21 },
  loginErrServer: { color: colors.muted, fontSize: 13, marginTop: 8 },
  loginErrBtn: {
    paddingHorizontal: 18,
    paddingVertical: 10,
    borderRadius: 12,
    backgroundColor: colors.panelAlt,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  loginErrBtnText: { color: '#fff', fontSize: 15, fontWeight: '800' },
  header: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 20, paddingVertical: 12 },
  iconBtn: {
    width: 46,
    height: 46,
    borderRadius: 23,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: 'transparent',
  },
  iconText: { fontSize: 22 },
  muted: { color: colors.muted, fontSize: 14, marginTop: 8 },
  updating: { color: colors.muted, fontSize: 12, fontWeight: '700' },

  heroSkeleton: {
    marginHorizontal: 16,
    borderRadius: 20,
    backgroundColor: colors.panel,
    alignItems: 'center',
    justifyContent: 'center',
  },
  hero: {
    borderRadius: 20,
    overflow: 'hidden',
    backgroundColor: colors.panelSolid,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  heroFade: { position: 'absolute', left: 0, right: 0, bottom: 0, height: '70%' },
  heroBadge: {
    position: 'absolute',
    top: 14,
    left: 14,
    backgroundColor: colors.live,
    borderRadius: 6,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  heroBadgeText: { color: '#fff', fontSize: 11, fontWeight: '900', letterSpacing: 1 },
  heroText: { position: 'absolute', left: 18, right: 18, bottom: 16 },
  heroTitle: { color: '#fff', fontSize: 24, fontWeight: '900' },
  heroMeta: { color: 'rgba(244,246,251,0.85)', fontSize: 13, marginTop: 4 },
  heroButtons: { flexDirection: 'row', gap: 10, marginTop: 12 },
  playBtn: {
    paddingHorizontal: 18,
    paddingVertical: 9,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: colors.accent,
    backgroundColor: colors.accent,
  },
  infoBtn: {
    paddingHorizontal: 16,
    paddingVertical: 9,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.2)',
    backgroundColor: 'rgba(255,255,255,0.15)',
  },
  playText: { color: '#fff', fontSize: 14, fontWeight: '800' },
  btnRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  dots: { flexDirection: 'row', justifyContent: 'center', gap: 6, marginTop: 10 },
  dotSmall: { width: 6, height: 6, borderRadius: 3, backgroundColor: 'rgba(255,255,255,0.25)' },
  dotOn: { width: 18, backgroundColor: colors.accent },

  section: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginTop: 26,
    marginBottom: 10,
  },
  sectionTitle: { color: colors.text, fontSize: 21, fontWeight: '900', flex: 1 },
  moreBtn: {
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  moreText: { color: colors.cyan, fontSize: 14, fontWeight: '800' },

  rankItem: { flexDirection: 'row', alignItems: 'flex-start', marginRight: 6 },
  rankNum: {
    fontSize: 86,
    lineHeight: 96,
    fontWeight: '900',
    color: colors.bg,
    textShadowColor: 'rgba(255,255,255,0.95)',
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 3,
    marginRight: -12,
    marginTop: -4,
    fontStyle: 'italic',
  },
  posterCard: { padding: 3, borderRadius: 14, borderWidth: 2, borderColor: 'transparent' },
  poster: { borderRadius: 10 },
  posterEmpty: { backgroundColor: colors.panelAlt, alignItems: 'center', justifyContent: 'center' },
  posterLetter: { color: colors.muted, fontSize: 34, fontWeight: '900' },
  cardTitle: { color: colors.text, fontSize: 14, fontWeight: '800', marginTop: 7 },
  cardSub: { color: colors.star, fontSize: 12, fontWeight: '700', marginTop: 2 },

  favCard: {
    width: 120,
    marginRight: 10,
    padding: 4,
    borderRadius: 14,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  favLogoBox: {
    height: 74,
    borderRadius: 12,
    backgroundColor: colors.panel,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  favLogo: { width: '78%', height: '78%' },
  favLetter: { color: colors.muted, fontSize: 26, fontWeight: '900' },
  favName: { color: colors.text, fontSize: 12, fontWeight: '700', marginTop: 6, textAlign: 'center' },
});
