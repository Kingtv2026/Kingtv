/** Recherche globale : chaînes, films et séries. */
import React, { useEffect, useMemo, useState } from 'react';
import { FlatList, Image, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { ScreenProps } from '../nav/Navigator';
import Focusable from '../components/Focusable';
import { loadPlaylist } from '../api';
import { loadCatalog } from '../api/catalog';
import { setQueue } from '../playerQueue';
import { colors } from '../theme';
import { Channel, VodItem } from '../types';

type Props = ScreenProps<'Search'>;

const MAX = 30;

export default function SearchScreen({ route, navigation }: Props) {
  const { source } = route.params;
  const [q, setQ] = useState('');
  const [channels, setChannels] = useState<Channel[]>([]);
  const [movies, setMovies] = useState<VodItem[] | null>(null);
  const [series, setSeries] = useState<VodItem[] | null>(null);
  const [progress, setProgress] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    loadPlaylist(source).then(pl => !cancelled && setChannels(pl.channels)).catch(() => {});
    loadCatalog(source, 'movie', (d, t) => !cancelled && setProgress(`${d}/${t}`))
      .then(m => {
        if (!cancelled) {
          setMovies(m);
          setProgress(null);
        }
      })
      .catch(() => !cancelled && setMovies([]));
    loadCatalog(source, 'series')
      .then(s => !cancelled && setSeries(s))
      .catch(() => !cancelled && setSeries([]));
    return () => {
      cancelled = true;
    };
  }, [source]);

  const needle = q.trim().toLowerCase();
  const active = needle.length >= 2;
  const match = (name: string) => name.toLowerCase().includes(needle);

  const chRes = useMemo(() => (active ? channels.filter(c => match(c.name)).slice(0, MAX) : []), [active, channels, needle]);
  const mvRes = useMemo(() => (active && movies ? movies.filter(m => match(m.name)).slice(0, MAX) : []), [active, movies, needle]);
  const srRes = useMemo(() => (active && series ? series.filter(m => match(m.name)).slice(0, MAX) : []), [active, series, needle]);

  return (
    <View style={{ flex: 1 }}>
      <TextInput
        autoFocus
        value={q}
        onChangeText={setQ}
        placeholder="Chaîne, film ou série…"
        placeholderTextColor={colors.muted}
        style={styles.input}
        autoCorrect={false}
        returnKeyType="search"
      />
      {progress && <Text style={styles.progress}>Chargement du catalogue… {progress} catégories</Text>}

      <ScrollView contentContainerStyle={{ paddingBottom: 30 }} keyboardShouldPersistTaps="handled">
        {!active && <Text style={styles.hint}>Tape au moins 2 lettres.</Text>}

        {active && chRes.length > 0 && (
          <>
            <Text style={styles.section}>Chaînes ({chRes.length})</Text>
            {chRes.map((c, i) => (
              <Focusable
                key={c.id}
                style={styles.chRow}
                onPress={() => {
                  setQueue(chRes, source);
                  navigation.navigate('Player', { index: i });
                }}>
                <View style={styles.logoBox}>
                  {c.logo ? <Image source={{ uri: c.logo }} style={styles.logo} resizeMode="contain" /> : null}
                </View>
                <Text style={styles.chName} numberOfLines={1}>
                  {c.name}
                </Text>
              </Focusable>
            ))}
          </>
        )}

        {active && mvRes.length > 0 && (
          <PosterRow
            title={`Films (${mvRes.length})`}
            items={mvRes}
            onPress={item => navigation.navigate('MovieDetail', { source, item })}
          />
        )}
        {active && srRes.length > 0 && (
          <PosterRow
            title={`Séries (${srRes.length})`}
            items={srRes}
            onPress={item => navigation.navigate('SeriesDetail', { source, item })}
          />
        )}

        {active && chRes.length + mvRes.length + srRes.length === 0 && (
          <Text style={styles.hint}>{movies && series ? 'Aucun résultat.' : 'Recherche en cours…'}</Text>
        )}
      </ScrollView>
    </View>
  );
}

function PosterRow({ title, items, onPress }: { title: string; items: VodItem[]; onPress: (i: VodItem) => void }) {
  return (
    <>
      <Text style={styles.section}>{title}</Text>
      <FlatList
        horizontal
        data={items}
        keyExtractor={i => i.id}
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={{ paddingHorizontal: 12 }}
        renderItem={({ item }) => (
          <Focusable scale={1.06} style={styles.card} onPress={() => onPress(item)}>
            {item.poster ? (
              <Image source={{ uri: item.poster }} style={styles.poster} resizeMode="cover" />
            ) : (
              <View style={[styles.poster, { backgroundColor: colors.panelAlt }]} />
            )}
            <Text style={styles.cardTitle} numberOfLines={2}>
              {item.name}
            </Text>
          </Focusable>
        )}
      />
    </>
  );
}

const styles = StyleSheet.create({
  input: {
    marginHorizontal: 16,
    marginTop: 4,
    backgroundColor: colors.panel,
    color: colors.text,
    borderRadius: 16,
    borderWidth: 2,
    borderColor: colors.focus,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 17,
  },
  progress: { color: colors.accent, fontSize: 12, marginHorizontal: 20, marginTop: 8 },
  hint: { color: colors.muted, fontSize: 15, textAlign: 'center', marginTop: 40 },
  section: { color: colors.text, fontSize: 18, fontWeight: '900', marginHorizontal: 20, marginTop: 22, marginBottom: 10 },
  chRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginHorizontal: 16,
    marginBottom: 6,
    padding: 10,
    borderRadius: 14,
    borderWidth: 2,
    borderColor: 'transparent',
    backgroundColor: colors.panel,
  },
  logoBox: {
    width: 56,
    height: 38,
    borderRadius: 8,
    backgroundColor: 'rgba(255,255,255,0.07)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  logo: { width: '86%', height: '86%' },
  chName: { color: colors.text, fontSize: 15, fontWeight: '700', flex: 1 },
  card: { width: 116, marginRight: 8, padding: 3, borderRadius: 12, borderWidth: 2, borderColor: 'transparent' },
  poster: { width: 106, height: 159, borderRadius: 10 },
  cardTitle: { color: colors.text, fontSize: 12, fontWeight: '700', marginTop: 6 },
});
