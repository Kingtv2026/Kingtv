/**
 * Liste des chaînes par-dessus le direct (télé), comme MyTVOnline 4 :
 * OK pendant le visionnement = la liste du groupe à gauche, la chaîne qui joue
 * en petit en haut à droite avec son guide. ← = panneau des groupes.
 * OK sur une autre chaîne = elle joue dans la petite fenêtre ; OK sur celle qui
 * joue = retour en plein écran.
 */
import React, { memo, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { BackHandler, FlatList, Image, StyleSheet, Text, useTVEventHandler, View } from 'react-native';
import Focusable from './Focusable';
import FocusTrap from './FocusTrap';
import Icon, { IconName } from './Icon';
import Clock from './Clock';
import { useParentalGate } from './PinPrompt';
import { isAdultName } from '../parental';
import { loadPlaylist } from '../api';
import { formatTime, getNowNext, progressOf, watchPrograms } from '../api/epg';
import { getFavorites } from '../storage';
import { colors } from '../theme';
import { CAT_ALL, CAT_FAVORITES, Category, Channel, Program, Source } from '../types';

const ROW = 64;
const DROW = 44;

const Row = memo(function Row({
  item,
  index,
  source,
  playing,
  preferred,
  onPress,
}: {
  item: Channel;
  index: number;
  source: Source;
  playing: boolean;
  preferred: boolean;
  onPress: (i: number) => void;
}) {
  const [now, setNow] = useState<Program | null>(null);
  useEffect(() => {
    let alive = true;
    const t = setTimeout(() => {
      getNowNext(source, item)
        .then(l => alive && setNow(l.find(p => p.start <= Date.now() && p.end > Date.now()) || null))
        .catch(() => {});
    }, 400);
    return () => {
      alive = false;
      clearTimeout(t);
    };
  }, [source, item]);
  return (
    <Focusable
      hasTVPreferredFocus={preferred}
      style={styles.row}
      focusedStyle={styles.rowFocused}
      onPress={() => onPress(index)}>
      <Text style={styles.num}>{index + 1}</Text>
      <View style={styles.logoBox}>
        {item.logo ? (
          <Image source={{ uri: item.logo }} style={styles.logo} resizeMode="contain" resizeMethod="resize" fadeDuration={0} />
        ) : (
          <Text style={styles.logoLetter}>{item.name.charAt(0)}</Text>
        )}
      </View>
      <View style={{ flex: 1 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <Text style={[styles.name, playing && { color: '#ff9f43' }]} numberOfLines={1}>
            {item.name}
          </Text>
          {!!item.archiveDays && <Icon name="refresh" size={14} color={colors.muted} />}
        </View>
        <View style={styles.nowLine}>
          {now && (
            <>
              <View style={styles.track}>
                <View style={[styles.fill, { width: `${progressOf(now) * 100}%` }]} />
              </View>
              <Text style={styles.nowText} numberOfLines={1}>
                {now.title}
              </Text>
            </>
          )}
        </View>
      </View>
    </Focusable>
  );
});

/** Guide de la chaîne qui joue (sous la petite fenêtre). */
function PlayingInfo({ source, channel }: { source: Source; channel: Channel }) {
  const [progs, setProgs] = useState<Program[]>([]);
  useEffect(() => {
    setProgs([]);
    return watchPrograms(source, channel, setProgs);
  }, [source, channel]);
  const t = Date.now();
  const upcoming = progs.filter(p => p.end > t).slice(0, 4);
  const now = upcoming[0] && upcoming[0].start <= t ? upcoming[0] : null;
  const next = upcoming.filter(p => p !== now).slice(0, 3);
  return (
    <View style={styles.info}>
      <Text style={styles.infoName} numberOfLines={1}>
        {channel.name}
      </Text>
      {now ? (
        <>
          <Text style={styles.infoNow} numberOfLines={1}>
            <Text style={{ color: colors.muted }}>
              {formatTime(now.start)} - {formatTime(now.end)}{'  '}
            </Text>
            {now.title}
          </Text>
          <View style={styles.infoTrack}>
            <View style={[styles.infoFill, { width: `${progressOf(now) * 100}%` }]} />
          </View>
          {!!now.description && (
            <Text style={styles.infoDesc} numberOfLines={3}>
              {now.description}
            </Text>
          )}
        </>
      ) : (
        <Text style={styles.infoDesc}>Pas d’horaire pour cette chaîne.</Text>
      )}
      {next.map(p => (
        <Text key={p.start} style={styles.infoNext} numberOfLines={1}>
          <Text style={styles.infoNextTime}>{formatTime(p.start)}{'   '}</Text>
          {p.title}
        </Text>
      ))}
    </View>
  );
}

/** Si la liste plante, on la ferme au lieu de fermer toute l'application. */
export class OverlayGuard extends React.Component<{ onError: () => void; children?: React.ReactNode }, { bad: boolean }> {
  state = { bad: false };
  static getDerivedStateFromError() {
    return { bad: true };
  }
  componentDidCatch() {
    this.props.onError();
  }
  render() {
    return this.state.bad ? null : this.props.children;
  }
}

export default function LiveOverlay({
  source,
  queue,
  queueName,
  playing,
  onPlay,
  onClose,
}: {
  source: Source;
  queue: Channel[];
  queueName: string;
  playing: Channel;
  onPlay: (list: Channel[], index: number, name: string) => void;
  onClose: () => void;
}) {
  // Groupe affiché (peut être différent de celui qui joue tant qu'on n'a pas choisi)
  const [list, setList] = useState<{ name: string; channels: Channel[] }>({ name: queueName, channels: queue });
  const [drawer, setDrawer] = useState(false);
  const [listKey, setListKey] = useState(0);
  const [cats, setCats] = useState<Category[] | null>(null);
  const [allCh, setAllCh] = useState<Channel[]>([]);
  const { ask, prompt } = useParentalGate();

  useEffect(() => {
    loadPlaylist(source)
      .then(p => {
        setAllCh(p.channels);
        setCats(p.categories);
      })
      .catch(() => {});
  }, [source]);

  // Retour : ferme le panneau des groupes, sinon la liste
  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (drawer) setDrawer(false);
      else onClose();
      return true;
    });
    return () => sub.remove();
  }, [drawer, onClose]);

  // ← depuis la liste : panneau des groupes
  const lastLeft = useRef(0);
  useTVEventHandler(evt => {
    if (!evt || drawer) return;
    if (evt.eventType === 'left' && Date.now() - lastLeft.current > 300) {
      lastLeft.current = Date.now();
      setDrawer(true);
    }
  });

  const playingIdx = list.channels.findIndex(c => c.id === playing.id);
  const focusIdx = useRef(Math.max(0, playingIdx));

  const onPress = useCallback(
    (i: number) => {
      const c = list.channels[i];
      if (!c) return;
      if (c.id === playing.id) onClose();
      else onPlay(list.channels, i, list.name);
    },
    [list, playing.id, onPlay, onClose],
  );

  const openGroup = async (id: string, name: string) => {
    const go = async () => {
      let chans: Channel[];
      if (id === CAT_ALL) chans = allCh;
      else if (id === CAT_FAVORITES) {
        const fav = new Set(await getFavorites(source.id));
        chans = allCh.filter(c => fav.has(c.id));
      } else chans = allCh.filter(c => c.categoryId === id);
      focusIdx.current = Math.max(0, chans.findIndex(c => c.id === playing.id));
      setList({ name, channels: chans });
      setListKey(k => k + 1);
      setDrawer(false);
    };
    if (cats?.find(c => c.id === id && isAdultName(c.name))) ask(go);
    else go();
  };

  const rows = useMemo(() => {
    const mine: { key: string; label?: string; id?: string; name?: string; icon?: IconName }[] = [
      { key: 'h1', label: 'Mes groupes' },
      { key: CAT_ALL, id: CAT_ALL, name: 'Toutes les chaînes', icon: 'tv' },
      { key: CAT_FAVORITES, id: CAT_FAVORITES, name: 'Favoris', icon: 'star' },
      { key: 'h2', label: (source as any).name || 'Groupes' },
    ];
    return [...mine, ...(cats || []).map(c => ({ key: c.id, id: c.id, name: c.name }))];
  }, [cats, source]);

  return (
    <View style={styles.wrap}>
      {/* Fond : la liste à gauche sur un fond bleu ; la chaîne continue de jouer à droite */}
      <View style={styles.bgLeft} />
      <View style={styles.bgEdge} />

      {/* Liste des chaînes */}
      {/* cachée pendant que le panneau des groupes est ouvert (un seul menu à la fois) */}
      {!drawer && (
      <View style={styles.listCol}>
        <Text style={styles.header} numberOfLines={1}>
          ‹  Groupe : {list.name} ({list.channels.length})
        </Text>
        <FocusTrap style={{ flex: 1 }}>
          <FlatList
            key={listKey}
            data={list.channels}
            keyExtractor={c => c.id}
            getItemLayout={(_, i) => ({ length: ROW, offset: ROW * i, index: i })}
            initialScrollIndex={Math.max(0, focusIdx.current - 2)}
            initialNumToRender={12}
            maxToRenderPerBatch={8}
            windowSize={5}
            renderItem={({ item, index }) => (
              <Row
                item={item}
                index={index}
                source={source}
                playing={item.id === playing.id}
                preferred={!drawer && index === focusIdx.current}
                onPress={onPress}
              />
            )}
            ListEmptyComponent={<Text style={styles.empty}>Aucune chaîne dans ce groupe.</Text>}
          />
        </FocusTrap>
      </View>
      )}

      {/* Guide de la chaîne qui joue (en bas à droite, par-dessus l'image) */}
      <View style={styles.infoCol}>
        <PlayingInfo source={source} channel={playing} />
        <Text style={styles.legendText}>←  Groupes   ·   OK sur la chaîne qui joue = plein écran</Text>
      </View>
      <View style={styles.clock}>
        <Clock compact />
      </View>

      {/* Panneau des groupes */}
      {drawer && (
        <View style={styles.drawerWrap}>
          <FocusTrap style={styles.drawer}>
            <Text style={styles.provider} numberOfLines={1}>
              Fournisseur : <Text style={{ color: '#fff', fontWeight: '900' }}>{(source as any).name}</Text>
            </Text>
            <FlatList
              data={rows}
              keyExtractor={r => r.key}
              getItemLayout={(_, i) => ({ length: DROW, offset: DROW * i, index: i })}
              initialScrollIndex={Math.max(0, rows.findIndex(r => r.name === list.name) - 3)}
              initialNumToRender={rows.length}
              maxToRenderPerBatch={rows.length}
              windowSize={101}
              removeClippedSubviews={false}
              renderItem={({ item: r }) => {
                if (!r.id) {
                  return (
                    <View style={styles.sectionRow}>
                      <Text style={styles.sectionText}>{r.label}</Text>
                      <View style={styles.sectionLine} />
                    </View>
                  );
                }
                const active = r.name === list.name;
                return (
                  <Focusable
                    hasTVPreferredFocus={active}
                    style={[styles.dRow, active && styles.dActive]}
                    focusedStyle={styles.rowFocused}
                    onPress={() => openGroup(r.id!, r.name!)}>
                    {!!r.icon && <Icon name={r.icon} size={16} color={active ? '#1a2350' : '#fff'} />}
                    <Text style={[styles.dText, active && styles.dTextActive]} numberOfLines={1}>
                      {r.name}
                    </Text>
                  </Focusable>
                );
              }}
            />
          </FocusTrap>
        </View>
      )}
      {prompt}
    </View>
  );
}

const BG = 'rgba(20,26,92,0.96)';

const styles = StyleSheet.create({
  wrap: { ...StyleSheet.absoluteFillObject, zIndex: 20 },
  bgLeft: { position: 'absolute', left: 0, top: 0, bottom: 0, width: '55%', backgroundColor: BG },
  bgEdge: { position: 'absolute', left: '55%', top: 0, bottom: 0, width: 40, backgroundColor: BG, opacity: 0.5 },

  listCol: { position: 'absolute', left: 24, top: 12, bottom: 12, width: '52%' },
  header: { color: 'rgba(235,240,255,0.85)', fontSize: 14, fontWeight: '800', marginBottom: 8, marginLeft: 6 },
  row: {
    height: ROW - 6,
    marginBottom: 6,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    borderRadius: 14,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  rowFocused: { backgroundColor: 'rgba(127,176,255,0.30)', borderColor: '#ffffff' },
  num: { color: colors.text, fontSize: 15, fontWeight: '800', width: 40 },
  logoBox: { width: 60, height: 40, alignItems: 'center', justifyContent: 'center', marginRight: 14 },
  logo: { width: '88%', height: '88%' },
  logoLetter: { color: colors.muted, fontSize: 18, fontWeight: '900' },
  name: { color: colors.text, fontSize: 16, fontWeight: '800', flexShrink: 1 },
  nowLine: { flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 4, minHeight: 18 },
  track: { width: 46, height: 4, borderRadius: 2, backgroundColor: 'rgba(255,255,255,0.18)', overflow: 'hidden' },
  fill: { height: '100%', backgroundColor: '#e8ebf1' },
  nowText: { color: 'rgba(200,215,255,0.9)', fontSize: 13, flex: 1 },
  empty: { color: colors.muted, fontSize: 15, padding: 16 },

  infoCol: {
    position: 'absolute',
    right: 24,
    bottom: 24,
    width: '38%',
    backgroundColor: 'rgba(10,14,40,0.88)',
    borderRadius: 16,
    padding: 16,
  },
  info: {},
  infoName: { color: '#fff', fontSize: 20, fontWeight: '900' },
  infoNow: { color: '#fff', fontSize: 14, fontWeight: '700', marginTop: 4 },
  infoTrack: { height: 4, borderRadius: 2, backgroundColor: 'rgba(255,255,255,0.2)', marginTop: 8, overflow: 'hidden' },
  infoFill: { height: '100%', backgroundColor: '#e8ebf1' },
  infoDesc: { color: 'rgba(220,228,255,0.85)', fontSize: 13, lineHeight: 18, marginTop: 8 },
  infoNext: { color: 'rgba(235,240,255,0.9)', fontSize: 13, fontWeight: '700', marginTop: 6 },
  infoNextTime: { color: colors.muted, fontWeight: '600' },
  clock: {
    position: 'absolute',
    top: 14,
    right: 24,
    backgroundColor: 'rgba(10,14,40,0.75)',
    borderRadius: 12,
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  legendText: { color: colors.muted, fontSize: 11, fontWeight: '700', marginTop: 12 },

  drawerWrap: { ...StyleSheet.absoluteFillObject, zIndex: 30 },
  drawer: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: '40%',
    backgroundColor: 'rgba(14,20,70,0.98)',
    paddingHorizontal: 10,
    paddingTop: 16,
    borderRightWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  provider: { color: 'rgba(235,240,255,0.7)', fontSize: 12, fontWeight: '700', marginLeft: 10, marginBottom: 6 },
  sectionRow: { height: DROW, flexDirection: 'row', alignItems: 'flex-end', gap: 8, paddingHorizontal: 10, paddingBottom: 8 },
  sectionText: { color: 'rgba(235,240,255,0.6)', fontSize: 11, fontWeight: '700' },
  sectionLine: { flex: 1, height: 1, backgroundColor: 'rgba(255,255,255,0.18)', marginBottom: 5 },
  dRow: {
    height: DROW - 4,
    marginBottom: 4,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingHorizontal: 12,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  dActive: { backgroundColor: 'rgba(255,255,255,0.92)' },
  dText: { color: colors.text, fontSize: 14, fontWeight: '600', flex: 1 },
  dTextActive: { color: '#1a2350', fontWeight: '800' },
});
