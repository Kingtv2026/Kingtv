import React, { memo, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { goTab } from '../components/TabBar';
import { thumb } from '../utils/thumb';
import MediaTv from './MediaTv';
import { isTVLike } from '../device';
import {
  ActivityIndicator,
  BackHandler,
  FlatList,
  Image,
  StyleSheet,
  Text,
  TextInput,
  useWindowDimensions,
  View,
  Platform,
  useTVEventHandler,
} from 'react-native';
import Icon from '../components/Icon';
import { loadCatalog, onCatalogUpdate, peekCatalog } from '../api/catalog';
import { ScreenProps, useHideSideMenu, useIsFocused } from '../nav/Navigator';
import { SIDE_W } from '../components/SideMenu';
import Focusable from '../components/Focusable';
import {
  getSeries,
  getSeriesCategories,
  getVodCategories,
  getVodStreams,
} from '../api/xtream';
import { colors } from '../theme';
import { useParentalGate } from '../components/PinPrompt';
import { isAdultName, isUnlocked, lock } from '../parental';
import { Category, VodItem } from '../types';
import { getFavs, getHistory, longPressFav, onFavChange, setVodContext } from '../vodLibrary';

type Props = ScreenProps<'Media'>;
type Sort = 'default' | 'recent' | 'name' | 'za';

const ALL = '__all__';
const HIST = '__hist__';
const FAV = '__fav__';
const RECENT = '__recent__';
const isSpecial = (id: string | null) => id === HIST || id === FAV;
const SORTS: { id: Sort; label: string }[] = [
  { id: 'default', label: 'Par défaut' },
  { id: 'recent', label: 'Ajouts récents' },
  { id: 'name', label: 'Nom A-Z' },
];

export default function MediaScreen({ route, navigation }: Props) {
  const { source, kind } = route.params;
  const { width } = useWindowDimensions();
  const wide = width >= 700;
  const isMovie = kind === 'movie';
  const isFocused = useIsFocused();
  // Téléphone : d'abord la liste des catégories, puis la grille
  const [showGroups, setShowGroups] = useState(true);
  // Télé : quand on parcourt les affiches, les colonnes de gauche se cachent
  const tv = isTVLike();
  const [immersive, setImmersive] = useState(tv);
  useHideSideMenu(wide && immersive);
  const lastCol = useRef({ col: 0, at: 0 });
  // Après OK sur une catégorie : la 1re affiche prend le focus
  const [gridFocus, setGridFocus] = useState(false);
  useEffect(() => {
    if (!isFocused || !wide || !immersive || tv) {
      return;
    }
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      setImmersive(false);
      return true;
    });
    return () => sub.remove();
  }, [isFocused, wide, immersive]);
  useTVEventHandler(evt => {
    // ← sur la première colonne : on réaffiche les catégories
    if (!tv && evt?.eventType === 'left' && immersive && lastCol.current.col === 0 && Date.now() - lastCol.current.at > 250) {
      setImmersive(false);
    }
  });
  useEffect(() => {
    if (!isFocused || wide || showGroups) {
      return;
    }
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      setShowGroups(true);
      return true;
    });
    return () => sub.remove();
  }, [isFocused, wide, showGroups]);

  const [categories, setCategories] = useState<Category[] | null>(null);
  const [categoryId, setCategoryId] = useState<string | null>(null);
  const categoryRef = useRef<string | null>(null);
  categoryRef.current = categoryId;
  const [items, setItems] = useState<VodItem[] | null>(null);
  const [allItems, setAllItems] = useState<VodItem[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [sort, setSort] = useState<Sort>('default');
  const cache = useRef(new Map<string, VodItem[]>());
  const catIdRef = useRef<string | null>(null);
  catIdRef.current = categoryId;
  // Contrôle parental : catégories de films pour adultes protégées par le code
  const { ask, prompt } = useParentalGate();
  const isAdultCat = (id: string) => isMovie && isAdultName(categories?.find(c => c.id === id)?.name);
  // Dès qu'on quitte la section adultes, on reverrouille
  useEffect(() => {
    if (!categoryId || !isAdultCat(categoryId) || (!wide && showGroups)) {
      lock();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [categoryId, categories, showGroups, wide]);
  useEffect(() => () => lock(), []);

  const openCategory = (id: string, after?: () => void) => {
    const go = () => {
      // annule un changement de groupe en attente (télécommande)
      if (catTimer.current) {
        clearTimeout(catTimer.current);
      }
      setCategoryId(id);
      after?.();
    };
    if (isAdultCat(id)) {
      ask(go);
    } else {
      go();
    }
  };
  const catTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const [allProgress, setAllProgress] = useState<{ done: number; total: number } | null>(null);
  const loadingAll = useRef<Promise<VodItem[]> | null>(null);

  const vk = isMovie ? 'movie' : 'series';
  useEffect(() => {
    if (isFocused) setVodContext(source.id, vk);
  }, [isFocused, source.id, vk]);
  const [libTick, setLibTick] = useState(0);
  // Nouveautés arrivées (mise à jour en arrière-plan ou « Actualiser ») : on oublie et on recharge
  const [catTick, setCatTick] = useState(0);
  useEffect(
    () =>
      onCatalogUpdate((sid, kind) => {
        if (sid !== source.id || kind !== vk) return;
        cache.current.clear();
        loadingAll.current = null;
        setAllItems(null);
        setCatTick(x => x + 1);
      }),
    [source.id, vk],
  );
  const [toast, setToast] = useState<string | null>(null);
  useEffect(() => {
    let t: ReturnType<typeof setTimeout> | null = null;
    const off = onFavChange((name, fav) => {
      setToast(fav ? `★ ${name} ajouté aux favoris` : `${name} retiré des favoris`);
      setLibTick(x => x + 1);
      if (t) clearTimeout(t);
      t = setTimeout(() => setToast(null), 2500);
    });
    return () => {
      off();
      if (t) clearTimeout(t);
    };
  }, []);

  const fetchCategory = async (id: string): Promise<VodItem[]> => {
    if (id === HIST) return getHistory(source.id, vk);
    if (id === FAV) return getFavs(source.id, vk);
    if (id === RECENT) {
      // Les 300 derniers ajouts de tout le catalogue
      const all = await loadAll(categories || []);
      const list = all.filter(i => i.added).sort((a, b) => (b.added || 0) - (a.added || 0)).slice(0, 300);
      cache.current.set(RECENT, list);
      return list;
    }
    const hit = cache.current.get(id);
    if (hit) {
      return hit;
    }
    // Catalogue déjà sur l'appareil : instantané, sans rien télécharger
    const cat = peekCatalog(source, isMovie ? 'movie' : 'series');
    if (cat) {
      const fromCat = cat.filter(i => i.categoryId === id);
      if (fromCat.length) {
        cache.current.set(id, fromCat);
        // vérifie ce groupe directement sur le serveur (1 seule requête) : nouveautés tout de suite
        (isMovie ? getVodStreams(source, id) : getSeries(source, id))
          .then(fresh => {
            if (!fresh.length) return;
            const changed =
              fresh.length !== fromCat.length || fresh.some(f => !fromCat.find(o => o.id === f.id));
            if (!changed) return;
            cache.current.set(id, fresh);
            if (catIdRef.current === id) setItems(fresh);
            // et on met tout le catalogue à jour discrètement
            loadCatalog(source, isMovie ? 'movie' : 'series').catch(() => {});
          })
          .catch(() => {});
        return fromCat;
      }
    }
    const list = isMovie ? await getVodStreams(source, id) : await getSeries(source, id);
    cache.current.set(id, list);
    return list;
  };

  /**
   * Tout le catalogue, chargé catégorie par catégorie (3 à la fois).
   * Une seule énorme requête ferait déborder la mémoire du téléphone.
   */
  const loadAll = (cats: Category[]): Promise<VodItem[]> => {
    const hit = cache.current.get(ALL);
    if (hit) {
      return Promise.resolve(hit);
    }
    if (loadingAll.current) {
      return loadingAll.current;
    }
    // Le catalogue complet est gardé sur l'appareil : ouvert tout de suite
    // (téléchargé seulement la toute première fois, avec la progression)
    loadingAll.current = loadCatalog(source, isMovie ? 'movie' : 'series', (done, total) =>
      setAllProgress({ done, total }),
    )
      .then(all => {
        cache.current.set(ALL, all);
        setAllItems(all);
        if (categoryRef.current === ALL) {
          setItems(all);
        }
        setAllProgress(null);
        return all;
      })
      .catch(() => {
        setAllProgress(null);
        loadingAll.current = null;
        return [] as VodItem[];
      });
    return loadingAll.current;
  };

  useEffect(() => {
    navigation.setOptions({ title: isMovie ? 'Films' : 'Séries' });
    (isMovie ? getVodCategories(source) : getSeriesCategories(source))
      .then(cats => {
        setCategories([
          { id: ALL, name: isMovie ? 'Tous les films' : 'Toutes les séries' },
          { id: RECENT, name: 'Ajouts récents' },
          { id: HIST, name: 'Historique' },
          { id: FAV, name: 'Favoris' },
          ...cats,
        ]);
        // première catégorie qui n'est pas pour adultes
        const first = cats.find(c => !(isMovie && isAdultName(c.name)));
        setCategoryId(first ? first.id : ALL);
      })
      .catch(e => setError(e?.message || 'Chargement impossible'));
  }, [isMovie, navigation, source]);

  // Charge la catégorie choisie (petit délai pour ne pas tout charger en défilant)
  useEffect(() => {
    if (!categoryId || !categories) {
      return;
    }
    if (isSpecial(categoryId)) {
      if (!isFocused) return;
      let off = false;
      fetchCategory(categoryId).then(l => !off && setItems(l));
      return () => {
        off = true;
      };
    }
    if (cache.current.has(categoryId)) {
      setItems(cache.current.get(categoryId)!);
      return;
    }
    if (categoryId === ALL) {
      setItems(allItems && allItems.length ? allItems : null);
      loadAll(categories);
      return;
    }
    setItems(null);
    let cancelled = false;
    const t = setTimeout(async () => {
      try {
        const list = await fetchCategory(categoryId);
        if (!cancelled) {
          setItems(list);
        }
      } catch (e: any) {
        if (!cancelled) {
          setError(e?.message || 'Chargement impossible');
        }
      }
    }, 350);
    return () => {
      cancelled = true;
      clearTimeout(t);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [categoryId, categories, catTick, isSpecial(categoryId) ? isFocused : 0, isSpecial(categoryId) ? libTick : 0]);

  // La recherche porte sur tout le catalogue
  useEffect(() => {
    if (!search.trim() || !categories || cache.current.has(ALL)) {
      return;
    }
    loadAll(categories);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search, categories]);

  const q = search.trim().toLowerCase();
  const searching = q.length > 0;

  const shown = useMemo(() => {
    const base = searching ? allItems : items;
    if (!base) {
      return null;
    }
    let list = searching ? base.filter(i => i.name.toLowerCase().includes(q)) : base;
    if (sort === 'recent') {
      list = [...list].sort((a, b) => (b.added || 0) - (a.added || 0));
    } else if (sort === 'name') {
      // tri rapide : clé sans accents calculée une seule fois par titre
      // (la comparaison « à la française » gelait l'app sur des milliers de titres)
      const keyed = list.map(i => [sortKey(i.name), i] as const);
      keyed.sort((a, b) => (a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0));
      list = keyed.map(k => k[1]);
    } else if (sort === 'za') {
      const keyed = list.map(i => [sortKey(i.name), i] as const);
      keyed.sort((a, b) => (a[0] < b[0] ? 1 : a[0] > b[0] ? -1 : 0));
      list = keyed.map(k => k[1]);
    }
    return list;
  }, [searching, allItems, items, q, sort]);

  // Grille : 3 colonnes sur téléphone, plus sur télé ; cartes à la bonne largeur
  // Télé : petites affiches (5 à 7 par rangée) ; téléphone : 3 colonnes
  // Le nombre de colonnes ne change pas (sinon la grille se recharge) : seules les cartes grandissent
  const sideW = isTVLike() ? SIDE_W : 0;
  const fullPane = width - 24;
  const paneWidth = wide ? fullPane : width - 16;
  const cols = wide ? Math.max(7, Math.floor(fullPane / 112)) : 3;
  const cardW = Math.floor(paneWidth / cols) - 10;

  // Cartes mémorisées : seule la carte qui change se redessine (navigation fluide)
  const openRef = useRef<(i: VodItem) => void>(() => {});
  const onCardPress = useCallback((it: VodItem) => openRef.current(it), []);
  const onCardFocus = useCallback(
    (index: number) => {
      lastCol.current = { col: index % cols, at: Date.now() };
      setGridFocus(false);
      if (wide) setImmersive(true);
    },
    [cols, wide],
  );
  const renderCard = useCallback(
    ({ item, index }: { item: VodItem; index: number }) => (
      <MediaCard
        item={item}
        index={index}
        width={cardW}
        preferred={gridFocus && index === 0}
        onPress={onCardPress}
        onFocusIndex={onCardFocus}
      />
    ),
    [cardW, gridFocus, onCardPress, onCardFocus],
  );

  const open = (item: VodItem) => {
    if (isMovie) {
      navigation.navigate('MovieDetail', { source, item });
    } else {
      navigation.navigate('SeriesDetail', { source, item });
    }
  };
  openRef.current = open;

  const catName = categories?.find(c => c.id === categoryId)?.name ?? '';
  // Télé : le menu principal reste caché, le panneau des groupes le remplace (comme MyTVOnline 4)
  const onPanelChange = useCallback((open: boolean) => setImmersive(tv ? true : !open), [tv]);

  if (error) {
    return (
      <View style={styles.center}>
        <Text style={styles.error}>{error}</Text>
      </View>
    );
  }

  if (!categories) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={colors.accent} />
      </View>
    );
  }

  // ---- Téléphone : écran des catégories ----
  // ---- Télé : écran style MyTVOnline 4 ----
  if (tv && categories) {
    return (
      <View style={{ flex: 1 }}>
        <MediaTv
          source={source}
          isMovie={isMovie}
          isFocused={isFocused}
          categories={categories}
          categoryId={categoryId}
          catName={searching ? `Recherche : ${search}` : catName}
          items={shown}
          loadingText={
            allProgress && (searching || categoryId === ALL)
              ? `Chargement du catalogue… ${allProgress.done}/${allProgress.total}`
              : null
          }
          sort={sort}
          setSort={setSort}
          search={search}
          setSearch={setSearch}
          onOpenCategory={(id, after) =>
            openCategory(id, () => {
              setSearch('');
              after();
            })
          }
          onOpen={open}
          isLocked={id => isAdultCat(id) && !isUnlocked()}
          onPanelChange={onPanelChange}
          onNav={key => {
            if (key === 'guide') navigation.navigate('Guide', { source });
            else if (key === 'search') navigation.navigate('Search', { source });
            else if (key === 'settings') navigation.navigate('Settings', { source });
            else goTab(key, isMovie ? 'movies' : 'series', source, navigation as any);
          }}
        />
        {prompt}
        {!!toast && (
          <View pointerEvents="none" style={styles.toast}>
            <Text style={styles.toastText}>{toast}</Text>
          </View>
        )}
      </View>
    );
  }

  if (!wide && showGroups) {
    return (
      <View style={{ flex: 1 }}>
      <FlatList
        data={categories}
        keyExtractor={c => c.id}
        contentContainerStyle={{ padding: 16, paddingBottom: 30 }}
        ListHeaderComponent={
          <View style={styles.groupsHead}>
            <Text style={styles.groupsTitle}>Catégories</Text>
            <Focusable
              style={styles.iconBtn}
              onPress={() => {
                setSearchOpen(true);
                setShowGroups(false);
              }}>
              <Icon name="search" size={22} />
            </Focusable>
          </View>
        }
        renderItem={({ item, index }) => (
          <Focusable
            hasTVPreferredFocus={index === 1}
            style={styles.groupRow}
            onPress={() =>
              openCategory(item.id, () => {
                setSearch('');
                setSearchOpen(false);
                setShowGroups(false);
              })
            }>
            <Icon
              name={item.id === ALL ? (isMovie ? 'film' : 'series') : item.id === RECENT ? 'plus' : item.id === HIST ? 'clock' : item.id === FAV ? 'star' : isAdultCat(item.id) ? 'lock' : 'folder'}
              size={24}
              color={isAdultCat(item.id) ? colors.danger : colors.accent}
            />
            <Text style={styles.groupName} numberOfLines={1}>
              {item.name}
            </Text>
            <Text style={styles.chev}>›</Text>
          </Focusable>
        )}
      />
      {prompt}
      </View>
    );
  }

  return (
    <View style={[styles.container, wide && { flexDirection: 'row' }]}>
      {wide && (
      <FlatList
        data={categories}
        horizontal={!wide}
        keyExtractor={c => c.id}
        style={wide ? [styles.catColumn, immersive && { display: 'none' }] : styles.catBar}
        contentContainerStyle={!wide ? { paddingHorizontal: 12 } : undefined}
        showsHorizontalScrollIndicator={false}
        renderItem={({ item, index }) => {
          const active = item.id === categoryId && !searching;
          return (
            <Focusable
              hasTVPreferredFocus={index === (categories.length > 1 ? 1 : 0)}
              style={[wide ? styles.catRow : styles.catChip, active && styles.catActive]}
              onFocus={() => {
                if (!wide) {
                  return;
                }
                // On ne charge rien au survol (fluide) : la catégorie s'ouvre avec OK
                setImmersive(false);
              }}
              onPress={() =>
                openCategory(item.id, () => {
                  setSearch('');
                  setSearchOpen(false);
                  if (wide) {
                    // télé : on cache le menu et on va directement aux films
                    setImmersive(true);
                    setGridFocus(true);
                  }
                })
              }>
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                {isAdultCat(item.id) && !isUnlocked() && (
                  <Icon name="lock" size={16} color={colors.danger} style={{ marginRight: 8 }} />
                )}
                <Text
                  style={[styles.catText, active && { color: '#fff', fontWeight: '800' }, { flexShrink: 1 }]}
                  numberOfLines={1}>
                  {item.name}
                </Text>
              </View>
            </Focusable>
          );
        }}
      />
      )}

      <View style={styles.gridPane}>
        {/* Barre : titre ou recherche + loupe */}
        <View style={styles.toolbar}>
          {!wide && (
            <Focusable style={styles.backGroups} onPress={() => setShowGroups(true)}>
              <Text style={styles.backGroupsText}>‹</Text>
            </Focusable>
          )}
          {searchOpen ? (
            <TextInput
              autoFocus
              value={search}
              onChangeText={setSearch}
              placeholder={isMovie ? 'Chercher un film…' : 'Chercher une série…'}
              placeholderTextColor={colors.muted}
              style={styles.search}
              autoCorrect={false}
              returnKeyType="search"
            />
          ) : (
            <Text style={styles.paneTitle} numberOfLines={1}>
              {catName}
            </Text>
          )}
          <Focusable
            style={styles.iconBtn}
            onPress={() => {
              if (searchOpen) {
                setSearch('');
                setSearchOpen(false);
              } else {
                setSearchOpen(true);
              }
            }}>
            {searchOpen ? <Text style={styles.iconText}>✕</Text> : <Icon name="search" size={22} />}
          </Focusable>
        </View>

        {/* Tri */}
        <View style={styles.sortRow}>
          {SORTS.map(s => (
            <Focusable
              key={s.id}
              style={[styles.sortChip, sort === s.id && styles.sortActive]}
              onPress={() => setSort(s.id)}>
              <Text style={[styles.sortText, sort === s.id && { color: '#fff' }]}>{s.label}</Text>
            </Focusable>
          ))}
          {shown && (
            <Text style={styles.count}>
              {searching ? `${shown.length} résultat${shown.length > 1 ? 's' : ''}` : shown.length}
            </Text>
          )}
        </View>

        {allProgress && (searching || categoryId === ALL) && (
          <Text style={styles.progress}>
            Chargement du catalogue… {allProgress.done}/{allProgress.total} catégories
          </Text>
        )}

        {shown === null ? (
          <ActivityIndicator color={colors.accent} style={{ marginTop: 40 }} />
        ) : (
          <FlatList
            key={cols}
            data={shown}
            numColumns={cols}
            keyExtractor={i => i.id}
            initialNumToRender={cols * 2}
            maxToRenderPerBatch={cols}
            updateCellsBatchingPeriod={60}
            windowSize={3}
            removeClippedSubviews
            contentContainerStyle={{ paddingBottom: 20 }}
            ListEmptyComponent={
              <Text style={styles.muted}>{searching
                  ? 'Aucun résultat.'
                  : categoryId === FAV
                  ? 'Aucun favori. Fais un appui long sur une affiche (ou ☆ Favori dans la fiche) pour l’ajouter.'
                  : categoryId === HIST
                  ? 'Rien de regardé pour l’instant.'
                  : 'Rien ici.'}</Text>
            }
            renderItem={renderCard}
          />
        )}
      </View>
      {prompt}
      {!!toast && (
        <View pointerEvents="none" style={styles.toast}>
          <Text style={styles.toastText}>{toast}</Text>
        </View>
      )}
    </View>
  );
}

/** Clé de tri : minuscules, sans accents ni préfixes « FR | » / articles de tête. */
const keyCache = new Map<string, string>();
function sortKey(name: string): string {
  let k = keyCache.get(name);
  if (k === undefined) {
    k = name
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/^[^a-z0-9]*(fr|en|eng|vf|vostfr|4k)\s*[|:-]\s*/, '')
      .replace(/^(le |la |les |l'|the )/, '')
      .replace(/^[^a-z0-9]+/, '');
    keyCache.set(name, k);
  }
  return k;
}

const MediaCard = memo(function MediaCard({
  item,
  index,
  width,
  preferred,
  onPress,
  onFocusIndex,
}: {
  item: VodItem;
  index: number;
  width: number;
  preferred: boolean;
  onPress: (i: VodItem) => void;
  onFocusIndex: (i: number) => void;
}) {
  const pw = width - 8;
  return (
    <Focusable
      hasTVPreferredFocus={preferred}
      style={[styles.card, { width }]}
      scale={1.06}
      onFocus={() => onFocusIndex(index)}
      onLongPress={() => longPressFav(item)}
      onPress={() => onPress(item)}>
      {item.poster ? (
        <Image
          source={{ uri: thumb(item.poster, pw) }}
          style={[styles.poster, { width: pw, height: pw * 1.5 }]}
          resizeMode="cover"
          resizeMethod="resize"
          fadeDuration={0}
        />
      ) : (
        <View style={[styles.poster, styles.posterEmpty, { width: pw, height: pw * 1.5 }]}>
          <Text style={styles.posterLetter}>{item.name.charAt(0)}</Text>
        </View>
      )}
      {Number(item.rating) > 0 && (
        <View style={styles.rating}>
          <Text style={styles.ratingText}>★ {Number(item.rating).toFixed(1)}</Text>
        </View>
      )}
      <Text style={styles.cardName} numberOfLines={2}>
        {item.name}
      </Text>
    </Focusable>
  );
});

const styles = StyleSheet.create({
  toast: {
    position: 'absolute',
    bottom: 40,
    alignSelf: 'center',
    backgroundColor: 'rgba(10,14,30,0.92)',
    borderColor: 'rgba(127,176,255,0.6)',
    borderWidth: 1,
    borderRadius: 14,
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  toastText: { color: '#fff', fontSize: 15, fontWeight: '800' },
  container: { flex: 1 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  error: { color: colors.danger, fontSize: 16, padding: 24, textAlign: 'center' },
  muted: { color: colors.muted, fontSize: 15, padding: 12 },
  catColumn: { width: 230, flexGrow: 0, paddingLeft: 12 },
  catBar: { flexGrow: 0, paddingVertical: 6 },
  catRow: {
    paddingHorizontal: 14,
    paddingVertical: 11,
    marginBottom: 4,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  catChip: {
    paddingHorizontal: 14,
    paddingVertical: 7,
    marginRight: 8,
    borderRadius: 20,
    borderWidth: 2,
    borderColor: colors.border,
    backgroundColor: colors.panel,
  },
  catActive: { backgroundColor: 'rgba(79,140,255,0.18)', borderColor: 'rgba(79,140,255,0.45)' },
  catText: { color: colors.text, fontSize: 15 },
  gridPane: { flex: 1, paddingHorizontal: 8 },
  groupsHead: { flexDirection: 'row', alignItems: 'center', marginBottom: 12, marginLeft: 4 },
  groupsTitle: { color: colors.text, fontSize: 22, fontWeight: '900', flex: 1 },
  groupRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: 14,
    paddingVertical: 14,
    marginBottom: 8,
    borderRadius: 14,
    borderWidth: 2,
    borderColor: colors.border,
    backgroundColor: colors.panel,
  },
  groupIcon: { fontSize: 20 },
  groupName: { color: colors.text, fontSize: 17, fontWeight: '700', flex: 1 },
  chev: { color: colors.muted, fontSize: 24, marginLeft: 4 },
  backGroups: {
    width: 46,
    height: 46,
    borderRadius: 23,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: 'rgba(79,140,255,0.45)',
    backgroundColor: 'rgba(79,140,255,0.18)',
  },
  backGroupsText: { color: '#fff', fontSize: 26, fontWeight: '800', marginTop: -3 },
  toolbar: { flexDirection: 'row', alignItems: 'center', gap: 10, marginHorizontal: 4, marginTop: 4 },
  paneTitle: { flex: 1, color: colors.text, fontSize: 20, fontWeight: '900' },
  search: {
    flex: 1,
    backgroundColor: colors.panel,
    color: colors.text,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: colors.focus,
    paddingHorizontal: 16,
    paddingVertical: 9,
    fontSize: 16,
  },
  iconBtn: {
    width: 46,
    height: 46,
    borderRadius: 23,
    borderWidth: 2,
    borderColor: colors.border,
    backgroundColor: colors.panel,
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconText: { fontSize: 19, color: colors.text },
  sortRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 8,
    marginHorizontal: 4,
    marginTop: 10,
    marginBottom: 6,
  },
  sortChip: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    borderWidth: 2,
    borderColor: colors.border,
    backgroundColor: colors.panel,
  },
  sortActive: { backgroundColor: colors.accent, borderColor: colors.accent },
  sortText: { color: colors.text, fontSize: 13, fontWeight: '700' },
  count: { color: colors.muted, fontSize: 12, marginLeft: 'auto' },
  progress: { color: colors.accent, fontSize: 12, marginHorizontal: 6, marginBottom: 4 },
  card: {
    margin: 5,
    padding: 2,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  poster: { borderRadius: 10 },
  posterEmpty: { backgroundColor: colors.panelAlt, alignItems: 'center', justifyContent: 'center' },
  posterLetter: { color: colors.muted, fontSize: 34, fontWeight: '900' },
  rating: {
    position: 'absolute',
    top: 8,
    right: 8,
    backgroundColor: 'rgba(0,0,0,0.72)',
    borderRadius: 8,
    paddingHorizontal: 5,
    paddingVertical: 2,
  },
  ratingText: { color: colors.star, fontSize: 11, fontWeight: '800' },
  cardName: { color: colors.text, fontSize: 12, fontWeight: '600', marginTop: 6, marginHorizontal: 2 },
});
