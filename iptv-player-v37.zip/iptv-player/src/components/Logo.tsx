import React, { useState } from 'react';
import { Image, Text, View } from 'react-native';
import { BRAND, colors } from '../theme';
import { useBrand } from '../brand';

/** Logo en haut : celui du revendeur s'il en a un, sinon Kingtv. */
export default function Logo({ size = 28 }: { size?: number }) {
  const brand = useBrand();
  const [failed, setFailed] = useState<string | null>(null);

  if (brand.logo && failed !== brand.logo) {
    const h = Math.round(size * 1.4);
    const ratio = brand.w && brand.h ? brand.w / brand.h : 3;
    const w = Math.round(Math.min(Math.max(h * ratio, h), size * 7));
    return (
      <Image
        source={{ uri: brand.logo }}
        style={{ width: w, height: h }}
        resizeMode="contain"
        fadeDuration={0}
        onError={() => setFailed(brand.logo!)}
      />
    );
  }

  return (
    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
      <Text style={{ color: colors.text, fontSize: size, fontWeight: '900', letterSpacing: 2 }}>
        {BRAND.first}
      </Text>
      <View
        style={{
          marginLeft: size * 0.2,
          backgroundColor: colors.accent,
          borderRadius: size * 0.25,
          paddingHorizontal: size * 0.28,
          paddingVertical: size * 0.04,
        }}>
        <Text style={{ color: '#fff', fontSize: size * 0.8, fontWeight: '900', letterSpacing: 1 }}>
          {BRAND.second}
        </Text>
      </View>
    </View>
  );
}
