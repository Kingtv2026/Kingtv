import React, { useEffect, useState } from 'react';
import { BackHandler, StyleSheet, Text, View } from 'react-native';
import Focusable from './Focusable';
import { colors } from '../theme';
import Icon from './Icon';
import { BUILD } from '../buildInfo';
import { checkForUpdate, downloadAndInstall, UpdateInfo } from '../update';

/** Fenêtre « Mise à jour disponible ». */
export function UpdateDialog({ info, onClose }: { info: UpdateInfo; onClose: () => void }) {
  const [pct, setPct] = useState<number | null>(null);
  const [done, setDone] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      onClose();
      return true;
    });
    return () => sub.remove();
  }, [onClose]);

  const start = async () => {
    setError(null);
    setPct(0);
    try {
      await downloadAndInstall(info.url, setPct);
      setDone(true);
    } catch (e: any) {
      setPct(null);
      setError(e?.message || 'Téléchargement impossible');
    }
  };

  return (
    <View style={styles.overlay}>
      <View style={styles.box}>
        <Icon name="download" size={44} color={colors.accent} style={{ alignSelf: 'center', marginBottom: 10 }} />
        <Text style={styles.title}>Mise à jour disponible</Text>
        <Text style={styles.sub}>
          Version {info.build}  ·  tu as la version {BUILD}
        </Text>

        {done ? (
          <Text style={styles.text}>
            Confirme l’installation à l’écran. Si Android le demande, autorise Kingtv à installer des
            applications, puis reviens et appuie de nouveau sur Mettre à jour.
          </Text>
        ) : pct !== null ? (
          <>
            <Text style={styles.text}>Téléchargement… {pct} %</Text>
            <View style={styles.track}>
              <View style={[styles.fill, { width: `${pct}%` }]} />
            </View>
          </>
        ) : (
          <Text style={styles.text}>
            Une nouvelle version de Kingtv est prête. Tes listes et tes favoris sont conservés.
          </Text>
        )}
        {!!error && <Text style={styles.error}>{error}</Text>}

        <View style={styles.buttons}>
          {(pct === null || done) && (
            <Focusable hasTVPreferredFocus style={[styles.btn, styles.primary]} onPress={start}>
              <Text style={styles.btnText}>{done ? 'Réessayer' : 'Mettre à jour'}</Text>
            </Focusable>
          )}
          <Focusable style={styles.btn} onPress={onClose}>
            <Text style={styles.btnText}>Plus tard</Text>
          </Focusable>
        </View>
      </View>
    </View>
  );
}

/** Vérifie une fois au démarrage et affiche la fenêtre si besoin. */
export default function UpdateGate() {
  const [info, setInfo] = useState<UpdateInfo | null>(null);
  useEffect(() => {
    const t = setTimeout(() => {
      checkForUpdate().then(setInfo).catch(() => {});
    }, 4000);
    return () => clearTimeout(t);
  }, []);
  return info ? <UpdateDialog info={info} onClose={() => setInfo(null)} /> : null;
}

const styles = StyleSheet.create({
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.7)',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  box: {
    width: '100%',
    maxWidth: 460,
    padding: 24,
    borderRadius: 24,
    backgroundColor: colors.panelSolid,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
  },
  icon: { fontSize: 40 },
  title: { color: colors.text, fontSize: 22, fontWeight: '900', marginTop: 8 },
  sub: { color: colors.muted, fontSize: 13, marginTop: 4 },
  text: { color: colors.text, fontSize: 15, textAlign: 'center', marginTop: 16, lineHeight: 21 },
  error: { color: colors.danger, fontSize: 13, textAlign: 'center', marginTop: 10 },
  track: { width: '100%', height: 8, borderRadius: 4, backgroundColor: colors.panelAlt, marginTop: 12 },
  fill: { height: 8, borderRadius: 4, backgroundColor: colors.accent },
  buttons: { flexDirection: 'row', gap: 12, marginTop: 22 },
  btn: {
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 14,
    borderWidth: 2,
    borderColor: colors.border,
    backgroundColor: colors.panelAlt,
  },
  primary: { backgroundColor: colors.accent, borderColor: colors.accent },
  btnText: { color: '#fff', fontSize: 15, fontWeight: '800' },
});
