/**
 * Guide horaire en grille : aperçu vidéo + fiche en haut, chaînes à gauche,
 * émissions en blocs, ligne de l'heure actuelle.
 */
import React, { memo, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  BackHandler,
  FlatList,
  Image,
  StyleSheet,
  Text,
  useWindowDimensions,
  View,
  AppState,
} from 'react-native';
import Video from 'react-native-video';
import { ScreenProps, useIsFocused } from '../nav/Navigator';
import Focusable from '../components/Focusable';
import { loadPlaylist } from '../api';
import { formatTime, getPrograms } from '../api/epg';
import { catchupUrl } from '../api/xtream';
import { setQueue } from '../playerQueue';
import { getFavorites, toggleFavorite } from '../storage';
import { colors } from '../theme';
import Icon from '../components/Icon';
import RecordSheet from '../components/RecordSheet';
import { recordingSupported } from '../record';
import { CAT_ALL, CAT_FAVORITES, Category, Channel, Playlist, Program, XtreamSource } from '../types';

type Props = ScreenProps<'Guide'>;

const SLOT_MIN = 30;
const MIN = 60 * 1000;
const JOURS = ['dim.', 'lun.', 'mar.', 'mer.', 'jeu.', 'ven.', 'sam.'];
const MOIS = ['janv.', 'févr.', 'mars', 'avr.', 'mai', 'juin', 'juil.', 'août', 'sept.', 'oct.', 'nov.', 'déc.'];

export default function GuideScreen({ route, navigation }: Props) {
  const { source } = route.params;
  const isFocused = useIsFocused();
  const { width, height } = useWindowDimensions();
  const wide = width >= 700;

  const CH_W = wide ? 270 : 118;
  const ROW_H = wide ? 52 : 50;
  const WINDOW_MIN = wide ? 180 : 90;
  const gridW = width - CH_W - (wide ? 16 : 6);
  const pxPerMin = gridW / WINDOW_MIN;
  const topH = wide ? Math.min(220, Math.round(height * 0.34)) : 128;

  const [playlist, setPlaylist] = useState<Playlist | null>(null);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [categoryId, setCategoryId] = useState<string | null>(null);
  const [picker, setPicker] = useState(false);
  const [now, setNow] = useState(Date.now());
  const [offset, setOffset] = useState(0); // en tranches de 30 min
  const [sel, setSel] = useState<{ channel: Channel; program: Program | null } | null>(null);
  const [rec, setRec] = useState<{ channel: Channel; program: Program | null } | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 4500);
    return () => clearTimeout(t);
  }, [toast]);
  const [preview, setPreview] = useState<Channel | null>(null);
  const previewTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // L'heure du guide : rafraîchie souvent, au retour dans l'app et sur l'écran
  useEffect(() => {
    setNow(Date.now());
    const t = setInterval(() => setNow(Date.now()), 15000);
    const sub = AppState.addEventListener('change', st => {
      if (st === 'active') setNow(Date.now());
    });
    return () => {
      clearInterval(t);
      sub.remove();
    };
  }, [isFocused]);

  useEffect(() => {
    Promise.all([loadPlaylist(source), getFavorites(source.id)])
      .then(([pl, favs]) => {
        setPlaylist(pl);
        setFavorites(favs);
        setCategoryId(favs.length > 0 ? CAT_FAVORITES : pl.categories[0]?.id ?? CAT_ALL);
      })
      .catch(e => setError(e?.message || 'Chargement impossible'));
  }, [source]);

  useEffect(() => {
    if (!picker || !isFocused) {
      return;
    }
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      setPicker(false);
      return true;
    });
    return () => sub.remove();
  }, [picker, isFocused]);

  const categories: Category[] = useMemo(
    () => [
      { id: CAT_FAVORITES, name: 'Favoris' },
      { id: CAT_ALL, name: 'Toutes les chaînes' },
      ...(playlist?.categories || []),
    ],
    [playlist],
  );
  const catNames = useMemo(() => new Map((playlist?.categories || []).map(c => [c.id, c.name])), [playlist]);

  const channels = useMemo(() => {
    if (!playlist) {
      return [];
    }
    if (categoryId === CAT_FAVORITES) {
      const f = new Set(favorites);
      return playlist.channels.filter(c => f.has(c.id));
    }
    if (categoryId === CAT_ALL) {
      return playlist.channels;
    }
    return playlist.channels.filter(c => c.categoryId === categoryId);
  }, [playlist, categoryId, favorites]);

  // Fenêtre : commence 30 min avant la demi-heure en cours
  const base = Math.floor(now / (SLOT_MIN * MIN)) * SLOT_MIN * MIN - SLOT_MIN * MIN;
  const winStart = base + offset * SLOT_MIN * MIN;
  const winEnd = winStart + WINDOW_MIN * MIN;
  const slots = Array.from({ length: WINDOW_MIN / SLOT_MIN }, (_, i) => winStart + (i + 1) * SLOT_MIN * MIN);
  const nowX = ((now - winStart) / MIN) * pxPerMin;
  const nowD = new Date(now);

  // Sélection d'une émission : fiche tout de suite, aperçu vidéo après une courte pause
  const onSelect = useCallback((channel: Channel, program: Program | null) => {
    setSel({ channel, program });
    if (previewTimer.current) {
      clearTimeout(previewTimer.current);
    }
    previewTimer.current = setTimeout(() => setPreview(p => (p?.id === channel.id ? p : channel)), 700);
  }, []);
  useEffect(
    () => () => {
      if (previewTimer.current) {
        clearTimeout(previewTimer.current);
      }
    },
    [],
  );

  const playLive = useCallback(
    (channel: Channel) => {
      const index = Math.max(0, channels.findIndex(c => c.id === channel.id));
      setPreview(null); // libère la connexion de l'aperçu
      setTimeout(() => {
        setQueue(channels, source);
        navigation.navigate('Player', { index });
      }, 400);
    },
    [channels, source, navigation],
  );

  const onPress = useCallback(
    (channel: Channel, program: Program | null) => {
      const t = Date.now();
      if (!program || (program.start <= t && program.end > t)) {
        playLive(channel);
        return;
      }
      if (program.end <= t && (channel.archiveDays || 0) > 0 && source.type === 'xtream') {
        const url = catchupUrl(source as XtreamSource, channel.id, program);
        if (url) {
          setPreview(null);
          navigation.navigate('Player', {
            vod: {
              url,
              title: `${channel.name} · ${program.title} (${formatTime(program.start)})`,
              catchup: { source: source as XtreamSource, streamId: channel.id, program },
            },
          });
          return;
        }
      }
      if (program.start > t && recordingSupported) {
        // Émission à venir : on propose de la programmer
        onSelect(channel, program);
        setRec({ channel, program });
        return;
      }
      onSelect(channel, program);
    },
    [playLive, onSelect, source, navigation],
  );

  const onToggleFav = async () => {
    if (sel) {
      setFavorites(await toggleFavorite(source.id, sel.channel.id));
    }
  };

  const renderRow = useCallback(
    ({ item, index }: { item: Channel; index: number }) => (
      <GuideRow
        source={source}
        channel={item}
        index={index}
        preferred={index === 0}
        playing={preview?.id === item.id}
        chW={CH_W}
        rowH={ROW_H}
        gridW={gridW}
        winStart={winStart}
        winEnd={winEnd}
        pxPerMin={pxPerMin}
        now={now}
        wide={wide}
        onSelect={onSelect}
        onPress={onPress}
      />
    ),
    [source, preview, CH_W, ROW_H, gridW, winStart, winEnd, pxPerMin, now, wide, onSelect, onPress],
  );

  if (error) {
    return (
      <View style={styles.center}>
        <Text style={styles.error}>{error}</Text>
      </View>
    );
  }
  if (!playlist || !categoryId) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={colors.accent} />
        <Text style={styles.muted}>Chargement du guide…</Text>
      </View>
    );
  }

  const p = sel?.program || null;
  const live = p && p.start <= now && p.end > now;
  const remaining = live ? Math.max(1, Math.round((p!.end - now) / MIN)) : 0;
  const progress = live ? (now - p!.start) / (p!.end - p!.start) : 0;
  const isFav = sel ? favorites.includes(sel.channel.id) : false;
  const catName = categories.find(c => c.id === categoryId)?.name ?? '';

  return (
    <View style={styles.container}>
      {/* Haut : aperçu + fiche */}
      <View style={[styles.top, { height: topH }]}>
        <View style={[styles.previewBox, { height: topH - 8, width: Math.round(((topH - 8) * 16) / 9) }]}>
          {preview && isFocused ? (
            <Video
              key={preview.streamUrl}
              source={{ uri: preview.streamUrl }}
              style={StyleSheet.absoluteFill}
              resizeMode="cover"
              muted={false}
            />
          ) : (
            <View style={styles.previewEmpty}>
              {sel?.channel.logo ? (
                <Image source={{ uri: sel.channel.logo }} style={styles.previewLogo} resizeMode="contain" />
              ) : (
                <Icon name="tv" size={48} color={colors.muted} />
              )}
            </View>
          )}
        </View>

        <View style={styles.info}>
          {sel ? (
            <>
              <View style={styles.infoHead}>
                <Text style={[styles.infoTitle, !wide && { fontSize: 16 }]} numberOfLines={1}>
                  {p?.title || sel.channel.name}
                  {live ? <Text style={styles.liveTag}>  LIVE</Text> : null}
                </Text>
                {recordingSupported && (!p || p.end > now) && (
                  <Focusable style={styles.favBtn} onPress={() => setRec({ channel: sel.channel, program: p })}>
                    <Icon name="record" size={22} color={colors.live} />
                  </Focusable>
                )}
                <Focusable style={styles.favBtn} onPress={onToggleFav}>
                  <Text style={[styles.favIcon, isFav && { color: colors.star }]}>{isFav ? '★' : '☆'}</Text>
                </Focusable>
              </View>
              {p && (
                <View style={styles.timeRow}>
                  <Text style={styles.infoTime}>
                    {formatTime(p.start)} — {formatTime(p.end)}
                  </Text>
                  {live && (
                    <>
                      <View style={styles.progTrack}>
                        <View style={[styles.progFill, { width: `${progress * 100}%` }]} />
                      </View>
                      <Text style={styles.infoTime}>{remaining} min</Text>
                    </>
                  )}
                  <View style={{ flex: 1 }} />
                  {wide && <Text style={styles.catName}>{(catNames.get(sel.channel.categoryId) || '').toUpperCase()}</Text>}
                </View>
              )}
              {!!p?.description && (
                <Text style={styles.infoDesc} numberOfLines={wide ? 3 : 2}>
                  {p.description}
                </Text>
              )}
              {!p && <Text style={styles.infoDesc}>Pas d’information pour cette chaîne.</Text>}
            </>
          ) : (
            <Text style={styles.muted}>Choisis une émission. OK sur une émission en cours = plein écran.</Text>
          )}
        </View>
      </View>

      {/* Barre d'outils (télé : groupe + temps) */}
      <View style={styles.toolbar}>
        {wide && (
          <Focusable style={styles.groupBtn} onPress={() => setPicker(true)}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Icon name="folder" size={18} color={colors.accent} style={{ marginRight: 8 }} />
              <Text style={styles.groupText} numberOfLines={1}>{catName}  ▾</Text>
            </View>
          </Focusable>
        )}
        <Focusable style={styles.timeBtn} onPress={() => setOffset(o => Math.max(o - 1, -48))}>
          <Text style={styles.timeText}>◀ 30 min</Text>
        </Focusable>
        <Focusable style={styles.timeBtn} onPress={() => setOffset(0)}>
          <Text style={styles.timeText}>Maintenant</Text>
        </Focusable>
        <Focusable style={styles.timeBtn} onPress={() => setOffset(o => Math.min(o + 1, 40))}>
          <Text style={styles.timeText}>30 min ▶</Text>
        </Focusable>
      </View>

      {/* Règle des heures */}
      <View style={styles.ruler}>
        <Focusable style={[styles.dateBtn, { width: CH_W - 4 }]} onPress={() => setPicker(true)}>
          <Text style={styles.dateText} numberOfLines={1}>
            {wide
              ? `${JOURS[nowD.getDay()]} ${nowD.getDate()} ${MOIS[nowD.getMonth()]}, ${formatTime(now)}`
              : `${catName} ▾`}
          </Text>
        </Focusable>
        <View style={{ width: gridW, height: 30 }}>
          {slots.map(t => (
            <Text key={t} style={[styles.slotText, { left: ((t - winStart) / MIN) * pxPerMin - 22 }]}>
              {formatTime(t)}
            </Text>
          ))}
        </View>
      </View>

      {/* Grille */}
      <View style={{ flex: 1 }}>
        <FlatList
          data={channels}
          keyExtractor={c => c.id}
          initialNumToRender={10}
          maxToRenderPerBatch={6}
          windowSize={5}
          removeClippedSubviews
          getItemLayout={(_, i) => ({ length: ROW_H, offset: ROW_H * i, index: i })}
          ListEmptyComponent={
            <Text style={styles.muted}>
              {categoryId === CAT_FAVORITES
                ? 'Aucun favori. Ajoute des chaînes avec ☆ ou un appui long dans Direct.'
                : 'Aucune chaîne dans ce groupe.'}
            </Text>
          }
          renderItem={renderRow}
        />
        {nowX >= 0 && nowX <= gridW && (
          <View pointerEvents="none" style={[styles.nowLine, { left: CH_W + nowX }]}>
            <View style={styles.nowDot} />
          </View>
        )}
      </View>

      {/* Liste des groupes */}
      {picker && (
        <View style={styles.pickerWrap}>
          <View style={styles.picker}>
            <Text style={styles.pickerTitle}>Groupes</Text>
            <FlatList
              data={categories}
              keyExtractor={c => c.id}
              renderItem={({ item }) => (
                <Focusable
                  hasTVPreferredFocus={item.id === categoryId}
                  style={[styles.pickRow, item.id === categoryId && styles.pickActive]}
                  onPress={() => {
                    setCategoryId(item.id);
                    setSel(null);
                    setPicker(false);
                  }}>
                  <Text style={styles.pickText} numberOfLines={1}>
                    {item.name}
                  </Text>
                </Focusable>
              )}
            />
            <Focusable style={styles.closeBtn} onPress={() => setPicker(false)}>
              <Text style={styles.timeText}>Fermer</Text>
            </Focusable>
          </View>
        </View>
      )}

      {!!toast && (
        <View style={styles.toast} pointerEvents="none">
          <Icon name="clock" size={18} color={colors.accent} />
          <Text style={styles.toastText}>{toast}</Text>
        </View>
      )}

      {rec && (
        <RecordSheet
          url={rec.channel.streamUrl}
          channel={rec.channel.name}
          program={rec.program}
          onClose={() => setRec(null)}
          onDone={msg => {
            setRec(null);
            setToast(msg);
          }}
        />
      )}
    </View>
  );
}

// ---------- Une ligne de la grille ----------
const GuideRow = memo(function GuideRow({
  source,
  channel,
  index,
  preferred,
  playing,
  chW,
  rowH,
  gridW,
  winStart,
  winEnd,
  pxPerMin,
  now,
  wide,
  onSelect,
  onPress,
}: {
  source: Props['route']['params']['source'];
  channel: Channel;
  index: number;
  preferred: boolean;
  playing: boolean;
  chW: number;
  rowH: number;
  gridW: number;
  winStart: number;
  winEnd: number;
  pxPerMin: number;
  now: number;
  wide: boolean;
  onSelect: (c: Channel, p: Program | null) => void;
  onPress: (c: Channel, p: Program | null) => void;
}) {
  const [programs, setPrograms] = useState<Program[] | null>(null);

  useEffect(() => {
    let cancelled = false;
    getPrograms(source, channel).then(p => !cancelled && setPrograms(p));
    return () => {
      cancelled = true;
    };
  }, [source, channel]);

  const visible = (programs || []).filter(p => p.end > winStart && p.start < winEnd);
  const current = (programs || []).find(p => p.start <= now && p.end > now) || null;
  const archive = (channel.archiveDays || 0) > 0;

  return (
    <View style={[styles.row, { height: rowH }]}>
      <Cell
        preferred={preferred}
        style={[styles.chCell, { width: chW - 4, height: rowH - 4 }]}
        focusedStyle={styles.cellFocused}
        onFocus={() => onSelect(channel, current)}
        onPress={() => onPress(channel, current)}
        render={focused => (
          <>
            <Text style={[styles.chNum, playing && styles.playingTxt, focused && styles.focusTxt]}>{index + 1}</Text>
            <View style={styles.chLogoBox}>
              {channel.logo ? (
                <Image source={{ uri: channel.logo }} style={styles.chLogo} resizeMode="contain" resizeMethod="resize" fadeDuration={0} />
              ) : null}
            </View>
            {wide && (
              <Text
                style={[styles.chName, playing && styles.playingTxt, focused && styles.focusTxt]}
                numberOfLines={1}>
                {channel.name}
              </Text>
            )}
            {playing && <Text style={styles.playIcon}>▶</Text>}
            {archive && <Text style={[styles.archIcon, focused && styles.focusTxt]}>⟲</Text>}
          </>
        )}
      />

      <View style={{ width: gridW, height: rowH }}>
        {programs === null ? (
          <View style={[styles.prog, { left: 0, width: gridW - 2 }]}>
            <Text style={styles.progMuted}>…</Text>
          </View>
        ) : visible.length === 0 ? (
          <Cell
            style={[styles.prog, { left: 0, width: gridW - 2 }]}
            focusedStyle={styles.progFocused}
            onFocus={() => onSelect(channel, null)}
            onPress={() => onPress(channel, null)}
        render={focused => <Text style={[styles.progMuted, focused && styles.focusDark]}>{channel.name}</Text>}
      />
        ) : (
          visible.map(p => {
            const s = Math.max(p.start, winStart);
            const e = Math.min(p.end, winEnd);
            const left = ((s - winStart) / MIN) * pxPerMin;
            const w = ((e - s) / MIN) * pxPerMin;
            const isLive = p.start <= now && p.end > now;
            const past = p.end <= now;
            return (
              <Cell
                key={`${p.start}-${p.end}`}
                style={[
                  styles.prog,
                  { left, width: Math.max(w - 2, 4) },
                  isLive && styles.progLive,
                  past && styles.progPast,
                ]}
                focusedStyle={styles.progFocused}
                onFocus={() => onSelect(channel, p)}
                onPress={() => onPress(channel, p)}
        render={focused =>
                  w > 26 ? (
                    <Text
                      style={[styles.progTitle, past && !focused && { color: colors.muted }, focused && styles.focusDark]}
                      numberOfLines={1}>
                      {p.title || '—'}
                      {isLive && w > 140 ? <Text style={styles.liveSmall}>  LIVE</Text> : null}
                    </Text>
                  ) : null}
      />
            );
          })
        )}
      </View>
    </View>
  );
});

/** Case focusable qui connaît son propre état (pour changer la couleur du texte). */
function Cell({
  render,
  style,
  focusedStyle,
  onFocus,
  onPress,
  preferred,
}: {
  render: (focused: boolean) => React.ReactNode;
  style: any;
  focusedStyle: any;
  onFocus: () => void;
  onPress: () => void;
  preferred?: boolean;
}) {
  const [focused, setFocused] = useState(false);
  return (
    <Focusable
      hasTVPreferredFocus={preferred}
      style={style}
      focusedStyle={focusedStyle}
      onFocus={() => {
        setFocused(true);
        onFocus();
      }}
      onBlur={() => setFocused(false)}
      onPress={() => {
        onFocus();
        onPress();
      }}>
      {render(focused)}
    </Focusable>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#05070c' },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12 },
  error: { color: colors.danger, fontSize: 16, padding: 24, textAlign: 'center' },
  muted: { color: colors.muted, fontSize: 14, padding: 10 },

  top: { flexDirection: 'row', paddingHorizontal: 10, paddingTop: 4, gap: 16 },
  previewBox: { borderRadius: 10, overflow: 'hidden', backgroundColor: '#000' },
  previewEmpty: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.panelSolid },
  previewLogo: { width: '50%', height: '50%' },
  previewIcon: { fontSize: 30 },
  info: { flex: 1, paddingTop: 4 },
  infoHead: { flexDirection: 'row', alignItems: 'flex-start', gap: 8 },
  infoTitle: { flex: 1, color: '#fff', fontSize: 20, fontWeight: '800' },
  liveTag: { color: '#fff', fontSize: 11, fontWeight: '900' },
  favBtn: { width: 38, height: 38, borderRadius: 19, alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: 'transparent' },
  favIcon: { color: colors.text, fontSize: 22 },
  toast: {
    position: 'absolute',
    bottom: 24,
    alignSelf: 'center',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: 'rgba(7,10,18,0.95)',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
    paddingHorizontal: 16,
    paddingVertical: 10,
    maxWidth: '90%',
    zIndex: 70,
  },
  toastText: { color: '#fff', fontSize: 14, fontWeight: '700' },
  timeRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 4 },
  infoTime: { color: colors.muted, fontSize: 13 },
  progTrack: { width: 50, height: 3, borderRadius: 2, backgroundColor: 'rgba(255,255,255,0.25)' },
  progFill: { height: 3, borderRadius: 2, backgroundColor: '#fff' },
  catName: { color: colors.text, fontSize: 12, fontWeight: '800', letterSpacing: 0.5 },
  infoDesc: { color: 'rgba(244,246,251,0.8)', fontSize: 13, marginTop: 8, lineHeight: 18 },

  ruler: { flexDirection: 'row', alignItems: 'center', marginTop: 6, paddingLeft: 6 },
  dateBtn: { paddingVertical: 5, paddingHorizontal: 6, borderRadius: 8, borderWidth: 2, borderColor: 'transparent', marginRight: 4 },
  dateText: { color: colors.focus, fontSize: 13, fontWeight: '700' },
  slotText: { position: 'absolute', top: 6, width: 60, color: colors.muted, fontSize: 12, textAlign: 'center' },

  toolbar: { flexDirection: 'row', gap: 6, paddingHorizontal: 8, paddingVertical: 4 },
  groupBtn: { flex: 1, paddingHorizontal: 12, paddingVertical: 6, borderRadius: 10, borderWidth: 2, borderColor: colors.border, backgroundColor: colors.panel },
  groupText: { color: colors.text, fontSize: 13, fontWeight: '800' },
  timeBtn: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 10, borderWidth: 2, borderColor: colors.border, backgroundColor: colors.panel },
  timeText: { color: colors.text, fontSize: 12, fontWeight: '800', textAlign: 'center' },

  row: { flexDirection: 'row', alignItems: 'center', paddingLeft: 6 },
  chCell: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 6,
    marginRight: 4,
    borderRadius: 6,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  cellFocused: { backgroundColor: '#e8ebf1', borderColor: '#e8ebf1' },
  chNum: { color: colors.text, fontSize: 14, fontWeight: '700', minWidth: 26, textAlign: 'right' },
  chLogoBox: { width: 44, height: 30, alignItems: 'center', justifyContent: 'center' },
  chLogo: { width: '100%', height: '100%' },
  chName: { flex: 1, color: colors.text, fontSize: 14, fontWeight: '700' },
  playingTxt: { color: colors.accent },
  playIcon: { color: colors.accent, fontSize: 12 },
  archIcon: { color: colors.muted, fontSize: 15 },
  focusTxt: { color: '#0b0f18' },

  prog: {
    position: 'absolute',
    top: 2,
    bottom: 2,
    paddingHorizontal: 10,
    justifyContent: 'center',
    borderRadius: 4,
    borderWidth: 2,
    borderColor: 'transparent',
    backgroundColor: 'rgba(255,255,255,0.10)',
    overflow: 'hidden',
  },
  progLive: { backgroundColor: 'rgba(255,255,255,0.16)' },
  progPast: { backgroundColor: 'rgba(255,255,255,0.05)' },
  progFocused: { backgroundColor: '#e8ebf1', borderColor: '#e8ebf1' },
  progTitle: { color: colors.text, fontSize: 13, fontWeight: '600' },
  progMuted: { color: colors.muted, fontSize: 13 },
  focusDark: { color: '#0b0f18' },
  liveSmall: { fontSize: 9, fontWeight: '900' },

  nowLine: { position: 'absolute', top: 0, bottom: 0, width: 1, backgroundColor: 'rgba(127,176,255,0.8)' },
  nowDot: { position: 'absolute', top: -3, left: -3, width: 7, height: 7, borderRadius: 4, backgroundColor: colors.focus },

  pickerWrap: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.6)', alignItems: 'center', justifyContent: 'center' },
  picker: {
    width: '90%',
    maxWidth: 520,
    height: '85%',
    padding: 16,
    borderRadius: 20,
    backgroundColor: colors.panelSolid,
    borderWidth: 1,
    borderColor: colors.border,
  },
  pickerTitle: { color: colors.text, fontSize: 20, fontWeight: '900', marginBottom: 10 },
  pickRow: { paddingHorizontal: 14, paddingVertical: 12, marginBottom: 6, borderRadius: 12, borderWidth: 2, borderColor: 'transparent', backgroundColor: colors.panel },
  pickActive: { backgroundColor: 'rgba(79,140,255,0.2)', borderColor: 'rgba(79,140,255,0.5)' },
  pickText: { color: colors.text, fontSize: 15, fontWeight: '700' },
  closeBtn: { marginTop: 10, paddingVertical: 12, borderRadius: 12, borderWidth: 2, borderColor: colors.border, backgroundColor: colors.panelAlt },
});
