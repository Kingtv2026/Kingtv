import React, { useEffect, useState } from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { ScreenProps } from '../nav/Navigator';
import Focusable from '../components/Focusable';
import { xtreamLogin } from '../api/xtream';
import { clearCaches, loadPlaylist } from '../api';
import { clearEpgCache } from '../api/epg';
import { colors } from '../theme';
import Icon, { IconName } from '../components/Icon';
import { BUILD } from '../buildInfo';
import { getLiveEngine, LiveEngine, setLiveEngine } from '../prefs';
import { getStoredLicense, License, PANEL_SOURCE_ID } from '../license';
import { checkForUpdate, UpdateInfo } from '../update';
import { UpdateDialog } from '../components/UpdateDialog';
import { PinPrompt } from '../components/PinPrompt';
import { checkPin, isUnlocked, lock, setPin } from '../parental';

type Props = ScreenProps<'Settings'>;


export default function SettingsScreen({ route, navigation }: Props) {
  const { source } = route.params;
  const [account, setAccount] = useState<{ expiry?: string; conn?: string; status?: string } | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [update, setUpdate] = useState<UpdateInfo | null>(null);
  const [engine, setEngine] = useState<LiveEngine>(getLiveEngine());
  const [license, setLicense] = useState<License | null>(null);
  // Changement du code parental : 0 = fermé, 1 = code actuel, 2 = nouveau, 3 = confirmation
  const [pinStep, setPinStep] = useState(0);
  const [newPin, setNewPin] = useState('');
  const [unlockedNow, setUnlockedNow] = useState(isUnlocked());
  useEffect(() => {
    getStoredLicense().then(setLicense);
  }, []);

  const checkUpdate = async () => {
    setMsg('Recherche d’une mise à jour…');
    try {
      const u = await checkForUpdate();
      if (u) {
        setMsg(null);
        setUpdate(u);
      } else {
        setMsg('✓ Tu as déjà la dernière version');
      }
    } catch {
      setMsg('Impossible de vérifier pour le moment');
    }
  };

  useEffect(() => {
    xtreamLogin(source)
      .then(data => {
        const u = data?.user_info || {};
        const exp = Number(u.exp_date);
        let expiry: string | undefined;
        if (exp > 0) {
          const d = new Date(exp * 1000);
          expiry = `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`;
        }
        setAccount({
          expiry: expiry ?? 'Illimité',
          conn: u.max_connections ? String(u.max_connections) : undefined,
          status: u.status,
        });
      })
      .catch(() => setAccount({}));
  }, [source]);

  const refresh = async () => {
    setBusy(true);
    setMsg(null);
    clearCaches(source.id);
    try {
      const pl = await loadPlaylist(source);
      setMsg(`✓ Contenu actualisé : ${pl.channels.length} chaînes`);
    } catch (e: any) {
      setMsg(`Échec : ${e?.message || 'serveur injoignable'}`);
    } finally {
      setBusy(false);
    }
  };

  const host = source.server.replace(/^https?:\/\//i, '').split('/')[0];

  return (
    <View style={{ flex: 1 }}>
    <ScrollView contentContainerStyle={styles.content}>
      <Group title="Abonnement">
        <Info icon="satellite" label={source.name} value={host} />
        <Info icon="shield" label="Statut" value={account ? account.status || '—' : '…'} />
        <Info icon="guide" label="Expiration" value={account ? account.expiry || '—' : '…'} />
        <Info icon="tv" label="Connexions permises" value={account ? account.conn || '—' : '…'} last />
      </Group>

      <Group title="Contenu">
        <Row
          preferred
          icon="refresh"
          label={busy ? 'Actualisation…' : 'Actualiser le contenu'}
          sub="Recharge chaînes, films, séries et guide"
          onPress={refresh}
        />
        <Row
          icon="guide"
          label="Données de l’EPG"
          sub="Vider le guide horaire en mémoire"
          onPress={() => {
            clearEpgCache();
            setMsg('✓ Le guide sera rechargé à la prochaine ouverture');
          }}
        />
        <Row icon="guide" label="Guide TV" onPress={() => navigation.navigate('Guide', { source })} />
        <Row
          icon="record"
          label="Enregistrements"
          sub="Sur l’appareil ou une clé USB"
          onPress={() => navigation.navigate('Recordings')}
          last
        />
      </Group>

      {!!msg && <Text style={styles.msg}>{msg}</Text>}

      <Group title="Contrôle parental">
        <Row
          icon="lock"
          label="Changer le code"
          sub="Protège les groupes adultes des chaînes et des films (code par défaut : 0000)"
          onPress={() => setPinStep(1)}
          last={!unlockedNow}
        />
        {unlockedNow && (
          <Row
            icon="lock"
            label="Verrouiller maintenant"
            sub="Les groupes adultes sont déverrouillés jusqu’à la fermeture de l’app"
            onPress={() => {
              lock();
              setUnlockedNow(false);
              setMsg('✓ Groupes adultes verrouillés');
            }}
            last
          />
        )}
      </Group>

      <Group title="Lecteur">
        <Row
          icon="play-circle"
          label={`Télé en direct : ${engine === 'vlc' ? 'VLC (recommandé)' : 'Lecteur Android'}`}
          sub="Appuie pour changer · essaie l’autre si une chaîne saccade ou recule"
          onPress={() => {
            const next: LiveEngine = engine === 'vlc' ? 'exo' : 'vlc';
            setEngine(next);
            setLiveEngine(next);
          }}
          last
        />
      </Group>

      <Group title="Sources">
        {source.id !== PANEL_SOURCE_ID && (
          <Row
            icon="edit"
            label="Modifier cette liste"
            onPress={() => navigation.navigate('AddSource', { edit: source })}
          />
        )}
        <Row icon="list" label="Mes listes" sub="Changer ou ajouter un abonnement" onPress={() => navigation.popToTop()} last />
      </Group>

      <Group title="Application">
        <Row icon="download" label="Rechercher une mise à jour" sub={`Version installée : ${BUILD}`} onPress={checkUpdate} />
        {license && (
          <Info
            icon="key"
            label={`Licence ${license.code}`}
            value={license.expires ? `jusqu’au ${license.expires.split('-').reverse().join('/')}` : 'illimitée'}
          />
        )}
        <Info icon="info" label="À propos" value={`Kingtv · version ${BUILD}`} />
        <Info icon="shield" label="Contenu" value="Lecteur seulement, aucune chaîne incluse" last />
      </Group>
    </ScrollView>
    {update && <UpdateDialog info={update} onClose={() => setUpdate(null)} />}
    {pinStep === 1 && (
      <PinPrompt
        title="Code actuel"
        subtitle="Entre le code parental actuel"
        onSubmit={p => {
          if (!checkPin(p)) {
            return 'Code incorrect';
          }
          setPinStep(2);
          return true;
        }}
        onCancel={() => setPinStep(0)}
      />
    )}
    {pinStep === 2 && (
      <PinPrompt
        key="new"
        title="Nouveau code"
        subtitle="Choisis un code à 4 chiffres"
        onSubmit={p => {
          setNewPin(p);
          setPinStep(3);
          return true;
        }}
        onCancel={() => setPinStep(0)}
      />
    )}
    {pinStep === 3 && (
      <PinPrompt
        key="confirm"
        title="Confirme le code"
        subtitle="Entre le nouveau code une 2e fois"
        onSubmit={async p => {
          if (p !== newPin) {
            return 'Pas pareil au nouveau code, réessaie';
          }
          await setPin(p);
          setPinStep(0);
          setMsg('✓ Nouveau code parental enregistré');
          return true;
        }}
        onCancel={() => setPinStep(0)}
      />
    )}
    </View>
  );
}

function Group({ title, children }: { title: string; children?: React.ReactNode }) {
  return (
    <View style={{ marginBottom: 18 }}>
      <Text style={styles.groupTitle}>{title}</Text>
      <View style={styles.group}>{children}</View>
    </View>
  );
}

function Row({
  icon,
  label,
  sub,
  onPress,
  last,
  preferred,
}: {
  icon: IconName;
  label: string;
  sub?: string;
  onPress: () => void;
  last?: boolean;
  preferred?: boolean;
}) {
  return (
    <Focusable hasTVPreferredFocus={preferred} style={[styles.row, !last && styles.sep]} onPress={onPress}>
      <Icon name={icon} size={22} color={colors.accent} style={styles.icon} />
      <View style={{ flex: 1 }}>
        <Text style={styles.label}>{label}</Text>
        {!!sub && <Text style={styles.sub}>{sub}</Text>}
      </View>
      <Text style={styles.chev}>›</Text>
    </Focusable>
  );
}

function Info({ icon, label, value, last }: { icon: IconName; label: string; value: string; last?: boolean }) {
  return (
    <View style={[styles.row, !last && styles.sep]}>
      <Icon name={icon} size={22} color={colors.accent} style={styles.icon} />
      <Text style={[styles.label, { flex: 1 }]} numberOfLines={1}>
        {label}
      </Text>
      <Text style={styles.value} numberOfLines={1}>
        {value}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  content: { padding: 16, paddingBottom: 40, width: '100%', maxWidth: 720, alignSelf: 'center' },
  groupTitle: { color: colors.muted, fontSize: 13, fontWeight: '800', marginLeft: 8, marginBottom: 8, letterSpacing: 0.5 },
  group: { borderRadius: 18, backgroundColor: colors.panel, borderWidth: 1, borderColor: colors.border, overflow: 'hidden' },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    paddingHorizontal: 18,
    paddingVertical: 16,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  sep: { borderBottomColor: colors.border, borderBottomWidth: 1 },
  icon: { marginHorizontal: 3 },
  label: { color: colors.text, fontSize: 16, fontWeight: '700' },
  sub: { color: colors.muted, fontSize: 12, marginTop: 2 },
  value: { color: colors.muted, fontSize: 14, maxWidth: '55%' },
  chev: { color: colors.muted, fontSize: 24 },
  msg: { color: colors.cyan, fontSize: 14, textAlign: 'center', marginTop: -6, marginBottom: 16 },
});
