package __PKG__;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import org.json.JSONObject;

/**
 * Enregistre le flux d'une chaîne dans un fichier .ts, en avant-plan
 * (notification visible), même si l'app est fermée.
 */
public class KingRecordService extends Service {
  private static final String CHANNEL = "king_rec";
  private static final int NOTIF_ID = 4711;

  private final Map<String, Thread> running = new ConcurrentHashMap<>();
  private final Map<String, HttpURLConnection> conns = new ConcurrentHashMap<>();
  private final Set<String> stopping = ConcurrentHashMap.newKeySet();
  private PowerManager.WakeLock wake;

  static void start(Context c, String id) {
    Intent i = new Intent(c, KingRecordService.class);
    i.setAction("start");
    i.putExtra("id", id);
    try {
      c.startForegroundService(i);
    } catch (Exception e) {
      // Android a refusé de démarrer en arrière-plan : on réessaie dans une minute
      JSONObject j = RecStore.get(c, id);
      if (j != null && j.optLong("endAt") > System.currentTimeMillis() + 120000) {
        try {
          j.put("startAt", System.currentTimeMillis() + 60000);
          j.put("status", "scheduled");
        } catch (Exception ignored) {
        }
        RecStore.put(c, j);
        RecStore.schedule(c, j);
      }
    }
  }

  static void stop(Context c, String id) {
    Intent i = new Intent(c, KingRecordService.class);
    i.setAction("stop");
    i.putExtra("id", id);
    try {
      c.startService(i);
    } catch (Exception ignored) {
    }
  }

  /** Android 15 : limite de durée des services d'avant-plan atteinte → on termine proprement. */
  public void onTimeout(int startId, int fgsType) {
    stopping.addAll(running.keySet());
    for (HttpURLConnection c : conns.values()) new Thread(c::disconnect).start();
  }

  @Override
  public IBinder onBind(Intent intent) {
    return null;
  }

  @Override
  public int onStartCommand(Intent intent, int flags, int startId) {
    goForeground();
    String action = intent != null ? intent.getAction() : null;
    String id = intent != null ? intent.getStringExtra("id") : null;
    if ("start".equals(action) && id != null && !running.containsKey(id)) {
      final String jobId = id;
      Thread t = new Thread(() -> record(jobId), "king-rec-" + id);
      running.put(id, t);
      t.start();
    } else if ("stop".equals(action) && id != null) {
      stopping.add(id);
      final HttpURLConnection conn = conns.get(id);
      if (conn != null) new Thread(conn::disconnect).start();
      if (!running.containsKey(id)) {
        RecStore.remove(this, id);
        stopping.remove(id);
      }
    }
    refresh();
    return START_NOT_STICKY;
  }

  private void goForeground() {
    NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
    if (nm != null) {
      NotificationChannel ch = new NotificationChannel(CHANNEL, "Enregistrements", NotificationManager.IMPORTANCE_LOW);
      nm.createNotificationChannel(ch);
    }
    Notification n = buildNotification();
    if (Build.VERSION.SDK_INT >= 29) {
      startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
    } else {
      startForeground(NOTIF_ID, n);
    }
  }

  private Notification buildNotification() {
    StringBuilder titles = new StringBuilder();
    for (String id : running.keySet()) {
      JSONObject j = RecStore.get(this, id);
      if (j == null) continue;
      if (titles.length() > 0) titles.append(" · ");
      titles.append(j.optString("channel"));
    }
    int n = running.size();
    int icon = getResources().getIdentifier("king_rec", "drawable", getPackageName());
    if (icon == 0) icon = android.R.drawable.ic_media_play;
    Notification.Builder b = new Notification.Builder(this, CHANNEL)
        .setSmallIcon(icon)
        .setOngoing(true)
        .setContentTitle(n <= 1 ? "Kingtv enregistre" : "Kingtv enregistre " + n + " émissions")
        .setContentText(titles.length() > 0 ? titles.toString() : "Préparation…");
    Intent open = getPackageManager().getLaunchIntentForPackage(getPackageName());
    if (open != null) {
      b.setContentIntent(PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
    }
    return b.build();
  }

  private void refresh() {
    if (running.isEmpty()) {
      if (wake != null && wake.isHeld()) wake.release();
      stopForeground(true);
      stopSelf();
      return;
    }
    if (wake == null) {
      PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
      if (pm != null) {
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "kingtv:record");
        wake.setReferenceCounted(false);
      }
    }
    if (wake != null && !wake.isHeld()) wake.acquire(6 * 3600 * 1000L);
    NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
    if (nm != null) nm.notify(NOTIF_ID, buildNotification());
  }

  private void put(JSONObject j, String k, Object v) {
    try {
      j.put(k, v);
    } catch (Exception ignored) {
    }
  }

  private void record(String id) {
    JSONObject job = RecStore.get(this, id);
    String error = null;
    File file = null;
    try {
      if (job == null) return;
      long endAt = job.optLong("endAt");
      File dir = new File(job.optString("dir"));
      if (!dir.exists() && !dir.mkdirs()) {
        error = "Stockage introuvable (clé USB retirée ?)";
        return;
      }
      file = new File(dir, job.optString("file"));
      put(job, "status", "recording");
      put(job, "path", file.getAbsolutePath());
      put(job, "realStart", System.currentTimeMillis());
      RecStore.put(this, job);
      writeInfo(file, job);

      byte[] buf = new byte[188 * 512];
      int fails = 0;
      long bytes = 0;
      long lastSave = 0;
      try (FileOutputStream out = new FileOutputStream(file, true)) {
        while (System.currentTimeMillis() < endAt && !stopping.contains(id)) {
          HttpURLConnection conn = null;
          try {
            conn = (HttpURLConnection) new URL(job.optString("url")).openConnection();
            conn.setInstanceFollowRedirects(true);
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(20000);
            conn.setRequestProperty("User-Agent", "VLC/3.0.20 LibVLC/3.0.20");
            conns.put(id, conn);
            int code = conn.getResponseCode();
            if (code >= 400) throw new IOException("HTTP " + code);
            InputStream in = conn.getInputStream();
            int n;
            while ((n = in.read(buf)) != -1) {
              try {
                out.write(buf, 0, n);
              } catch (IOException we) {
                error = "Espace plein ou stockage retiré";
                throw new IllegalStateException(we);
              }
              bytes += n;
              fails = 0;
              long now = System.currentTimeMillis();
              if (now - lastSave > 5000) {
                lastSave = now;
                put(job, "bytes", bytes);
                RecStore.put(this, job);
              }
              if (now >= endAt || stopping.contains(id)) break;
            }
          } catch (IllegalStateException fatal) {
            break;
          } catch (Exception e) {
            if (stopping.contains(id)) break;
            fails++;
            try {
              Thread.sleep(Math.min(fails, 5) * 2000L);
            } catch (InterruptedException ie) {
              break;
            }
          } finally {
            conns.remove(id);
            if (conn != null) conn.disconnect();
          }
        }
      }
      if (bytes == 0 && error == null) error = "La chaîne n'a envoyé aucune image";
    } catch (Exception e) {
      if (error == null) error = "Erreur : " + e.getMessage();
    } finally {
      if (file != null && file.exists() && file.length() == 0) {
        file.delete();
        new File(file.getAbsolutePath() + ".json").delete();
      } else if (file != null && job != null) {
        put(job, "realEnd", System.currentTimeMillis());
        writeInfo(file, job);
      }
      RecStore.remove(this, id);
      stopping.remove(id);
      running.remove(id);
      if (error != null && job != null) notifyError(job.optString("channel") + " · " + job.optString("title"), error);
      refresh();
    }
  }

  /** Petit fichier à côté de l'enregistrement : titre, chaîne, heures. */
  private void writeInfo(File file, JSONObject job) {
    try (FileOutputStream o = new FileOutputStream(new File(file.getAbsolutePath() + ".json"))) {
      JSONObject info = new JSONObject();
      info.put("title", job.optString("title"));
      info.put("channel", job.optString("channel"));
      info.put("startAt", job.optLong("realStart", job.optLong("startAt")));
      info.put("endAt", job.optLong("realEnd", job.optLong("endAt")));
      o.write(info.toString().getBytes("UTF-8"));
    } catch (Exception ignored) {
    }
  }

  private void notifyError(String what, String why) {
    NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
    if (nm == null) return;
    int icon = getResources().getIdentifier("king_rec", "drawable", getPackageName());
    if (icon == 0) icon = android.R.drawable.ic_media_play;
    Notification n = new Notification.Builder(this, CHANNEL)
        .setSmallIcon(icon)
        .setContentTitle("Enregistrement interrompu")
        .setContentText(what + " — " + why)
        .setAutoCancel(true)
        .build();
    nm.notify(what.hashCode(), n);
  }
}
