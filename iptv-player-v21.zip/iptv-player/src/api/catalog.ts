/**
 * Catalogue complet des films ou des séries, chargé catégorie par catégorie
 * (3 à la fois) pour ne pas saturer la mémoire du téléphone. Gardé en mémoire.
 */
import { VodItem, XtreamSource } from '../types';
import { getSeries, getSeriesCategories, getVodCategories, getVodStreams } from './xtream';

type Kind = 'movie' | 'series';
const cache = new Map<string, VodItem[]>();
const inflight = new Map<string, Promise<VodItem[]>>();
const listeners = new Map<string, Set<(done: number, total: number) => void>>();

export function loadCatalog(
  src: XtreamSource,
  kind: Kind,
  onProgress?: (done: number, total: number) => void,
): Promise<VodItem[]> {
  const key = `${src.id}:${kind}`;
  const hit = cache.get(key);
  if (hit) {
    return Promise.resolve(hit);
  }
  if (onProgress) {
    if (!listeners.has(key)) {
      listeners.set(key, new Set());
    }
    listeners.get(key)!.add(onProgress);
  }
  const running = inflight.get(key);
  if (running) {
    return running;
  }

  const p = (async () => {
    const cats = kind === 'movie' ? await getVodCategories(src) : await getSeriesCategories(src);
    const queue = [...cats];
    const found = new Map<string, VodItem>();
    let done = 0;
    const worker = async () => {
      while (queue.length) {
        const c = queue.shift()!;
        try {
          const list = kind === 'movie' ? await getVodStreams(src, c.id) : await getSeries(src, c.id);
          for (const it of list) {
            if (!found.has(it.id)) {
              found.set(it.id, it);
            }
          }
        } catch {
          // une catégorie en erreur ne bloque pas les autres
        }
        done++;
        listeners.get(key)?.forEach(fn => fn(done, cats.length));
      }
    };
    await Promise.all([worker(), worker(), worker()]);
    const all = Array.from(found.values());
    cache.set(key, all);
    return all;
  })().finally(() => {
    inflight.delete(key);
    listeners.delete(key);
  });

  inflight.set(key, p);
  return p;
}

/** Les plus récemment ajoutés en premier. */
export function newest(items: VodItem[], n: number): VodItem[] {
  return [...items].sort((a, b) => (b.added || 0) - (a.added || 0)).slice(0, n);
}

export function clearCatalog() {
  cache.clear();
}
